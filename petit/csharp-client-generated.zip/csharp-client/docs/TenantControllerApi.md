# IO.Swagger.Api.TenantControllerApi

All URIs are relative to *https://192.168.0.9:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**DeleteTenantUsingDELETE**](TenantControllerApi.md#deletetenantusingdelete) | **DELETE** /api/tenant/{tenantId} | deleteTenant
[**GetTenantByIdUsingGET**](TenantControllerApi.md#gettenantbyidusingget) | **GET** /api/tenant/{tenantId} | getTenantById
[**GetTenantInfoByIdUsingGET**](TenantControllerApi.md#gettenantinfobyidusingget) | **GET** /api/tenant/info/{tenantId} | getTenantInfoById
[**GetTenantInfosUsingGET**](TenantControllerApi.md#gettenantinfosusingget) | **GET** /api/tenantInfos{?textSearch,sortProperty,sortOrder,pageSize,page} | getTenantInfos
[**GetTenantsUsingGET**](TenantControllerApi.md#gettenantsusingget) | **GET** /api/tenants{?textSearch,sortProperty,sortOrder,pageSize,page} | getTenants
[**SaveTenantUsingPOST**](TenantControllerApi.md#savetenantusingpost) | **POST** /api/tenant | saveTenant


<a name="deletetenantusingdelete"></a>
# **DeleteTenantUsingDELETE**
> void DeleteTenantUsingDELETE (string tenantId)

deleteTenant

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeleteTenantUsingDELETEExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TenantControllerApi();
            var tenantId = tenantId_example;  // string | tenantId

            try
            {
                // deleteTenant
                apiInstance.DeleteTenantUsingDELETE(tenantId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TenantControllerApi.DeleteTenantUsingDELETE: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenantId** | **string**| tenantId | 

### Return type

void (empty response body)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettenantbyidusingget"></a>
# **GetTenantByIdUsingGET**
> Tenant GetTenantByIdUsingGET (string tenantId)

getTenantById

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTenantByIdUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TenantControllerApi();
            var tenantId = tenantId_example;  // string | tenantId

            try
            {
                // getTenantById
                Tenant result = apiInstance.GetTenantByIdUsingGET(tenantId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TenantControllerApi.GetTenantByIdUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenantId** | **string**| tenantId | 

### Return type

[**Tenant**](Tenant.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettenantinfobyidusingget"></a>
# **GetTenantInfoByIdUsingGET**
> TenantInfo GetTenantInfoByIdUsingGET (string tenantId)

getTenantInfoById

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTenantInfoByIdUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TenantControllerApi();
            var tenantId = tenantId_example;  // string | tenantId

            try
            {
                // getTenantInfoById
                TenantInfo result = apiInstance.GetTenantInfoByIdUsingGET(tenantId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TenantControllerApi.GetTenantInfoByIdUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenantId** | **string**| tenantId | 

### Return type

[**TenantInfo**](TenantInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettenantinfosusingget"></a>
# **GetTenantInfosUsingGET**
> PageDataTenantInfo GetTenantInfosUsingGET (string pageSize, string page, string textSearch = null, string sortProperty = null, string sortOrder = null)

getTenantInfos

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTenantInfosUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TenantControllerApi();
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 

            try
            {
                // getTenantInfos
                PageDataTenantInfo result = apiInstance.GetTenantInfosUsingGET(pageSize, page, textSearch, sortProperty, sortOrder);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TenantControllerApi.GetTenantInfosUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 

### Return type

[**PageDataTenantInfo**](PageDataTenantInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettenantsusingget"></a>
# **GetTenantsUsingGET**
> PageDataTenant GetTenantsUsingGET (string pageSize, string page, string textSearch = null, string sortProperty = null, string sortOrder = null)

getTenants

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTenantsUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TenantControllerApi();
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 

            try
            {
                // getTenants
                PageDataTenant result = apiInstance.GetTenantsUsingGET(pageSize, page, textSearch, sortProperty, sortOrder);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TenantControllerApi.GetTenantsUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 

### Return type

[**PageDataTenant**](PageDataTenant.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="savetenantusingpost"></a>
# **SaveTenantUsingPOST**
> Tenant SaveTenantUsingPOST (Tenant tenant)

saveTenant

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SaveTenantUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TenantControllerApi();
            var tenant = new Tenant(); // Tenant | tenant

            try
            {
                // saveTenant
                Tenant result = apiInstance.SaveTenantUsingPOST(tenant);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TenantControllerApi.SaveTenantUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenant** | [**Tenant**](Tenant.md)| tenant | 

### Return type

[**Tenant**](Tenant.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

