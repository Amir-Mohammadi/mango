# IO.Swagger.Api.ComponentDescriptorControllerApi

All URIs are relative to *https://192.168.0.9:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetComponentDescriptorByClazzUsingGET**](ComponentDescriptorControllerApi.md#getcomponentdescriptorbyclazzusingget) | **GET** /api/component/{componentDescriptorClazz} | getComponentDescriptorByClazz
[**GetComponentDescriptorsByTypeUsingGET**](ComponentDescriptorControllerApi.md#getcomponentdescriptorsbytypeusingget) | **GET** /api/components/{componentType} | getComponentDescriptorsByType
[**GetComponentDescriptorsByTypesUsingGET**](ComponentDescriptorControllerApi.md#getcomponentdescriptorsbytypesusingget) | **GET** /api/components{?componentTypes} | getComponentDescriptorsByTypes


<a name="getcomponentdescriptorbyclazzusingget"></a>
# **GetComponentDescriptorByClazzUsingGET**
> ComponentDescriptor GetComponentDescriptorByClazzUsingGET (string componentDescriptorClazz)

getComponentDescriptorByClazz

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetComponentDescriptorByClazzUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new ComponentDescriptorControllerApi();
            var componentDescriptorClazz = componentDescriptorClazz_example;  // string | componentDescriptorClazz

            try
            {
                // getComponentDescriptorByClazz
                ComponentDescriptor result = apiInstance.GetComponentDescriptorByClazzUsingGET(componentDescriptorClazz);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ComponentDescriptorControllerApi.GetComponentDescriptorByClazzUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **componentDescriptorClazz** | **string**| componentDescriptorClazz | 

### Return type

[**ComponentDescriptor**](ComponentDescriptor.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getcomponentdescriptorsbytypeusingget"></a>
# **GetComponentDescriptorsByTypeUsingGET**
> List<ComponentDescriptor> GetComponentDescriptorsByTypeUsingGET (string componentType)

getComponentDescriptorsByType

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetComponentDescriptorsByTypeUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new ComponentDescriptorControllerApi();
            var componentType = componentType_example;  // string | componentType

            try
            {
                // getComponentDescriptorsByType
                List&lt;ComponentDescriptor&gt; result = apiInstance.GetComponentDescriptorsByTypeUsingGET(componentType);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ComponentDescriptorControllerApi.GetComponentDescriptorsByTypeUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **componentType** | **string**| componentType | 

### Return type

[**List<ComponentDescriptor>**](ComponentDescriptor.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getcomponentdescriptorsbytypesusingget"></a>
# **GetComponentDescriptorsByTypesUsingGET**
> List<ComponentDescriptor> GetComponentDescriptorsByTypesUsingGET (string componentTypes)

getComponentDescriptorsByTypes

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetComponentDescriptorsByTypesUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new ComponentDescriptorControllerApi();
            var componentTypes = componentTypes_example;  // string | componentTypes

            try
            {
                // getComponentDescriptorsByTypes
                List&lt;ComponentDescriptor&gt; result = apiInstance.GetComponentDescriptorsByTypesUsingGET(componentTypes);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ComponentDescriptorControllerApi.GetComponentDescriptorsByTypesUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **componentTypes** | **string**| componentTypes | 

### Return type

[**List<ComponentDescriptor>**](ComponentDescriptor.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

