# IO.Swagger.Model.AlarmDataPageLink
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Dynamic** | **bool?** |  | [optional] 
**Page** | **int?** |  | [optional] 
**PageSize** | **int?** |  | [optional] 
**SortOrder** | [**EntityDataSortOrder**](EntityDataSortOrder.md) |  | [optional] 
**StartTs** | **long?** |  | 
**TextSearch** | **string** |  | [optional] 
**EndTs** | **long?** |  | 
**TimeWindow** | **long?** |  | 
**TypeList** | **List&lt;string&gt;** |  | 
**StatusList** | **List&lt;string&gt;** |  | 
**SeverityList** | **List&lt;string&gt;** |  | 
**SearchPropagatedAlarms** | **bool?** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

