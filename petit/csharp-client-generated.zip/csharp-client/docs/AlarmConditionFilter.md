# IO.Swagger.Model.AlarmConditionFilter
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Key** | [**AlarmConditionFilterKey**](AlarmConditionFilterKey.md) |  | [optional] 
**Predicate** | [**KeyFilterPredicate**](KeyFilterPredicate.md) |  | [optional] 
**Value** | **Object** |  | [optional] 
**ValueType** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

