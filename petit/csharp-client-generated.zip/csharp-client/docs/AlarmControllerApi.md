# IO.Swagger.Api.AlarmControllerApi

All URIs are relative to *https://192.168.0.9:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AckAlarmUsingPOST**](AlarmControllerApi.md#ackalarmusingpost) | **POST** /api/alarm/{alarmId}/ack | ackAlarm
[**ClearAlarmUsingPOST**](AlarmControllerApi.md#clearalarmusingpost) | **POST** /api/alarm/{alarmId}/clear | clearAlarm
[**DeleteAlarmUsingDELETE**](AlarmControllerApi.md#deletealarmusingdelete) | **DELETE** /api/alarm/{alarmId} | deleteAlarm
[**GetAlarmByIdUsingGET**](AlarmControllerApi.md#getalarmbyidusingget) | **GET** /api/alarm/{alarmId} | getAlarmById
[**GetAlarmInfoByIdUsingGET**](AlarmControllerApi.md#getalarminfobyidusingget) | **GET** /api/alarm/info/{alarmId} | getAlarmInfoById
[**GetAlarmsUsingGET**](AlarmControllerApi.md#getalarmsusingget) | **GET** /api/alarm/{entityType}/{entityId}{?searchStatus,status,pageSize,page,textSearch,sortProperty,sortOrder,startTime,endTime,offset,fetchOriginator} | getAlarms
[**GetHighestAlarmSeverityUsingGET**](AlarmControllerApi.md#gethighestalarmseverityusingget) | **GET** /api/alarm/highestSeverity/{entityType}/{entityId}{?searchStatus,status} | getHighestAlarmSeverity
[**SaveAlarmUsingPOST**](AlarmControllerApi.md#savealarmusingpost) | **POST** /api/alarm | saveAlarm


<a name="ackalarmusingpost"></a>
# **AckAlarmUsingPOST**
> void AckAlarmUsingPOST (string alarmId)

ackAlarm

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AckAlarmUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AlarmControllerApi();
            var alarmId = alarmId_example;  // string | alarmId

            try
            {
                // ackAlarm
                apiInstance.AckAlarmUsingPOST(alarmId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AlarmControllerApi.AckAlarmUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **alarmId** | **string**| alarmId | 

### Return type

void (empty response body)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="clearalarmusingpost"></a>
# **ClearAlarmUsingPOST**
> void ClearAlarmUsingPOST (string alarmId)

clearAlarm

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ClearAlarmUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AlarmControllerApi();
            var alarmId = alarmId_example;  // string | alarmId

            try
            {
                // clearAlarm
                apiInstance.ClearAlarmUsingPOST(alarmId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AlarmControllerApi.ClearAlarmUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **alarmId** | **string**| alarmId | 

### Return type

void (empty response body)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="deletealarmusingdelete"></a>
# **DeleteAlarmUsingDELETE**
> bool? DeleteAlarmUsingDELETE (string alarmId)

deleteAlarm

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeleteAlarmUsingDELETEExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AlarmControllerApi();
            var alarmId = alarmId_example;  // string | alarmId

            try
            {
                // deleteAlarm
                bool? result = apiInstance.DeleteAlarmUsingDELETE(alarmId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AlarmControllerApi.DeleteAlarmUsingDELETE: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **alarmId** | **string**| alarmId | 

### Return type

**bool?**

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getalarmbyidusingget"></a>
# **GetAlarmByIdUsingGET**
> Alarm GetAlarmByIdUsingGET (string alarmId)

getAlarmById

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAlarmByIdUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AlarmControllerApi();
            var alarmId = alarmId_example;  // string | alarmId

            try
            {
                // getAlarmById
                Alarm result = apiInstance.GetAlarmByIdUsingGET(alarmId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AlarmControllerApi.GetAlarmByIdUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **alarmId** | **string**| alarmId | 

### Return type

[**Alarm**](Alarm.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getalarminfobyidusingget"></a>
# **GetAlarmInfoByIdUsingGET**
> AlarmInfo GetAlarmInfoByIdUsingGET (string alarmId)

getAlarmInfoById

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAlarmInfoByIdUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AlarmControllerApi();
            var alarmId = alarmId_example;  // string | alarmId

            try
            {
                // getAlarmInfoById
                AlarmInfo result = apiInstance.GetAlarmInfoByIdUsingGET(alarmId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AlarmControllerApi.GetAlarmInfoByIdUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **alarmId** | **string**| alarmId | 

### Return type

[**AlarmInfo**](AlarmInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getalarmsusingget"></a>
# **GetAlarmsUsingGET**
> PageDataAlarmInfo GetAlarmsUsingGET (string entityType, string entityId, int? pageSize, int? page, string searchStatus = null, string status = null, string textSearch = null, string sortProperty = null, string sortOrder = null, long? startTime = null, long? endTime = null, string offset = null, bool? fetchOriginator = null)

getAlarms

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAlarmsUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AlarmControllerApi();
            var entityType = entityType_example;  // string | entityType
            var entityId = entityId_example;  // string | entityId
            var pageSize = 56;  // int? | pageSize
            var page = 56;  // int? | page
            var searchStatus = searchStatus_example;  // string | searchStatus (optional) 
            var status = status_example;  // string | status (optional) 
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 
            var startTime = 789;  // long? | startTime (optional) 
            var endTime = 789;  // long? | endTime (optional) 
            var offset = offset_example;  // string | offset (optional) 
            var fetchOriginator = true;  // bool? | fetchOriginator (optional) 

            try
            {
                // getAlarms
                PageDataAlarmInfo result = apiInstance.GetAlarmsUsingGET(entityType, entityId, pageSize, page, searchStatus, status, textSearch, sortProperty, sortOrder, startTime, endTime, offset, fetchOriginator);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AlarmControllerApi.GetAlarmsUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entityType** | **string**| entityType | 
 **entityId** | **string**| entityId | 
 **pageSize** | **int?**| pageSize | 
 **page** | **int?**| page | 
 **searchStatus** | **string**| searchStatus | [optional] 
 **status** | **string**| status | [optional] 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 
 **startTime** | **long?**| startTime | [optional] 
 **endTime** | **long?**| endTime | [optional] 
 **offset** | **string**| offset | [optional] 
 **fetchOriginator** | **bool?**| fetchOriginator | [optional] 

### Return type

[**PageDataAlarmInfo**](PageDataAlarmInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gethighestalarmseverityusingget"></a>
# **GetHighestAlarmSeverityUsingGET**
> string GetHighestAlarmSeverityUsingGET (string entityType, string entityId, string searchStatus = null, string status = null)

getHighestAlarmSeverity

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetHighestAlarmSeverityUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AlarmControllerApi();
            var entityType = entityType_example;  // string | entityType
            var entityId = entityId_example;  // string | entityId
            var searchStatus = searchStatus_example;  // string | searchStatus (optional) 
            var status = status_example;  // string | status (optional) 

            try
            {
                // getHighestAlarmSeverity
                string result = apiInstance.GetHighestAlarmSeverityUsingGET(entityType, entityId, searchStatus, status);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AlarmControllerApi.GetHighestAlarmSeverityUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entityType** | **string**| entityType | 
 **entityId** | **string**| entityId | 
 **searchStatus** | **string**| searchStatus | [optional] 
 **status** | **string**| status | [optional] 

### Return type

**string**

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="savealarmusingpost"></a>
# **SaveAlarmUsingPOST**
> Alarm SaveAlarmUsingPOST (Alarm alarm)

saveAlarm

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SaveAlarmUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AlarmControllerApi();
            var alarm = new Alarm(); // Alarm | alarm

            try
            {
                // saveAlarm
                Alarm result = apiInstance.SaveAlarmUsingPOST(alarm);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AlarmControllerApi.SaveAlarmUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **alarm** | [**Alarm**](Alarm.md)| alarm | 

### Return type

[**Alarm**](Alarm.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

