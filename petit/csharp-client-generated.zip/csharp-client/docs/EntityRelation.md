# IO.Swagger.Model.EntityRelation
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AdditionalInfo** | **string** |  | [optional] 
**From** | [**EntityId**](EntityId.md) |  | [optional] 
**To** | [**EntityId**](EntityId.md) |  | [optional] 
**Type** | **string** |  | [optional] 
**TypeGroup** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

