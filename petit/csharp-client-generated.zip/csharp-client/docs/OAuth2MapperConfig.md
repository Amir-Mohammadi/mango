# IO.Swagger.Model.OAuth2MapperConfig
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ActivateUser** | **bool?** |  | [optional] 
**AllowUserCreation** | **bool?** |  | [optional] 
**Basic** | [**OAuth2BasicMapperConfig**](OAuth2BasicMapperConfig.md) |  | [optional] 
**Custom** | [**OAuth2CustomMapperConfig**](OAuth2CustomMapperConfig.md) |  | [optional] 
**Type** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

