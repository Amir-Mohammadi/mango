# IO.Swagger.Api.OAuth2ConfigTemplateControllerApi

All URIs are relative to *https://192.168.0.9:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**DeleteClientRegistrationTemplateUsingDELETE**](OAuth2ConfigTemplateControllerApi.md#deleteclientregistrationtemplateusingdelete) | **DELETE** /api/oauth2/config/template/{clientRegistrationTemplateId} | deleteClientRegistrationTemplate
[**GetClientRegistrationTemplatesUsingGET**](OAuth2ConfigTemplateControllerApi.md#getclientregistrationtemplatesusingget) | **GET** /api/oauth2/config/template | getClientRegistrationTemplates
[**SaveClientRegistrationTemplateUsingPOST**](OAuth2ConfigTemplateControllerApi.md#saveclientregistrationtemplateusingpost) | **POST** /api/oauth2/config/template | saveClientRegistrationTemplate


<a name="deleteclientregistrationtemplateusingdelete"></a>
# **DeleteClientRegistrationTemplateUsingDELETE**
> void DeleteClientRegistrationTemplateUsingDELETE (string clientRegistrationTemplateId)

deleteClientRegistrationTemplate

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeleteClientRegistrationTemplateUsingDELETEExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new OAuth2ConfigTemplateControllerApi();
            var clientRegistrationTemplateId = clientRegistrationTemplateId_example;  // string | clientRegistrationTemplateId

            try
            {
                // deleteClientRegistrationTemplate
                apiInstance.DeleteClientRegistrationTemplateUsingDELETE(clientRegistrationTemplateId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OAuth2ConfigTemplateControllerApi.DeleteClientRegistrationTemplateUsingDELETE: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **clientRegistrationTemplateId** | **string**| clientRegistrationTemplateId | 

### Return type

void (empty response body)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getclientregistrationtemplatesusingget"></a>
# **GetClientRegistrationTemplatesUsingGET**
> List<OAuth2ClientRegistrationTemplate> GetClientRegistrationTemplatesUsingGET ()

getClientRegistrationTemplates

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetClientRegistrationTemplatesUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new OAuth2ConfigTemplateControllerApi();

            try
            {
                // getClientRegistrationTemplates
                List&lt;OAuth2ClientRegistrationTemplate&gt; result = apiInstance.GetClientRegistrationTemplatesUsingGET();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OAuth2ConfigTemplateControllerApi.GetClientRegistrationTemplatesUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List<OAuth2ClientRegistrationTemplate>**](OAuth2ClientRegistrationTemplate.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="saveclientregistrationtemplateusingpost"></a>
# **SaveClientRegistrationTemplateUsingPOST**
> OAuth2ClientRegistrationTemplate SaveClientRegistrationTemplateUsingPOST (OAuth2ClientRegistrationTemplate clientRegistrationTemplate)

saveClientRegistrationTemplate

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SaveClientRegistrationTemplateUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new OAuth2ConfigTemplateControllerApi();
            var clientRegistrationTemplate = new OAuth2ClientRegistrationTemplate(); // OAuth2ClientRegistrationTemplate | clientRegistrationTemplate

            try
            {
                // saveClientRegistrationTemplate
                OAuth2ClientRegistrationTemplate result = apiInstance.SaveClientRegistrationTemplateUsingPOST(clientRegistrationTemplate);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OAuth2ConfigTemplateControllerApi.SaveClientRegistrationTemplateUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **clientRegistrationTemplate** | [**OAuth2ClientRegistrationTemplate**](OAuth2ClientRegistrationTemplate.md)| clientRegistrationTemplate | 

### Return type

[**OAuth2ClientRegistrationTemplate**](OAuth2ClientRegistrationTemplate.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

