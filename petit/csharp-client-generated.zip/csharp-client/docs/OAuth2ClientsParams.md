# IO.Swagger.Model.OAuth2ClientsParams
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DomainsParams** | [**List&lt;OAuth2ClientsDomainParams&gt;**](OAuth2ClientsDomainParams.md) |  | [optional] 
**Enabled** | **bool?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

