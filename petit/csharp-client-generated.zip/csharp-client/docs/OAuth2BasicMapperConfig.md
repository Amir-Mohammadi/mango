# IO.Swagger.Model.OAuth2BasicMapperConfig
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AlwaysFullScreen** | **bool?** |  | [optional] 
**CustomerNamePattern** | **string** |  | [optional] 
**DefaultDashboardName** | **string** |  | [optional] 
**EmailAttributeKey** | **string** |  | [optional] 
**FirstNameAttributeKey** | **string** |  | [optional] 
**LastNameAttributeKey** | **string** |  | [optional] 
**TenantNamePattern** | **string** |  | [optional] 
**TenantNameStrategy** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

