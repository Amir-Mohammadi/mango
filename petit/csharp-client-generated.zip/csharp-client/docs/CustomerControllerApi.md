# IO.Swagger.Api.CustomerControllerApi

All URIs are relative to *https://192.168.0.9:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**DeleteCustomerUsingDELETE**](CustomerControllerApi.md#deletecustomerusingdelete) | **DELETE** /api/customer/{customerId} | deleteCustomer
[**GetCustomerByIdUsingGET**](CustomerControllerApi.md#getcustomerbyidusingget) | **GET** /api/customer/{customerId} | getCustomerById
[**GetCustomerTitleByIdUsingGET**](CustomerControllerApi.md#getcustomertitlebyidusingget) | **GET** /api/customer/{customerId}/title | getCustomerTitleById
[**GetCustomersUsingGET**](CustomerControllerApi.md#getcustomersusingget) | **GET** /api/customers{?textSearch,sortProperty,sortOrder,pageSize,page} | getCustomers
[**GetShortCustomerInfoByIdUsingGET**](CustomerControllerApi.md#getshortcustomerinfobyidusingget) | **GET** /api/customer/{customerId}/shortInfo | getShortCustomerInfoById
[**GetTenantCustomerUsingGET**](CustomerControllerApi.md#gettenantcustomerusingget) | **GET** /api/tenant/customers{?customerTitle} | getTenantCustomer
[**SaveCustomerUsingPOST**](CustomerControllerApi.md#savecustomerusingpost) | **POST** /api/customer | saveCustomer


<a name="deletecustomerusingdelete"></a>
# **DeleteCustomerUsingDELETE**
> void DeleteCustomerUsingDELETE (string customerId)

deleteCustomer

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeleteCustomerUsingDELETEExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new CustomerControllerApi();
            var customerId = customerId_example;  // string | customerId

            try
            {
                // deleteCustomer
                apiInstance.DeleteCustomerUsingDELETE(customerId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CustomerControllerApi.DeleteCustomerUsingDELETE: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customerId** | **string**| customerId | 

### Return type

void (empty response body)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getcustomerbyidusingget"></a>
# **GetCustomerByIdUsingGET**
> Customer GetCustomerByIdUsingGET (string customerId)

getCustomerById

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetCustomerByIdUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new CustomerControllerApi();
            var customerId = customerId_example;  // string | customerId

            try
            {
                // getCustomerById
                Customer result = apiInstance.GetCustomerByIdUsingGET(customerId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CustomerControllerApi.GetCustomerByIdUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customerId** | **string**| customerId | 

### Return type

[**Customer**](Customer.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getcustomertitlebyidusingget"></a>
# **GetCustomerTitleByIdUsingGET**
> string GetCustomerTitleByIdUsingGET (string customerId)

getCustomerTitleById

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetCustomerTitleByIdUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new CustomerControllerApi();
            var customerId = customerId_example;  // string | customerId

            try
            {
                // getCustomerTitleById
                string result = apiInstance.GetCustomerTitleByIdUsingGET(customerId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CustomerControllerApi.GetCustomerTitleByIdUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customerId** | **string**| customerId | 

### Return type

**string**

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/text

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getcustomersusingget"></a>
# **GetCustomersUsingGET**
> PageDataCustomer GetCustomersUsingGET (string pageSize, string page, string textSearch = null, string sortProperty = null, string sortOrder = null)

getCustomers

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetCustomersUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new CustomerControllerApi();
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 

            try
            {
                // getCustomers
                PageDataCustomer result = apiInstance.GetCustomersUsingGET(pageSize, page, textSearch, sortProperty, sortOrder);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CustomerControllerApi.GetCustomersUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 

### Return type

[**PageDataCustomer**](PageDataCustomer.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getshortcustomerinfobyidusingget"></a>
# **GetShortCustomerInfoByIdUsingGET**
> string GetShortCustomerInfoByIdUsingGET (string customerId)

getShortCustomerInfoById

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetShortCustomerInfoByIdUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new CustomerControllerApi();
            var customerId = customerId_example;  // string | customerId

            try
            {
                // getShortCustomerInfoById
                string result = apiInstance.GetShortCustomerInfoByIdUsingGET(customerId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CustomerControllerApi.GetShortCustomerInfoByIdUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customerId** | **string**| customerId | 

### Return type

**string**

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettenantcustomerusingget"></a>
# **GetTenantCustomerUsingGET**
> Customer GetTenantCustomerUsingGET (string customerTitle)

getTenantCustomer

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTenantCustomerUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new CustomerControllerApi();
            var customerTitle = customerTitle_example;  // string | customerTitle

            try
            {
                // getTenantCustomer
                Customer result = apiInstance.GetTenantCustomerUsingGET(customerTitle);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CustomerControllerApi.GetTenantCustomerUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customerTitle** | **string**| customerTitle | 

### Return type

[**Customer**](Customer.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="savecustomerusingpost"></a>
# **SaveCustomerUsingPOST**
> Customer SaveCustomerUsingPOST (Customer customer)

saveCustomer

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SaveCustomerUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new CustomerControllerApi();
            var customer = new Customer(); // Customer | customer

            try
            {
                // saveCustomer
                Customer result = apiInstance.SaveCustomerUsingPOST(customer);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CustomerControllerApi.SaveCustomerUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customer** | [**Customer**](Customer.md)| customer | 

### Return type

[**Customer**](Customer.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

