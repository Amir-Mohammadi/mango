# IO.Swagger.Model.ComponentDescriptor
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Actions** | **string** |  | [optional] 
**Clazz** | **string** |  | [optional] 
**ConfigurationDescriptor** | **string** |  | [optional] 
**CreatedTime** | **long?** |  | [optional] 
**Id** | [**ComponentDescriptorId**](ComponentDescriptorId.md) |  | [optional] 
**Name** | **string** |  | [optional] 
**Scope** | **string** |  | [optional] 
**Type** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

