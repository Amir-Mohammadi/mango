# IO.Swagger.Model.Customer
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AdditionalInfo** | **string** |  | [optional] 
**Address** | **string** |  | [optional] 
**Address2** | **string** |  | [optional] 
**City** | **string** |  | [optional] 
**Country** | **string** |  | [optional] 
**CreatedTime** | **long?** |  | [optional] 
**Email** | **string** |  | [optional] 
**Id** | [**CustomerId**](CustomerId.md) |  | [optional] 
**Name** | **string** |  | [optional] 
**Phone** | **string** |  | [optional] 
**State** | **string** |  | [optional] 
**TenantId** | [**TenantId**](TenantId.md) |  | [optional] 
**Title** | **string** |  | [optional] 
**Zip** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

