# IO.Swagger.Model.EntityRelationInfo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AdditionalInfo** | **string** |  | [optional] 
**From** | [**EntityId**](EntityId.md) |  | [optional] 
**FromName** | **string** |  | [optional] 
**To** | [**EntityId**](EntityId.md) |  | [optional] 
**ToName** | **string** |  | [optional] 
**Type** | **string** |  | [optional] 
**TypeGroup** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

