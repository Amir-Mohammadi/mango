# IO.Swagger.Model.AdminSettings
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreatedTime** | **long?** |  | [optional] 
**Id** | [**AdminSettingsId**](AdminSettingsId.md) |  | [optional] 
**JsonValue** | **string** |  | [optional] 
**Key** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

