# IO.Swagger.Model.Asset
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AdditionalInfo** | **string** |  | [optional] 
**CreatedTime** | **long?** |  | [optional] 
**CustomerId** | [**CustomerId**](CustomerId.md) |  | [optional] 
**Id** | [**AssetId**](AssetId.md) |  | [optional] 
**Label** | **string** |  | [optional] 
**Name** | **string** |  | [optional] 
**TenantId** | [**TenantId**](TenantId.md) |  | [optional] 
**Type** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

