# IO.Swagger.Api.EntityViewControllerApi

All URIs are relative to *https://192.168.0.9:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AssignEntityViewToCustomerUsingPOST**](EntityViewControllerApi.md#assignentityviewtocustomerusingpost) | **POST** /api/customer/{customerId}/entityView/{entityViewId} | assignEntityViewToCustomer
[**AssignEntityViewToPublicCustomerUsingPOST**](EntityViewControllerApi.md#assignentityviewtopubliccustomerusingpost) | **POST** /api/customer/public/entityView/{entityViewId} | assignEntityViewToPublicCustomer
[**DeleteEntityViewUsingDELETE**](EntityViewControllerApi.md#deleteentityviewusingdelete) | **DELETE** /api/entityView/{entityViewId} | deleteEntityView
[**FindByQueryUsingPOST3**](EntityViewControllerApi.md#findbyqueryusingpost3) | **POST** /api/entityViews | findByQuery
[**GetCustomerEntityViewInfosUsingGET**](EntityViewControllerApi.md#getcustomerentityviewinfosusingget) | **GET** /api/customer/{customerId}/entityViewInfos{?type,textSearch,sortProperty,sortOrder,pageSize,page} | getCustomerEntityViewInfos
[**GetCustomerEntityViewsUsingGET**](EntityViewControllerApi.md#getcustomerentityviewsusingget) | **GET** /api/customer/{customerId}/entityViews{?type,textSearch,sortProperty,sortOrder,pageSize,page} | getCustomerEntityViews
[**GetEntityViewByIdUsingGET**](EntityViewControllerApi.md#getentityviewbyidusingget) | **GET** /api/entityView/{entityViewId} | getEntityViewById
[**GetEntityViewInfoByIdUsingGET**](EntityViewControllerApi.md#getentityviewinfobyidusingget) | **GET** /api/entityView/info/{entityViewId} | getEntityViewInfoById
[**GetEntityViewTypesUsingGET**](EntityViewControllerApi.md#getentityviewtypesusingget) | **GET** /api/entityView/types | getEntityViewTypes
[**GetTenantEntityViewInfosUsingGET**](EntityViewControllerApi.md#gettenantentityviewinfosusingget) | **GET** /api/tenant/entityViewInfos{?type,textSearch,sortProperty,sortOrder,pageSize,page} | getTenantEntityViewInfos
[**GetTenantEntityViewUsingGET**](EntityViewControllerApi.md#gettenantentityviewusingget) | **GET** /api/tenant/entityViews{?entityViewName} | getTenantEntityView
[**GetTenantEntityViewsUsingGET**](EntityViewControllerApi.md#gettenantentityviewsusingget) | **GET** /api/tenant/entityViews{?type,textSearch,sortProperty,sortOrder,pageSize,page} | getTenantEntityViews
[**SaveEntityViewUsingPOST**](EntityViewControllerApi.md#saveentityviewusingpost) | **POST** /api/entityView | saveEntityView
[**UnassignEntityViewFromCustomerUsingDELETE**](EntityViewControllerApi.md#unassignentityviewfromcustomerusingdelete) | **DELETE** /api/customer/entityView/{entityViewId} | unassignEntityViewFromCustomer


<a name="assignentityviewtocustomerusingpost"></a>
# **AssignEntityViewToCustomerUsingPOST**
> EntityView AssignEntityViewToCustomerUsingPOST (string customerId, string entityViewId)

assignEntityViewToCustomer

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AssignEntityViewToCustomerUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityViewControllerApi();
            var customerId = customerId_example;  // string | customerId
            var entityViewId = entityViewId_example;  // string | entityViewId

            try
            {
                // assignEntityViewToCustomer
                EntityView result = apiInstance.AssignEntityViewToCustomerUsingPOST(customerId, entityViewId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityViewControllerApi.AssignEntityViewToCustomerUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customerId** | **string**| customerId | 
 **entityViewId** | **string**| entityViewId | 

### Return type

[**EntityView**](EntityView.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="assignentityviewtopubliccustomerusingpost"></a>
# **AssignEntityViewToPublicCustomerUsingPOST**
> EntityView AssignEntityViewToPublicCustomerUsingPOST (string entityViewId)

assignEntityViewToPublicCustomer

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AssignEntityViewToPublicCustomerUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityViewControllerApi();
            var entityViewId = entityViewId_example;  // string | entityViewId

            try
            {
                // assignEntityViewToPublicCustomer
                EntityView result = apiInstance.AssignEntityViewToPublicCustomerUsingPOST(entityViewId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityViewControllerApi.AssignEntityViewToPublicCustomerUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entityViewId** | **string**| entityViewId | 

### Return type

[**EntityView**](EntityView.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="deleteentityviewusingdelete"></a>
# **DeleteEntityViewUsingDELETE**
> void DeleteEntityViewUsingDELETE (string entityViewId)

deleteEntityView

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeleteEntityViewUsingDELETEExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityViewControllerApi();
            var entityViewId = entityViewId_example;  // string | entityViewId

            try
            {
                // deleteEntityView
                apiInstance.DeleteEntityViewUsingDELETE(entityViewId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityViewControllerApi.DeleteEntityViewUsingDELETE: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entityViewId** | **string**| entityViewId | 

### Return type

void (empty response body)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="findbyqueryusingpost3"></a>
# **FindByQueryUsingPOST3**
> List<EntityView> FindByQueryUsingPOST3 (EntityViewSearchQuery query)

findByQuery

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class FindByQueryUsingPOST3Example
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityViewControllerApi();
            var query = new EntityViewSearchQuery(); // EntityViewSearchQuery | query

            try
            {
                // findByQuery
                List&lt;EntityView&gt; result = apiInstance.FindByQueryUsingPOST3(query);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityViewControllerApi.FindByQueryUsingPOST3: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | [**EntityViewSearchQuery**](EntityViewSearchQuery.md)| query | 

### Return type

[**List<EntityView>**](EntityView.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getcustomerentityviewinfosusingget"></a>
# **GetCustomerEntityViewInfosUsingGET**
> PageDataEntityViewInfo GetCustomerEntityViewInfosUsingGET (string customerId, string pageSize, string page, string type = null, string textSearch = null, string sortProperty = null, string sortOrder = null)

getCustomerEntityViewInfos

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetCustomerEntityViewInfosUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityViewControllerApi();
            var customerId = customerId_example;  // string | customerId
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var type = type_example;  // string | type (optional) 
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 

            try
            {
                // getCustomerEntityViewInfos
                PageDataEntityViewInfo result = apiInstance.GetCustomerEntityViewInfosUsingGET(customerId, pageSize, page, type, textSearch, sortProperty, sortOrder);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityViewControllerApi.GetCustomerEntityViewInfosUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customerId** | **string**| customerId | 
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **type** | **string**| type | [optional] 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 

### Return type

[**PageDataEntityViewInfo**](PageDataEntityViewInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getcustomerentityviewsusingget"></a>
# **GetCustomerEntityViewsUsingGET**
> PageDataEntityView GetCustomerEntityViewsUsingGET (string customerId, string pageSize, string page, string type = null, string textSearch = null, string sortProperty = null, string sortOrder = null)

getCustomerEntityViews

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetCustomerEntityViewsUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityViewControllerApi();
            var customerId = customerId_example;  // string | customerId
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var type = type_example;  // string | type (optional) 
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 

            try
            {
                // getCustomerEntityViews
                PageDataEntityView result = apiInstance.GetCustomerEntityViewsUsingGET(customerId, pageSize, page, type, textSearch, sortProperty, sortOrder);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityViewControllerApi.GetCustomerEntityViewsUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customerId** | **string**| customerId | 
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **type** | **string**| type | [optional] 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 

### Return type

[**PageDataEntityView**](PageDataEntityView.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getentityviewbyidusingget"></a>
# **GetEntityViewByIdUsingGET**
> EntityView GetEntityViewByIdUsingGET (string entityViewId)

getEntityViewById

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetEntityViewByIdUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityViewControllerApi();
            var entityViewId = entityViewId_example;  // string | entityViewId

            try
            {
                // getEntityViewById
                EntityView result = apiInstance.GetEntityViewByIdUsingGET(entityViewId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityViewControllerApi.GetEntityViewByIdUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entityViewId** | **string**| entityViewId | 

### Return type

[**EntityView**](EntityView.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getentityviewinfobyidusingget"></a>
# **GetEntityViewInfoByIdUsingGET**
> EntityViewInfo GetEntityViewInfoByIdUsingGET (string entityViewId)

getEntityViewInfoById

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetEntityViewInfoByIdUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityViewControllerApi();
            var entityViewId = entityViewId_example;  // string | entityViewId

            try
            {
                // getEntityViewInfoById
                EntityViewInfo result = apiInstance.GetEntityViewInfoByIdUsingGET(entityViewId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityViewControllerApi.GetEntityViewInfoByIdUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entityViewId** | **string**| entityViewId | 

### Return type

[**EntityViewInfo**](EntityViewInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getentityviewtypesusingget"></a>
# **GetEntityViewTypesUsingGET**
> List<EntitySubtype> GetEntityViewTypesUsingGET ()

getEntityViewTypes

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetEntityViewTypesUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityViewControllerApi();

            try
            {
                // getEntityViewTypes
                List&lt;EntitySubtype&gt; result = apiInstance.GetEntityViewTypesUsingGET();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityViewControllerApi.GetEntityViewTypesUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List<EntitySubtype>**](EntitySubtype.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettenantentityviewinfosusingget"></a>
# **GetTenantEntityViewInfosUsingGET**
> PageDataEntityViewInfo GetTenantEntityViewInfosUsingGET (string pageSize, string page, string type = null, string textSearch = null, string sortProperty = null, string sortOrder = null)

getTenantEntityViewInfos

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTenantEntityViewInfosUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityViewControllerApi();
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var type = type_example;  // string | type (optional) 
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 

            try
            {
                // getTenantEntityViewInfos
                PageDataEntityViewInfo result = apiInstance.GetTenantEntityViewInfosUsingGET(pageSize, page, type, textSearch, sortProperty, sortOrder);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityViewControllerApi.GetTenantEntityViewInfosUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **type** | **string**| type | [optional] 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 

### Return type

[**PageDataEntityViewInfo**](PageDataEntityViewInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettenantentityviewusingget"></a>
# **GetTenantEntityViewUsingGET**
> EntityView GetTenantEntityViewUsingGET (string entityViewName)

getTenantEntityView

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTenantEntityViewUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityViewControllerApi();
            var entityViewName = entityViewName_example;  // string | entityViewName

            try
            {
                // getTenantEntityView
                EntityView result = apiInstance.GetTenantEntityViewUsingGET(entityViewName);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityViewControllerApi.GetTenantEntityViewUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entityViewName** | **string**| entityViewName | 

### Return type

[**EntityView**](EntityView.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettenantentityviewsusingget"></a>
# **GetTenantEntityViewsUsingGET**
> PageDataEntityView GetTenantEntityViewsUsingGET (string pageSize, string page, string type = null, string textSearch = null, string sortProperty = null, string sortOrder = null)

getTenantEntityViews

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTenantEntityViewsUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityViewControllerApi();
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var type = type_example;  // string | type (optional) 
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 

            try
            {
                // getTenantEntityViews
                PageDataEntityView result = apiInstance.GetTenantEntityViewsUsingGET(pageSize, page, type, textSearch, sortProperty, sortOrder);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityViewControllerApi.GetTenantEntityViewsUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **type** | **string**| type | [optional] 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 

### Return type

[**PageDataEntityView**](PageDataEntityView.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="saveentityviewusingpost"></a>
# **SaveEntityViewUsingPOST**
> EntityView SaveEntityViewUsingPOST (EntityView entityView)

saveEntityView

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SaveEntityViewUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityViewControllerApi();
            var entityView = new EntityView(); // EntityView | entityView

            try
            {
                // saveEntityView
                EntityView result = apiInstance.SaveEntityViewUsingPOST(entityView);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityViewControllerApi.SaveEntityViewUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entityView** | [**EntityView**](EntityView.md)| entityView | 

### Return type

[**EntityView**](EntityView.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="unassignentityviewfromcustomerusingdelete"></a>
# **UnassignEntityViewFromCustomerUsingDELETE**
> EntityView UnassignEntityViewFromCustomerUsingDELETE (string entityViewId)

unassignEntityViewFromCustomer

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class UnassignEntityViewFromCustomerUsingDELETEExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityViewControllerApi();
            var entityViewId = entityViewId_example;  // string | entityViewId

            try
            {
                // unassignEntityViewFromCustomer
                EntityView result = apiInstance.UnassignEntityViewFromCustomerUsingDELETE(entityViewId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityViewControllerApi.UnassignEntityViewFromCustomerUsingDELETE: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entityViewId** | **string**| entityViewId | 

### Return type

[**EntityView**](EntityView.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

