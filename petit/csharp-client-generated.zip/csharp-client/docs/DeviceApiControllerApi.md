# IO.Swagger.Api.DeviceApiControllerApi

All URIs are relative to *https://192.168.0.9:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ClaimDeviceUsingPOST**](DeviceApiControllerApi.md#claimdeviceusingpost) | **POST** /api/v1/{deviceToken}/claim | claimDevice
[**GetDeviceAttributesUsingGET**](DeviceApiControllerApi.md#getdeviceattributesusingget) | **GET** /api/v1/{deviceToken}/attributes{?clientKeys,sharedKeys} | getDeviceAttributes
[**PostDeviceAttributesUsingPOST**](DeviceApiControllerApi.md#postdeviceattributesusingpost) | **POST** /api/v1/{deviceToken}/attributes | postDeviceAttributes
[**PostRpcRequestUsingPOST**](DeviceApiControllerApi.md#postrpcrequestusingpost) | **POST** /api/v1/{deviceToken}/rpc | postRpcRequest
[**PostTelemetryUsingPOST**](DeviceApiControllerApi.md#posttelemetryusingpost) | **POST** /api/v1/{deviceToken}/telemetry | postTelemetry
[**ProvisionDeviceUsingPOST**](DeviceApiControllerApi.md#provisiondeviceusingpost) | **POST** /api/v1/provision | provisionDevice
[**ReplyToCommandUsingPOST**](DeviceApiControllerApi.md#replytocommandusingpost) | **POST** /api/v1/{deviceToken}/rpc/{requestId} | replyToCommand
[**SubscribeToAttributesUsingGET**](DeviceApiControllerApi.md#subscribetoattributesusingget) | **GET** /api/v1/{deviceToken}/attributes/updates{?timeout} | subscribeToAttributes
[**SubscribeToCommandsUsingGET**](DeviceApiControllerApi.md#subscribetocommandsusingget) | **GET** /api/v1/{deviceToken}/rpc{?timeout} | subscribeToCommands


<a name="claimdeviceusingpost"></a>
# **ClaimDeviceUsingPOST**
> DeferredResultResponseEntity ClaimDeviceUsingPOST (string deviceToken, string json = null)

claimDevice

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ClaimDeviceUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceApiControllerApi();
            var deviceToken = deviceToken_example;  // string | deviceToken
            var json = json_example;  // string | json (optional) 

            try
            {
                // claimDevice
                DeferredResultResponseEntity result = apiInstance.ClaimDeviceUsingPOST(deviceToken, json);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceApiControllerApi.ClaimDeviceUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceToken** | **string**| deviceToken | 
 **json** | **string**| json | [optional] 

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getdeviceattributesusingget"></a>
# **GetDeviceAttributesUsingGET**
> DeferredResultResponseEntity GetDeviceAttributesUsingGET (string deviceToken, string clientKeys = null, string sharedKeys = null)

getDeviceAttributes

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetDeviceAttributesUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceApiControllerApi();
            var deviceToken = deviceToken_example;  // string | deviceToken
            var clientKeys = clientKeys_example;  // string | clientKeys (optional) 
            var sharedKeys = sharedKeys_example;  // string | sharedKeys (optional) 

            try
            {
                // getDeviceAttributes
                DeferredResultResponseEntity result = apiInstance.GetDeviceAttributesUsingGET(deviceToken, clientKeys, sharedKeys);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceApiControllerApi.GetDeviceAttributesUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceToken** | **string**| deviceToken | 
 **clientKeys** | **string**| clientKeys | [optional] 
 **sharedKeys** | **string**| sharedKeys | [optional] 

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="postdeviceattributesusingpost"></a>
# **PostDeviceAttributesUsingPOST**
> DeferredResultResponseEntity PostDeviceAttributesUsingPOST (string deviceToken, string json)

postDeviceAttributes

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PostDeviceAttributesUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceApiControllerApi();
            var deviceToken = deviceToken_example;  // string | deviceToken
            var json = json_example;  // string | json

            try
            {
                // postDeviceAttributes
                DeferredResultResponseEntity result = apiInstance.PostDeviceAttributesUsingPOST(deviceToken, json);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceApiControllerApi.PostDeviceAttributesUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceToken** | **string**| deviceToken | 
 **json** | **string**| json | 

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="postrpcrequestusingpost"></a>
# **PostRpcRequestUsingPOST**
> DeferredResultResponseEntity PostRpcRequestUsingPOST (string deviceToken, string json)

postRpcRequest

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PostRpcRequestUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceApiControllerApi();
            var deviceToken = deviceToken_example;  // string | deviceToken
            var json = json_example;  // string | json

            try
            {
                // postRpcRequest
                DeferredResultResponseEntity result = apiInstance.PostRpcRequestUsingPOST(deviceToken, json);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceApiControllerApi.PostRpcRequestUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceToken** | **string**| deviceToken | 
 **json** | **string**| json | 

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="posttelemetryusingpost"></a>
# **PostTelemetryUsingPOST**
> DeferredResultResponseEntity PostTelemetryUsingPOST (string deviceToken, string json)

postTelemetry

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PostTelemetryUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceApiControllerApi();
            var deviceToken = deviceToken_example;  // string | deviceToken
            var json = json_example;  // string | json

            try
            {
                // postTelemetry
                DeferredResultResponseEntity result = apiInstance.PostTelemetryUsingPOST(deviceToken, json);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceApiControllerApi.PostTelemetryUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceToken** | **string**| deviceToken | 
 **json** | **string**| json | 

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="provisiondeviceusingpost"></a>
# **ProvisionDeviceUsingPOST**
> DeferredResultResponseEntity ProvisionDeviceUsingPOST (string json)

provisionDevice

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProvisionDeviceUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceApiControllerApi();
            var json = json_example;  // string | json

            try
            {
                // provisionDevice
                DeferredResultResponseEntity result = apiInstance.ProvisionDeviceUsingPOST(json);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceApiControllerApi.ProvisionDeviceUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **json** | **string**| json | 

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="replytocommandusingpost"></a>
# **ReplyToCommandUsingPOST**
> DeferredResultResponseEntity ReplyToCommandUsingPOST (string deviceToken, int? requestId, string json)

replyToCommand

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ReplyToCommandUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceApiControllerApi();
            var deviceToken = deviceToken_example;  // string | deviceToken
            var requestId = 56;  // int? | requestId
            var json = json_example;  // string | json

            try
            {
                // replyToCommand
                DeferredResultResponseEntity result = apiInstance.ReplyToCommandUsingPOST(deviceToken, requestId, json);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceApiControllerApi.ReplyToCommandUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceToken** | **string**| deviceToken | 
 **requestId** | **int?**| requestId | 
 **json** | **string**| json | 

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="subscribetoattributesusingget"></a>
# **SubscribeToAttributesUsingGET**
> DeferredResultResponseEntity SubscribeToAttributesUsingGET (string deviceToken, long? timeout = null)

subscribeToAttributes

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SubscribeToAttributesUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceApiControllerApi();
            var deviceToken = deviceToken_example;  // string | deviceToken
            var timeout = 789;  // long? | timeout (optional)  (default to 0)

            try
            {
                // subscribeToAttributes
                DeferredResultResponseEntity result = apiInstance.SubscribeToAttributesUsingGET(deviceToken, timeout);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceApiControllerApi.SubscribeToAttributesUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceToken** | **string**| deviceToken | 
 **timeout** | **long?**| timeout | [optional] [default to 0]

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="subscribetocommandsusingget"></a>
# **SubscribeToCommandsUsingGET**
> DeferredResultResponseEntity SubscribeToCommandsUsingGET (string deviceToken, long? timeout = null)

subscribeToCommands

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SubscribeToCommandsUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceApiControllerApi();
            var deviceToken = deviceToken_example;  // string | deviceToken
            var timeout = 789;  // long? | timeout (optional)  (default to 0)

            try
            {
                // subscribeToCommands
                DeferredResultResponseEntity result = apiInstance.SubscribeToCommandsUsingGET(deviceToken, timeout);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceApiControllerApi.SubscribeToCommandsUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceToken** | **string**| deviceToken | 
 **timeout** | **long?**| timeout | [optional] [default to 0]

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

