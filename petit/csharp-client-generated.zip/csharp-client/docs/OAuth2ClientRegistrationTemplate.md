# IO.Swagger.Model.OAuth2ClientRegistrationTemplate
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccessTokenUri** | **string** |  | [optional] 
**AdditionalInfo** | **string** |  | [optional] 
**AuthorizationUri** | **string** |  | [optional] 
**ClientAuthenticationMethod** | **string** |  | [optional] 
**Comment** | **string** |  | [optional] 
**CreatedTime** | **long?** |  | [optional] 
**HelpLink** | **string** |  | [optional] 
**Id** | [**OAuth2ClientRegistrationTemplateId**](OAuth2ClientRegistrationTemplateId.md) |  | [optional] 
**JwkSetUri** | **string** |  | [optional] 
**LoginButtonIcon** | **string** |  | [optional] 
**LoginButtonLabel** | **string** |  | [optional] 
**MapperConfig** | [**OAuth2MapperConfig**](OAuth2MapperConfig.md) |  | [optional] 
**Name** | **string** |  | [optional] 
**ProviderId** | **string** |  | [optional] 
**Scope** | **List&lt;string&gt;** |  | [optional] 
**UserInfoUri** | **string** |  | [optional] 
**UserNameAttributeName** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

