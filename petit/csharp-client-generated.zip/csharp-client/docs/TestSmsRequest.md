# IO.Swagger.Model.TestSmsRequest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Message** | **string** |  | [optional] 
**NumberTo** | **string** |  | [optional] 
**ProviderConfiguration** | [**SmsProviderConfiguration**](SmsProviderConfiguration.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

