# IO.Swagger.Model.DeviceProfile
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreatedTime** | **long?** |  | [optional] 
**Default** | **bool?** |  | [optional] 
**DefaultQueueName** | **string** |  | [optional] 
**DefaultRuleChainId** | [**RuleChainId**](RuleChainId.md) |  | [optional] 
**Description** | **string** |  | [optional] 
**Id** | [**DeviceProfileId**](DeviceProfileId.md) |  | [optional] 
**Name** | **string** |  | [optional] 
**ProfileData** | [**DeviceProfileData**](DeviceProfileData.md) |  | [optional] 
**ProvisionDeviceKey** | **string** |  | [optional] 
**ProvisionType** | **string** |  | [optional] 
**TenantId** | [**TenantId**](TenantId.md) |  | [optional] 
**TransportType** | **string** |  | [optional] 
**Type** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

