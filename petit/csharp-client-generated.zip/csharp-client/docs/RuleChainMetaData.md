# IO.Swagger.Model.RuleChainMetaData
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Connections** | [**List&lt;NodeConnectionInfo&gt;**](NodeConnectionInfo.md) |  | [optional] 
**FirstNodeIndex** | **int?** |  | [optional] 
**Nodes** | [**List&lt;RuleNode&gt;**](RuleNode.md) |  | [optional] 
**RuleChainConnections** | [**List&lt;RuleChainConnectionInfo&gt;**](RuleChainConnectionInfo.md) |  | [optional] 
**RuleChainId** | [**RuleChainId**](RuleChainId.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

