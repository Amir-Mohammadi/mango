# IO.Swagger.Model.ResponseEntity
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Body** | **Object** |  | [optional] 
**StatusCode** | **string** |  | [optional] 
**StatusCodeValue** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

