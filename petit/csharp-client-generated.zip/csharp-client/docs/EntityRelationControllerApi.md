# IO.Swagger.Api.EntityRelationControllerApi

All URIs are relative to *https://192.168.0.9:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**DeleteRelationUsingDELETE**](EntityRelationControllerApi.md#deleterelationusingdelete) | **DELETE** /api/relation{?relationTypeGroup,fromId,fromType,relationType,toId,toType} | deleteRelation
[**DeleteRelationsUsingDELETE**](EntityRelationControllerApi.md#deleterelationsusingdelete) | **DELETE** /api/relations{?entityId,entityType,id,type} | deleteRelations
[**FindByFromUsingGET**](EntityRelationControllerApi.md#findbyfromusingget) | **GET** /api/relations{?relationTypeGroup,fromId,fromType,relationType} | findByFrom
[**FindByFromUsingGET1**](EntityRelationControllerApi.md#findbyfromusingget1) | **GET** /api/relations{?relationTypeGroup,fromId,fromType} | findByFrom
[**FindByQueryUsingPOST2**](EntityRelationControllerApi.md#findbyqueryusingpost2) | **POST** /api/relations | findByQuery
[**FindByToUsingGET**](EntityRelationControllerApi.md#findbytousingget) | **GET** /api/relations{?relationTypeGroup,toId,toType,relationType} | findByTo
[**FindByToUsingGET1**](EntityRelationControllerApi.md#findbytousingget1) | **GET** /api/relations{?relationTypeGroup,toId,toType} | findByTo
[**FindInfoByFromUsingGET**](EntityRelationControllerApi.md#findinfobyfromusingget) | **GET** /api/relations/info{?relationTypeGroup,fromId,fromType} | findInfoByFrom
[**FindInfoByQueryUsingPOST**](EntityRelationControllerApi.md#findinfobyqueryusingpost) | **POST** /api/relations/info | findInfoByQuery
[**FindInfoByToUsingGET**](EntityRelationControllerApi.md#findinfobytousingget) | **GET** /api/relations/info{?relationTypeGroup,toId,toType} | findInfoByTo
[**GetRelationUsingGET**](EntityRelationControllerApi.md#getrelationusingget) | **GET** /api/relation{?relationTypeGroup,fromId,fromType,relationType,toId,toType} | getRelation
[**SaveRelationUsingPOST**](EntityRelationControllerApi.md#saverelationusingpost) | **POST** /api/relation | saveRelation


<a name="deleterelationusingdelete"></a>
# **DeleteRelationUsingDELETE**
> void DeleteRelationUsingDELETE (string fromId, string fromType, string relationType, string toId, string toType, string relationTypeGroup = null)

deleteRelation

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeleteRelationUsingDELETEExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityRelationControllerApi();
            var fromId = fromId_example;  // string | fromId
            var fromType = fromType_example;  // string | fromType
            var relationType = relationType_example;  // string | relationType
            var toId = toId_example;  // string | toId
            var toType = toType_example;  // string | toType
            var relationTypeGroup = relationTypeGroup_example;  // string | relationTypeGroup (optional) 

            try
            {
                // deleteRelation
                apiInstance.DeleteRelationUsingDELETE(fromId, fromType, relationType, toId, toType, relationTypeGroup);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityRelationControllerApi.DeleteRelationUsingDELETE: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **fromId** | **string**| fromId | 
 **fromType** | **string**| fromType | 
 **relationType** | **string**| relationType | 
 **toId** | **string**| toId | 
 **toType** | **string**| toType | 
 **relationTypeGroup** | **string**| relationTypeGroup | [optional] 

### Return type

void (empty response body)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="deleterelationsusingdelete"></a>
# **DeleteRelationsUsingDELETE**
> void DeleteRelationsUsingDELETE (string entityId, string entityType, string id, string type)

deleteRelations

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeleteRelationsUsingDELETEExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityRelationControllerApi();
            var entityId = entityId_example;  // string | entityId
            var entityType = entityType_example;  // string | entityType
            var id = id_example;  // string | 
            var type = type_example;  // string | 

            try
            {
                // deleteRelations
                apiInstance.DeleteRelationsUsingDELETE(entityId, entityType, id, type);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityRelationControllerApi.DeleteRelationsUsingDELETE: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entityId** | **string**| entityId | 
 **entityType** | **string**| entityType | 
 **id** | **string**|  | 
 **type** | **string**|  | 

### Return type

void (empty response body)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="findbyfromusingget"></a>
# **FindByFromUsingGET**
> List<EntityRelation> FindByFromUsingGET (string fromId, string fromType, string relationType, string relationTypeGroup = null)

findByFrom

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class FindByFromUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityRelationControllerApi();
            var fromId = fromId_example;  // string | fromId
            var fromType = fromType_example;  // string | fromType
            var relationType = relationType_example;  // string | relationType
            var relationTypeGroup = relationTypeGroup_example;  // string | relationTypeGroup (optional) 

            try
            {
                // findByFrom
                List&lt;EntityRelation&gt; result = apiInstance.FindByFromUsingGET(fromId, fromType, relationType, relationTypeGroup);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityRelationControllerApi.FindByFromUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **fromId** | **string**| fromId | 
 **fromType** | **string**| fromType | 
 **relationType** | **string**| relationType | 
 **relationTypeGroup** | **string**| relationTypeGroup | [optional] 

### Return type

[**List<EntityRelation>**](EntityRelation.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="findbyfromusingget1"></a>
# **FindByFromUsingGET1**
> List<EntityRelation> FindByFromUsingGET1 (string fromId, string fromType, string relationTypeGroup = null)

findByFrom

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class FindByFromUsingGET1Example
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityRelationControllerApi();
            var fromId = fromId_example;  // string | fromId
            var fromType = fromType_example;  // string | fromType
            var relationTypeGroup = relationTypeGroup_example;  // string | relationTypeGroup (optional) 

            try
            {
                // findByFrom
                List&lt;EntityRelation&gt; result = apiInstance.FindByFromUsingGET1(fromId, fromType, relationTypeGroup);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityRelationControllerApi.FindByFromUsingGET1: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **fromId** | **string**| fromId | 
 **fromType** | **string**| fromType | 
 **relationTypeGroup** | **string**| relationTypeGroup | [optional] 

### Return type

[**List<EntityRelation>**](EntityRelation.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="findbyqueryusingpost2"></a>
# **FindByQueryUsingPOST2**
> List<EntityRelation> FindByQueryUsingPOST2 (EntityRelationsQuery query)

findByQuery

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class FindByQueryUsingPOST2Example
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityRelationControllerApi();
            var query = new EntityRelationsQuery(); // EntityRelationsQuery | query

            try
            {
                // findByQuery
                List&lt;EntityRelation&gt; result = apiInstance.FindByQueryUsingPOST2(query);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityRelationControllerApi.FindByQueryUsingPOST2: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | [**EntityRelationsQuery**](EntityRelationsQuery.md)| query | 

### Return type

[**List<EntityRelation>**](EntityRelation.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="findbytousingget"></a>
# **FindByToUsingGET**
> List<EntityRelation> FindByToUsingGET (string toId, string toType, string relationType, string relationTypeGroup = null)

findByTo

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class FindByToUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityRelationControllerApi();
            var toId = toId_example;  // string | toId
            var toType = toType_example;  // string | toType
            var relationType = relationType_example;  // string | relationType
            var relationTypeGroup = relationTypeGroup_example;  // string | relationTypeGroup (optional) 

            try
            {
                // findByTo
                List&lt;EntityRelation&gt; result = apiInstance.FindByToUsingGET(toId, toType, relationType, relationTypeGroup);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityRelationControllerApi.FindByToUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **toId** | **string**| toId | 
 **toType** | **string**| toType | 
 **relationType** | **string**| relationType | 
 **relationTypeGroup** | **string**| relationTypeGroup | [optional] 

### Return type

[**List<EntityRelation>**](EntityRelation.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="findbytousingget1"></a>
# **FindByToUsingGET1**
> List<EntityRelation> FindByToUsingGET1 (string toId, string toType, string relationTypeGroup = null)

findByTo

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class FindByToUsingGET1Example
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityRelationControllerApi();
            var toId = toId_example;  // string | toId
            var toType = toType_example;  // string | toType
            var relationTypeGroup = relationTypeGroup_example;  // string | relationTypeGroup (optional) 

            try
            {
                // findByTo
                List&lt;EntityRelation&gt; result = apiInstance.FindByToUsingGET1(toId, toType, relationTypeGroup);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityRelationControllerApi.FindByToUsingGET1: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **toId** | **string**| toId | 
 **toType** | **string**| toType | 
 **relationTypeGroup** | **string**| relationTypeGroup | [optional] 

### Return type

[**List<EntityRelation>**](EntityRelation.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="findinfobyfromusingget"></a>
# **FindInfoByFromUsingGET**
> List<EntityRelationInfo> FindInfoByFromUsingGET (string fromId, string fromType, string relationTypeGroup = null)

findInfoByFrom

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class FindInfoByFromUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityRelationControllerApi();
            var fromId = fromId_example;  // string | fromId
            var fromType = fromType_example;  // string | fromType
            var relationTypeGroup = relationTypeGroup_example;  // string | relationTypeGroup (optional) 

            try
            {
                // findInfoByFrom
                List&lt;EntityRelationInfo&gt; result = apiInstance.FindInfoByFromUsingGET(fromId, fromType, relationTypeGroup);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityRelationControllerApi.FindInfoByFromUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **fromId** | **string**| fromId | 
 **fromType** | **string**| fromType | 
 **relationTypeGroup** | **string**| relationTypeGroup | [optional] 

### Return type

[**List<EntityRelationInfo>**](EntityRelationInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="findinfobyqueryusingpost"></a>
# **FindInfoByQueryUsingPOST**
> List<EntityRelationInfo> FindInfoByQueryUsingPOST (EntityRelationsQuery query)

findInfoByQuery

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class FindInfoByQueryUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityRelationControllerApi();
            var query = new EntityRelationsQuery(); // EntityRelationsQuery | query

            try
            {
                // findInfoByQuery
                List&lt;EntityRelationInfo&gt; result = apiInstance.FindInfoByQueryUsingPOST(query);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityRelationControllerApi.FindInfoByQueryUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | [**EntityRelationsQuery**](EntityRelationsQuery.md)| query | 

### Return type

[**List<EntityRelationInfo>**](EntityRelationInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="findinfobytousingget"></a>
# **FindInfoByToUsingGET**
> List<EntityRelationInfo> FindInfoByToUsingGET (string toId, string toType, string relationTypeGroup = null)

findInfoByTo

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class FindInfoByToUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityRelationControllerApi();
            var toId = toId_example;  // string | toId
            var toType = toType_example;  // string | toType
            var relationTypeGroup = relationTypeGroup_example;  // string | relationTypeGroup (optional) 

            try
            {
                // findInfoByTo
                List&lt;EntityRelationInfo&gt; result = apiInstance.FindInfoByToUsingGET(toId, toType, relationTypeGroup);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityRelationControllerApi.FindInfoByToUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **toId** | **string**| toId | 
 **toType** | **string**| toType | 
 **relationTypeGroup** | **string**| relationTypeGroup | [optional] 

### Return type

[**List<EntityRelationInfo>**](EntityRelationInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getrelationusingget"></a>
# **GetRelationUsingGET**
> EntityRelation GetRelationUsingGET (string fromId, string fromType, string relationType, string toId, string toType, string relationTypeGroup = null)

getRelation

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetRelationUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityRelationControllerApi();
            var fromId = fromId_example;  // string | fromId
            var fromType = fromType_example;  // string | fromType
            var relationType = relationType_example;  // string | relationType
            var toId = toId_example;  // string | toId
            var toType = toType_example;  // string | toType
            var relationTypeGroup = relationTypeGroup_example;  // string | relationTypeGroup (optional) 

            try
            {
                // getRelation
                EntityRelation result = apiInstance.GetRelationUsingGET(fromId, fromType, relationType, toId, toType, relationTypeGroup);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityRelationControllerApi.GetRelationUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **fromId** | **string**| fromId | 
 **fromType** | **string**| fromType | 
 **relationType** | **string**| relationType | 
 **toId** | **string**| toId | 
 **toType** | **string**| toType | 
 **relationTypeGroup** | **string**| relationTypeGroup | [optional] 

### Return type

[**EntityRelation**](EntityRelation.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="saverelationusingpost"></a>
# **SaveRelationUsingPOST**
> void SaveRelationUsingPOST (EntityRelation relation)

saveRelation

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SaveRelationUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityRelationControllerApi();
            var relation = new EntityRelation(); // EntityRelation | relation

            try
            {
                // saveRelation
                apiInstance.SaveRelationUsingPOST(relation);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityRelationControllerApi.SaveRelationUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **relation** | [**EntityRelation**](EntityRelation.md)| relation | 

### Return type

void (empty response body)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

