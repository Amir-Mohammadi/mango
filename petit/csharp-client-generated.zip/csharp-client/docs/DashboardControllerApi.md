# IO.Swagger.Api.DashboardControllerApi

All URIs are relative to *https://192.168.0.9:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AddDashboardCustomersUsingPOST**](DashboardControllerApi.md#adddashboardcustomersusingpost) | **POST** /api/dashboard/{dashboardId}/customers/add | addDashboardCustomers
[**AssignDashboardToCustomerUsingPOST**](DashboardControllerApi.md#assigndashboardtocustomerusingpost) | **POST** /api/customer/{customerId}/dashboard/{dashboardId} | assignDashboardToCustomer
[**AssignDashboardToPublicCustomerUsingPOST**](DashboardControllerApi.md#assigndashboardtopubliccustomerusingpost) | **POST** /api/customer/public/dashboard/{dashboardId} | assignDashboardToPublicCustomer
[**DeleteDashboardUsingDELETE**](DashboardControllerApi.md#deletedashboardusingdelete) | **DELETE** /api/dashboard/{dashboardId} | deleteDashboard
[**GetCustomerDashboardsUsingGET**](DashboardControllerApi.md#getcustomerdashboardsusingget) | **GET** /api/customer/{customerId}/dashboards{?textSearch,sortProperty,sortOrder,pageSize,page} | getCustomerDashboards
[**GetDashboardByIdUsingGET**](DashboardControllerApi.md#getdashboardbyidusingget) | **GET** /api/dashboard/{dashboardId} | getDashboardById
[**GetDashboardInfoByIdUsingGET**](DashboardControllerApi.md#getdashboardinfobyidusingget) | **GET** /api/dashboard/info/{dashboardId} | getDashboardInfoById
[**GetHomeDashboardUsingGET**](DashboardControllerApi.md#gethomedashboardusingget) | **GET** /api/dashboard/home | getHomeDashboard
[**GetMaxDatapointsLimitUsingGET**](DashboardControllerApi.md#getmaxdatapointslimitusingget) | **GET** /api/dashboard/maxDatapointsLimit | getMaxDatapointsLimit
[**GetServerTimeUsingGET**](DashboardControllerApi.md#getservertimeusingget) | **GET** /api/dashboard/serverTime | getServerTime
[**GetTenantDashboardsUsingGET**](DashboardControllerApi.md#gettenantdashboardsusingget) | **GET** /api/tenant/dashboards{?textSearch,sortProperty,sortOrder,pageSize,page} | getTenantDashboards
[**GetTenantDashboardsUsingGET1**](DashboardControllerApi.md#gettenantdashboardsusingget1) | **GET** /api/tenant/{tenantId}/dashboards{?textSearch,sortProperty,sortOrder,pageSize,page} | getTenantDashboards
[**GetTenantHomeDashboardInfoUsingGET**](DashboardControllerApi.md#gettenanthomedashboardinfousingget) | **GET** /api/tenant/dashboard/home/info | getTenantHomeDashboardInfo
[**RemoveDashboardCustomersUsingPOST**](DashboardControllerApi.md#removedashboardcustomersusingpost) | **POST** /api/dashboard/{dashboardId}/customers/remove | removeDashboardCustomers
[**SaveDashboardUsingPOST**](DashboardControllerApi.md#savedashboardusingpost) | **POST** /api/dashboard | saveDashboard
[**SetTenantHomeDashboardInfoUsingPOST**](DashboardControllerApi.md#settenanthomedashboardinfousingpost) | **POST** /api/tenant/dashboard/home/info | setTenantHomeDashboardInfo
[**UnassignDashboardFromCustomerUsingDELETE**](DashboardControllerApi.md#unassigndashboardfromcustomerusingdelete) | **DELETE** /api/customer/{customerId}/dashboard/{dashboardId} | unassignDashboardFromCustomer
[**UnassignDashboardFromPublicCustomerUsingDELETE**](DashboardControllerApi.md#unassigndashboardfrompubliccustomerusingdelete) | **DELETE** /api/customer/public/dashboard/{dashboardId} | unassignDashboardFromPublicCustomer
[**UpdateDashboardCustomersUsingPOST**](DashboardControllerApi.md#updatedashboardcustomersusingpost) | **POST** /api/dashboard/{dashboardId}/customers | updateDashboardCustomers


<a name="adddashboardcustomersusingpost"></a>
# **AddDashboardCustomersUsingPOST**
> Dashboard AddDashboardCustomersUsingPOST (string dashboardId, List<string> strCustomerIds)

addDashboardCustomers

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AddDashboardCustomersUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DashboardControllerApi();
            var dashboardId = dashboardId_example;  // string | dashboardId
            var strCustomerIds = ;  // List<string> | strCustomerIds

            try
            {
                // addDashboardCustomers
                Dashboard result = apiInstance.AddDashboardCustomersUsingPOST(dashboardId, strCustomerIds);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DashboardControllerApi.AddDashboardCustomersUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **dashboardId** | **string**| dashboardId | 
 **strCustomerIds** | **List&lt;string&gt;**| strCustomerIds | 

### Return type

[**Dashboard**](Dashboard.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="assigndashboardtocustomerusingpost"></a>
# **AssignDashboardToCustomerUsingPOST**
> Dashboard AssignDashboardToCustomerUsingPOST (string customerId, string dashboardId)

assignDashboardToCustomer

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AssignDashboardToCustomerUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DashboardControllerApi();
            var customerId = customerId_example;  // string | customerId
            var dashboardId = dashboardId_example;  // string | dashboardId

            try
            {
                // assignDashboardToCustomer
                Dashboard result = apiInstance.AssignDashboardToCustomerUsingPOST(customerId, dashboardId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DashboardControllerApi.AssignDashboardToCustomerUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customerId** | **string**| customerId | 
 **dashboardId** | **string**| dashboardId | 

### Return type

[**Dashboard**](Dashboard.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="assigndashboardtopubliccustomerusingpost"></a>
# **AssignDashboardToPublicCustomerUsingPOST**
> Dashboard AssignDashboardToPublicCustomerUsingPOST (string dashboardId)

assignDashboardToPublicCustomer

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AssignDashboardToPublicCustomerUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DashboardControllerApi();
            var dashboardId = dashboardId_example;  // string | dashboardId

            try
            {
                // assignDashboardToPublicCustomer
                Dashboard result = apiInstance.AssignDashboardToPublicCustomerUsingPOST(dashboardId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DashboardControllerApi.AssignDashboardToPublicCustomerUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **dashboardId** | **string**| dashboardId | 

### Return type

[**Dashboard**](Dashboard.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="deletedashboardusingdelete"></a>
# **DeleteDashboardUsingDELETE**
> void DeleteDashboardUsingDELETE (string dashboardId)

deleteDashboard

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeleteDashboardUsingDELETEExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DashboardControllerApi();
            var dashboardId = dashboardId_example;  // string | dashboardId

            try
            {
                // deleteDashboard
                apiInstance.DeleteDashboardUsingDELETE(dashboardId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DashboardControllerApi.DeleteDashboardUsingDELETE: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **dashboardId** | **string**| dashboardId | 

### Return type

void (empty response body)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getcustomerdashboardsusingget"></a>
# **GetCustomerDashboardsUsingGET**
> PageDataDashboardInfo GetCustomerDashboardsUsingGET (string customerId, string pageSize, string page, string textSearch = null, string sortProperty = null, string sortOrder = null)

getCustomerDashboards

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetCustomerDashboardsUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DashboardControllerApi();
            var customerId = customerId_example;  // string | customerId
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 

            try
            {
                // getCustomerDashboards
                PageDataDashboardInfo result = apiInstance.GetCustomerDashboardsUsingGET(customerId, pageSize, page, textSearch, sortProperty, sortOrder);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DashboardControllerApi.GetCustomerDashboardsUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customerId** | **string**| customerId | 
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 

### Return type

[**PageDataDashboardInfo**](PageDataDashboardInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getdashboardbyidusingget"></a>
# **GetDashboardByIdUsingGET**
> Dashboard GetDashboardByIdUsingGET (string dashboardId)

getDashboardById

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetDashboardByIdUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DashboardControllerApi();
            var dashboardId = dashboardId_example;  // string | dashboardId

            try
            {
                // getDashboardById
                Dashboard result = apiInstance.GetDashboardByIdUsingGET(dashboardId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DashboardControllerApi.GetDashboardByIdUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **dashboardId** | **string**| dashboardId | 

### Return type

[**Dashboard**](Dashboard.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getdashboardinfobyidusingget"></a>
# **GetDashboardInfoByIdUsingGET**
> DashboardInfo GetDashboardInfoByIdUsingGET (string dashboardId)

getDashboardInfoById

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetDashboardInfoByIdUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DashboardControllerApi();
            var dashboardId = dashboardId_example;  // string | dashboardId

            try
            {
                // getDashboardInfoById
                DashboardInfo result = apiInstance.GetDashboardInfoByIdUsingGET(dashboardId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DashboardControllerApi.GetDashboardInfoByIdUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **dashboardId** | **string**| dashboardId | 

### Return type

[**DashboardInfo**](DashboardInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gethomedashboardusingget"></a>
# **GetHomeDashboardUsingGET**
> HomeDashboard GetHomeDashboardUsingGET ()

getHomeDashboard

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetHomeDashboardUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DashboardControllerApi();

            try
            {
                // getHomeDashboard
                HomeDashboard result = apiInstance.GetHomeDashboardUsingGET();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DashboardControllerApi.GetHomeDashboardUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**HomeDashboard**](HomeDashboard.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getmaxdatapointslimitusingget"></a>
# **GetMaxDatapointsLimitUsingGET**
> long? GetMaxDatapointsLimitUsingGET ()

getMaxDatapointsLimit

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetMaxDatapointsLimitUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DashboardControllerApi();

            try
            {
                // getMaxDatapointsLimit
                long? result = apiInstance.GetMaxDatapointsLimitUsingGET();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DashboardControllerApi.GetMaxDatapointsLimitUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

**long?**

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getservertimeusingget"></a>
# **GetServerTimeUsingGET**
> long? GetServerTimeUsingGET ()

getServerTime

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetServerTimeUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DashboardControllerApi();

            try
            {
                // getServerTime
                long? result = apiInstance.GetServerTimeUsingGET();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DashboardControllerApi.GetServerTimeUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

**long?**

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettenantdashboardsusingget"></a>
# **GetTenantDashboardsUsingGET**
> PageDataDashboardInfo GetTenantDashboardsUsingGET (string pageSize, string page, string textSearch = null, string sortProperty = null, string sortOrder = null)

getTenantDashboards

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTenantDashboardsUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DashboardControllerApi();
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 

            try
            {
                // getTenantDashboards
                PageDataDashboardInfo result = apiInstance.GetTenantDashboardsUsingGET(pageSize, page, textSearch, sortProperty, sortOrder);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DashboardControllerApi.GetTenantDashboardsUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 

### Return type

[**PageDataDashboardInfo**](PageDataDashboardInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettenantdashboardsusingget1"></a>
# **GetTenantDashboardsUsingGET1**
> PageDataDashboardInfo GetTenantDashboardsUsingGET1 (string tenantId, string pageSize, string page, string textSearch = null, string sortProperty = null, string sortOrder = null)

getTenantDashboards

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTenantDashboardsUsingGET1Example
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DashboardControllerApi();
            var tenantId = tenantId_example;  // string | tenantId
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 

            try
            {
                // getTenantDashboards
                PageDataDashboardInfo result = apiInstance.GetTenantDashboardsUsingGET1(tenantId, pageSize, page, textSearch, sortProperty, sortOrder);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DashboardControllerApi.GetTenantDashboardsUsingGET1: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenantId** | **string**| tenantId | 
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 

### Return type

[**PageDataDashboardInfo**](PageDataDashboardInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettenanthomedashboardinfousingget"></a>
# **GetTenantHomeDashboardInfoUsingGET**
> HomeDashboardInfo GetTenantHomeDashboardInfoUsingGET ()

getTenantHomeDashboardInfo

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTenantHomeDashboardInfoUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DashboardControllerApi();

            try
            {
                // getTenantHomeDashboardInfo
                HomeDashboardInfo result = apiInstance.GetTenantHomeDashboardInfoUsingGET();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DashboardControllerApi.GetTenantHomeDashboardInfoUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**HomeDashboardInfo**](HomeDashboardInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="removedashboardcustomersusingpost"></a>
# **RemoveDashboardCustomersUsingPOST**
> Dashboard RemoveDashboardCustomersUsingPOST (string dashboardId, List<string> strCustomerIds)

removeDashboardCustomers

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class RemoveDashboardCustomersUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DashboardControllerApi();
            var dashboardId = dashboardId_example;  // string | dashboardId
            var strCustomerIds = ;  // List<string> | strCustomerIds

            try
            {
                // removeDashboardCustomers
                Dashboard result = apiInstance.RemoveDashboardCustomersUsingPOST(dashboardId, strCustomerIds);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DashboardControllerApi.RemoveDashboardCustomersUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **dashboardId** | **string**| dashboardId | 
 **strCustomerIds** | **List&lt;string&gt;**| strCustomerIds | 

### Return type

[**Dashboard**](Dashboard.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="savedashboardusingpost"></a>
# **SaveDashboardUsingPOST**
> Dashboard SaveDashboardUsingPOST (Dashboard dashboard)

saveDashboard

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SaveDashboardUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DashboardControllerApi();
            var dashboard = new Dashboard(); // Dashboard | dashboard

            try
            {
                // saveDashboard
                Dashboard result = apiInstance.SaveDashboardUsingPOST(dashboard);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DashboardControllerApi.SaveDashboardUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **dashboard** | [**Dashboard**](Dashboard.md)| dashboard | 

### Return type

[**Dashboard**](Dashboard.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="settenanthomedashboardinfousingpost"></a>
# **SetTenantHomeDashboardInfoUsingPOST**
> void SetTenantHomeDashboardInfoUsingPOST (HomeDashboardInfo homeDashboardInfo)

setTenantHomeDashboardInfo

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SetTenantHomeDashboardInfoUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DashboardControllerApi();
            var homeDashboardInfo = new HomeDashboardInfo(); // HomeDashboardInfo | homeDashboardInfo

            try
            {
                // setTenantHomeDashboardInfo
                apiInstance.SetTenantHomeDashboardInfoUsingPOST(homeDashboardInfo);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DashboardControllerApi.SetTenantHomeDashboardInfoUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **homeDashboardInfo** | [**HomeDashboardInfo**](HomeDashboardInfo.md)| homeDashboardInfo | 

### Return type

void (empty response body)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="unassigndashboardfromcustomerusingdelete"></a>
# **UnassignDashboardFromCustomerUsingDELETE**
> Dashboard UnassignDashboardFromCustomerUsingDELETE (string customerId, string dashboardId)

unassignDashboardFromCustomer

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class UnassignDashboardFromCustomerUsingDELETEExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DashboardControllerApi();
            var customerId = customerId_example;  // string | customerId
            var dashboardId = dashboardId_example;  // string | dashboardId

            try
            {
                // unassignDashboardFromCustomer
                Dashboard result = apiInstance.UnassignDashboardFromCustomerUsingDELETE(customerId, dashboardId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DashboardControllerApi.UnassignDashboardFromCustomerUsingDELETE: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customerId** | **string**| customerId | 
 **dashboardId** | **string**| dashboardId | 

### Return type

[**Dashboard**](Dashboard.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="unassigndashboardfrompubliccustomerusingdelete"></a>
# **UnassignDashboardFromPublicCustomerUsingDELETE**
> Dashboard UnassignDashboardFromPublicCustomerUsingDELETE (string dashboardId)

unassignDashboardFromPublicCustomer

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class UnassignDashboardFromPublicCustomerUsingDELETEExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DashboardControllerApi();
            var dashboardId = dashboardId_example;  // string | dashboardId

            try
            {
                // unassignDashboardFromPublicCustomer
                Dashboard result = apiInstance.UnassignDashboardFromPublicCustomerUsingDELETE(dashboardId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DashboardControllerApi.UnassignDashboardFromPublicCustomerUsingDELETE: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **dashboardId** | **string**| dashboardId | 

### Return type

[**Dashboard**](Dashboard.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="updatedashboardcustomersusingpost"></a>
# **UpdateDashboardCustomersUsingPOST**
> Dashboard UpdateDashboardCustomersUsingPOST (string dashboardId, List<string> strCustomerIds = null)

updateDashboardCustomers

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class UpdateDashboardCustomersUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DashboardControllerApi();
            var dashboardId = dashboardId_example;  // string | dashboardId
            var strCustomerIds = ;  // List<string> | strCustomerIds (optional) 

            try
            {
                // updateDashboardCustomers
                Dashboard result = apiInstance.UpdateDashboardCustomersUsingPOST(dashboardId, strCustomerIds);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DashboardControllerApi.UpdateDashboardCustomersUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **dashboardId** | **string**| dashboardId | 
 **strCustomerIds** | **List&lt;string&gt;**| strCustomerIds | [optional] 

### Return type

[**Dashboard**](Dashboard.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

