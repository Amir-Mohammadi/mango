# IO.Swagger.Model.RelationEntityTypeFilter
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RelationType** | **string** |  | 
**EntityTypes** | **List&lt;string&gt;** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

