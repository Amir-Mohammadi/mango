# IO.Swagger.Api.AuthControllerApi

All URIs are relative to *https://192.168.0.9:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ActivateUserUsingPOST**](AuthControllerApi.md#activateuserusingpost) | **POST** /api/noauth/activate{?sendActivationMail} | activateUser
[**ChangePasswordUsingPOST**](AuthControllerApi.md#changepasswordusingpost) | **POST** /api/auth/changePassword | changePassword
[**CheckActivateTokenUsingGET**](AuthControllerApi.md#checkactivatetokenusingget) | **GET** /api/noauth/activate{?activateToken} | checkActivateToken
[**CheckResetTokenUsingGET**](AuthControllerApi.md#checkresettokenusingget) | **GET** /api/noauth/resetPassword{?resetToken} | checkResetToken
[**GetUserPasswordPolicyUsingGET**](AuthControllerApi.md#getuserpasswordpolicyusingget) | **GET** /api/noauth/userPasswordPolicy | getUserPasswordPolicy
[**GetUserUsingGET**](AuthControllerApi.md#getuserusingget) | **GET** /api/auth/user | getUser
[**LogoutUsingPOST**](AuthControllerApi.md#logoutusingpost) | **POST** /api/auth/logout | logout
[**RequestResetPasswordByEmailUsingPOST**](AuthControllerApi.md#requestresetpasswordbyemailusingpost) | **POST** /api/noauth/resetPasswordByEmail | requestResetPasswordByEmail
[**ResetPasswordUsingPOST**](AuthControllerApi.md#resetpasswordusingpost) | **POST** /api/noauth/resetPassword | resetPassword


<a name="activateuserusingpost"></a>
# **ActivateUserUsingPOST**
> string ActivateUserUsingPOST (string activateRequest, bool? sendActivationMail = null)

activateUser

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ActivateUserUsingPOSTExample
    {
        public void main()
        {
            var apiInstance = new AuthControllerApi();
            var activateRequest = activateRequest_example;  // string | activateRequest
            var sendActivationMail = true;  // bool? | sendActivationMail (optional)  (default to true)

            try
            {
                // activateUser
                string result = apiInstance.ActivateUserUsingPOST(activateRequest, sendActivationMail);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AuthControllerApi.ActivateUserUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **activateRequest** | **string**| activateRequest | 
 **sendActivationMail** | **bool?**| sendActivationMail | [optional] [default to true]

### Return type

**string**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="changepasswordusingpost"></a>
# **ChangePasswordUsingPOST**
> void ChangePasswordUsingPOST (string changePasswordRequest)

changePassword

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ChangePasswordUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AuthControllerApi();
            var changePasswordRequest = changePasswordRequest_example;  // string | changePasswordRequest

            try
            {
                // changePassword
                apiInstance.ChangePasswordUsingPOST(changePasswordRequest);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AuthControllerApi.ChangePasswordUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **changePasswordRequest** | **string**| changePasswordRequest | 

### Return type

void (empty response body)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="checkactivatetokenusingget"></a>
# **CheckActivateTokenUsingGET**
> string CheckActivateTokenUsingGET (string activateToken)

checkActivateToken

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CheckActivateTokenUsingGETExample
    {
        public void main()
        {
            var apiInstance = new AuthControllerApi();
            var activateToken = activateToken_example;  // string | activateToken

            try
            {
                // checkActivateToken
                string result = apiInstance.CheckActivateTokenUsingGET(activateToken);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AuthControllerApi.CheckActivateTokenUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **activateToken** | **string**| activateToken | 

### Return type

**string**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="checkresettokenusingget"></a>
# **CheckResetTokenUsingGET**
> string CheckResetTokenUsingGET (string resetToken)

checkResetToken

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CheckResetTokenUsingGETExample
    {
        public void main()
        {
            var apiInstance = new AuthControllerApi();
            var resetToken = resetToken_example;  // string | resetToken

            try
            {
                // checkResetToken
                string result = apiInstance.CheckResetTokenUsingGET(resetToken);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AuthControllerApi.CheckResetTokenUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **resetToken** | **string**| resetToken | 

### Return type

**string**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getuserpasswordpolicyusingget"></a>
# **GetUserPasswordPolicyUsingGET**
> UserPasswordPolicy GetUserPasswordPolicyUsingGET ()

getUserPasswordPolicy

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetUserPasswordPolicyUsingGETExample
    {
        public void main()
        {
            var apiInstance = new AuthControllerApi();

            try
            {
                // getUserPasswordPolicy
                UserPasswordPolicy result = apiInstance.GetUserPasswordPolicyUsingGET();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AuthControllerApi.GetUserPasswordPolicyUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**UserPasswordPolicy**](UserPasswordPolicy.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getuserusingget"></a>
# **GetUserUsingGET**
> User GetUserUsingGET ()

getUser

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetUserUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AuthControllerApi();

            try
            {
                // getUser
                User result = apiInstance.GetUserUsingGET();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AuthControllerApi.GetUserUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**User**](User.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="logoutusingpost"></a>
# **LogoutUsingPOST**
> void LogoutUsingPOST ()

logout

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class LogoutUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AuthControllerApi();

            try
            {
                // logout
                apiInstance.LogoutUsingPOST();
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AuthControllerApi.LogoutUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="requestresetpasswordbyemailusingpost"></a>
# **RequestResetPasswordByEmailUsingPOST**
> void RequestResetPasswordByEmailUsingPOST (string resetPasswordByEmailRequest)

requestResetPasswordByEmail

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class RequestResetPasswordByEmailUsingPOSTExample
    {
        public void main()
        {
            var apiInstance = new AuthControllerApi();
            var resetPasswordByEmailRequest = resetPasswordByEmailRequest_example;  // string | resetPasswordByEmailRequest

            try
            {
                // requestResetPasswordByEmail
                apiInstance.RequestResetPasswordByEmailUsingPOST(resetPasswordByEmailRequest);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AuthControllerApi.RequestResetPasswordByEmailUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **resetPasswordByEmailRequest** | **string**| resetPasswordByEmailRequest | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="resetpasswordusingpost"></a>
# **ResetPasswordUsingPOST**
> string ResetPasswordUsingPOST (string resetPasswordRequest)

resetPassword

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ResetPasswordUsingPOSTExample
    {
        public void main()
        {
            var apiInstance = new AuthControllerApi();
            var resetPasswordRequest = resetPasswordRequest_example;  // string | resetPasswordRequest

            try
            {
                // resetPassword
                string result = apiInstance.ResetPasswordUsingPOST(resetPasswordRequest);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AuthControllerApi.ResetPasswordUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **resetPasswordRequest** | **string**| resetPasswordRequest | 

### Return type

**string**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

