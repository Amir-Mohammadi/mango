# IO.Swagger.Model.EntityRelationsQuery
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Filters** | [**List&lt;RelationEntityTypeFilter&gt;**](RelationEntityTypeFilter.md) |  | [optional] 
**Parameters** | [**RelationsSearchParameters**](RelationsSearchParameters.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

