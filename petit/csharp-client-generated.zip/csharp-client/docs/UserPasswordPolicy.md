# IO.Swagger.Model.UserPasswordPolicy
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MinimumDigits** | **int?** |  | [optional] 
**MinimumLength** | **int?** |  | [optional] 
**MinimumLowercaseLetters** | **int?** |  | [optional] 
**MinimumSpecialCharacters** | **int?** |  | [optional] 
**MinimumUppercaseLetters** | **int?** |  | [optional] 
**PasswordExpirationPeriodDays** | **int?** |  | [optional] 
**PasswordReuseFrequencyDays** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

