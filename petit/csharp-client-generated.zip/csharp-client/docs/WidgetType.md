# IO.Swagger.Model.WidgetType
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Alias** | **string** |  | [optional] 
**BundleAlias** | **string** |  | [optional] 
**CreatedTime** | **long?** |  | [optional] 
**Descriptor** | **string** |  | [optional] 
**Id** | [**WidgetTypeId**](WidgetTypeId.md) |  | [optional] 
**Name** | **string** |  | [optional] 
**TenantId** | [**TenantId**](TenantId.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

