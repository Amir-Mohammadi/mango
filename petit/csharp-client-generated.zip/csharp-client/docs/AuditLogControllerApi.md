# IO.Swagger.Api.AuditLogControllerApi

All URIs are relative to *https://192.168.0.9:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetAuditLogsByCustomerIdUsingGET**](AuditLogControllerApi.md#getauditlogsbycustomeridusingget) | **GET** /api/audit/logs/customer/{customerId}{?textSearch,sortProperty,sortOrder,startTime,endTime,actionTypes,pageSize,page} | getAuditLogsByCustomerId
[**GetAuditLogsByEntityIdUsingGET**](AuditLogControllerApi.md#getauditlogsbyentityidusingget) | **GET** /api/audit/logs/entity/{entityType}/{entityId}{?textSearch,sortProperty,sortOrder,startTime,endTime,actionTypes,pageSize,page} | getAuditLogsByEntityId
[**GetAuditLogsByUserIdUsingGET**](AuditLogControllerApi.md#getauditlogsbyuseridusingget) | **GET** /api/audit/logs/user/{userId}{?textSearch,sortProperty,sortOrder,startTime,endTime,actionTypes,pageSize,page} | getAuditLogsByUserId
[**GetAuditLogsUsingGET**](AuditLogControllerApi.md#getauditlogsusingget) | **GET** /api/audit/logs{?textSearch,sortProperty,sortOrder,startTime,endTime,actionTypes,pageSize,page} | getAuditLogs


<a name="getauditlogsbycustomeridusingget"></a>
# **GetAuditLogsByCustomerIdUsingGET**
> PageDataAuditLog GetAuditLogsByCustomerIdUsingGET (string customerId, string pageSize, string page, string textSearch = null, string sortProperty = null, string sortOrder = null, long? startTime = null, long? endTime = null, string actionTypes = null)

getAuditLogsByCustomerId

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAuditLogsByCustomerIdUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AuditLogControllerApi();
            var customerId = customerId_example;  // string | customerId
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 
            var startTime = 789;  // long? | startTime (optional) 
            var endTime = 789;  // long? | endTime (optional) 
            var actionTypes = actionTypes_example;  // string | actionTypes (optional) 

            try
            {
                // getAuditLogsByCustomerId
                PageDataAuditLog result = apiInstance.GetAuditLogsByCustomerIdUsingGET(customerId, pageSize, page, textSearch, sortProperty, sortOrder, startTime, endTime, actionTypes);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AuditLogControllerApi.GetAuditLogsByCustomerIdUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customerId** | **string**| customerId | 
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 
 **startTime** | **long?**| startTime | [optional] 
 **endTime** | **long?**| endTime | [optional] 
 **actionTypes** | **string**| actionTypes | [optional] 

### Return type

[**PageDataAuditLog**](PageDataAuditLog.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getauditlogsbyentityidusingget"></a>
# **GetAuditLogsByEntityIdUsingGET**
> PageDataAuditLog GetAuditLogsByEntityIdUsingGET (string entityType, string entityId, string pageSize, string page, string textSearch = null, string sortProperty = null, string sortOrder = null, long? startTime = null, long? endTime = null, string actionTypes = null)

getAuditLogsByEntityId

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAuditLogsByEntityIdUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AuditLogControllerApi();
            var entityType = entityType_example;  // string | entityType
            var entityId = entityId_example;  // string | entityId
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 
            var startTime = 789;  // long? | startTime (optional) 
            var endTime = 789;  // long? | endTime (optional) 
            var actionTypes = actionTypes_example;  // string | actionTypes (optional) 

            try
            {
                // getAuditLogsByEntityId
                PageDataAuditLog result = apiInstance.GetAuditLogsByEntityIdUsingGET(entityType, entityId, pageSize, page, textSearch, sortProperty, sortOrder, startTime, endTime, actionTypes);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AuditLogControllerApi.GetAuditLogsByEntityIdUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entityType** | **string**| entityType | 
 **entityId** | **string**| entityId | 
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 
 **startTime** | **long?**| startTime | [optional] 
 **endTime** | **long?**| endTime | [optional] 
 **actionTypes** | **string**| actionTypes | [optional] 

### Return type

[**PageDataAuditLog**](PageDataAuditLog.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getauditlogsbyuseridusingget"></a>
# **GetAuditLogsByUserIdUsingGET**
> PageDataAuditLog GetAuditLogsByUserIdUsingGET (string userId, string pageSize, string page, string textSearch = null, string sortProperty = null, string sortOrder = null, long? startTime = null, long? endTime = null, string actionTypes = null)

getAuditLogsByUserId

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAuditLogsByUserIdUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AuditLogControllerApi();
            var userId = userId_example;  // string | userId
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 
            var startTime = 789;  // long? | startTime (optional) 
            var endTime = 789;  // long? | endTime (optional) 
            var actionTypes = actionTypes_example;  // string | actionTypes (optional) 

            try
            {
                // getAuditLogsByUserId
                PageDataAuditLog result = apiInstance.GetAuditLogsByUserIdUsingGET(userId, pageSize, page, textSearch, sortProperty, sortOrder, startTime, endTime, actionTypes);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AuditLogControllerApi.GetAuditLogsByUserIdUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userId** | **string**| userId | 
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 
 **startTime** | **long?**| startTime | [optional] 
 **endTime** | **long?**| endTime | [optional] 
 **actionTypes** | **string**| actionTypes | [optional] 

### Return type

[**PageDataAuditLog**](PageDataAuditLog.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getauditlogsusingget"></a>
# **GetAuditLogsUsingGET**
> PageDataAuditLog GetAuditLogsUsingGET (string pageSize, string page, string textSearch = null, string sortProperty = null, string sortOrder = null, long? startTime = null, long? endTime = null, string actionTypes = null)

getAuditLogs

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAuditLogsUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AuditLogControllerApi();
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 
            var startTime = 789;  // long? | startTime (optional) 
            var endTime = 789;  // long? | endTime (optional) 
            var actionTypes = actionTypes_example;  // string | actionTypes (optional) 

            try
            {
                // getAuditLogs
                PageDataAuditLog result = apiInstance.GetAuditLogsUsingGET(pageSize, page, textSearch, sortProperty, sortOrder, startTime, endTime, actionTypes);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AuditLogControllerApi.GetAuditLogsUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 
 **startTime** | **long?**| startTime | [optional] 
 **endTime** | **long?**| endTime | [optional] 
 **actionTypes** | **string**| actionTypes | [optional] 

### Return type

[**PageDataAuditLog**](PageDataAuditLog.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

