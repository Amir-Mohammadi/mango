# IO.Swagger.Model.User
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AdditionalInfo** | **string** |  | [optional] 
**Authority** | **string** |  | [optional] 
**CreatedTime** | **long?** |  | [optional] 
**CustomerId** | [**CustomerId**](CustomerId.md) |  | [optional] 
**Email** | **string** |  | [optional] 
**FirstName** | **string** |  | [optional] 
**Id** | [**UserId**](UserId.md) |  | [optional] 
**LastName** | **string** |  | [optional] 
**Name** | **string** |  | [optional] 
**TenantId** | [**TenantId**](TenantId.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

