# IO.Swagger.Model.EntityCountQuery
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EntityFilter** | [**EntityFilter**](EntityFilter.md) |  | [optional] 
**KeyFilters** | [**List&lt;KeyFilter&gt;**](KeyFilter.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

