# IO.Swagger.Api.RuleChainControllerApi

All URIs are relative to *https://192.168.0.9:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**DeleteRuleChainUsingDELETE**](RuleChainControllerApi.md#deleterulechainusingdelete) | **DELETE** /api/ruleChain/{ruleChainId} | deleteRuleChain
[**ExportRuleChainsUsingGET**](RuleChainControllerApi.md#exportrulechainsusingget) | **GET** /api/ruleChains/export{?limit} | exportRuleChains
[**GetLatestRuleNodeDebugInputUsingGET**](RuleChainControllerApi.md#getlatestrulenodedebuginputusingget) | **GET** /api/ruleNode/{ruleNodeId}/debugIn | getLatestRuleNodeDebugInput
[**GetRuleChainByIdUsingGET**](RuleChainControllerApi.md#getrulechainbyidusingget) | **GET** /api/ruleChain/{ruleChainId} | getRuleChainById
[**GetRuleChainMetaDataUsingGET**](RuleChainControllerApi.md#getrulechainmetadatausingget) | **GET** /api/ruleChain/{ruleChainId}/metadata | getRuleChainMetaData
[**GetRuleChainsUsingGET**](RuleChainControllerApi.md#getrulechainsusingget) | **GET** /api/ruleChains{?textSearch,sortProperty,sortOrder,pageSize,page} | getRuleChains
[**ImportRuleChainsUsingPOST**](RuleChainControllerApi.md#importrulechainsusingpost) | **POST** /api/ruleChains/import{?overwrite} | importRuleChains
[**SaveRuleChainMetaDataUsingPOST**](RuleChainControllerApi.md#saverulechainmetadatausingpost) | **POST** /api/ruleChain/metadata | saveRuleChainMetaData
[**SaveRuleChainUsingPOST**](RuleChainControllerApi.md#saverulechainusingpost) | **POST** /api/ruleChain/device/default | saveRuleChain
[**SaveRuleChainUsingPOST1**](RuleChainControllerApi.md#saverulechainusingpost1) | **POST** /api/ruleChain | saveRuleChain
[**SetRootRuleChainUsingPOST**](RuleChainControllerApi.md#setrootrulechainusingpost) | **POST** /api/ruleChain/{ruleChainId}/root | setRootRuleChain
[**TestScriptUsingPOST**](RuleChainControllerApi.md#testscriptusingpost) | **POST** /api/ruleChain/testScript | testScript


<a name="deleterulechainusingdelete"></a>
# **DeleteRuleChainUsingDELETE**
> void DeleteRuleChainUsingDELETE (string ruleChainId)

deleteRuleChain

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeleteRuleChainUsingDELETEExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new RuleChainControllerApi();
            var ruleChainId = ruleChainId_example;  // string | ruleChainId

            try
            {
                // deleteRuleChain
                apiInstance.DeleteRuleChainUsingDELETE(ruleChainId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RuleChainControllerApi.DeleteRuleChainUsingDELETE: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ruleChainId** | **string**| ruleChainId | 

### Return type

void (empty response body)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="exportrulechainsusingget"></a>
# **ExportRuleChainsUsingGET**
> RuleChainData ExportRuleChainsUsingGET (string limit)

exportRuleChains

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ExportRuleChainsUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new RuleChainControllerApi();
            var limit = limit_example;  // string | limit

            try
            {
                // exportRuleChains
                RuleChainData result = apiInstance.ExportRuleChainsUsingGET(limit);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RuleChainControllerApi.ExportRuleChainsUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **string**| limit | 

### Return type

[**RuleChainData**](RuleChainData.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getlatestrulenodedebuginputusingget"></a>
# **GetLatestRuleNodeDebugInputUsingGET**
> string GetLatestRuleNodeDebugInputUsingGET (string ruleNodeId)

getLatestRuleNodeDebugInput

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetLatestRuleNodeDebugInputUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new RuleChainControllerApi();
            var ruleNodeId = ruleNodeId_example;  // string | ruleNodeId

            try
            {
                // getLatestRuleNodeDebugInput
                string result = apiInstance.GetLatestRuleNodeDebugInputUsingGET(ruleNodeId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RuleChainControllerApi.GetLatestRuleNodeDebugInputUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ruleNodeId** | **string**| ruleNodeId | 

### Return type

**string**

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getrulechainbyidusingget"></a>
# **GetRuleChainByIdUsingGET**
> RuleChain GetRuleChainByIdUsingGET (string ruleChainId)

getRuleChainById

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetRuleChainByIdUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new RuleChainControllerApi();
            var ruleChainId = ruleChainId_example;  // string | ruleChainId

            try
            {
                // getRuleChainById
                RuleChain result = apiInstance.GetRuleChainByIdUsingGET(ruleChainId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RuleChainControllerApi.GetRuleChainByIdUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ruleChainId** | **string**| ruleChainId | 

### Return type

[**RuleChain**](RuleChain.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getrulechainmetadatausingget"></a>
# **GetRuleChainMetaDataUsingGET**
> RuleChainMetaData GetRuleChainMetaDataUsingGET (string ruleChainId)

getRuleChainMetaData

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetRuleChainMetaDataUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new RuleChainControllerApi();
            var ruleChainId = ruleChainId_example;  // string | ruleChainId

            try
            {
                // getRuleChainMetaData
                RuleChainMetaData result = apiInstance.GetRuleChainMetaDataUsingGET(ruleChainId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RuleChainControllerApi.GetRuleChainMetaDataUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ruleChainId** | **string**| ruleChainId | 

### Return type

[**RuleChainMetaData**](RuleChainMetaData.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getrulechainsusingget"></a>
# **GetRuleChainsUsingGET**
> PageDataRuleChain GetRuleChainsUsingGET (string pageSize, string page, string textSearch = null, string sortProperty = null, string sortOrder = null)

getRuleChains

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetRuleChainsUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new RuleChainControllerApi();
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 

            try
            {
                // getRuleChains
                PageDataRuleChain result = apiInstance.GetRuleChainsUsingGET(pageSize, page, textSearch, sortProperty, sortOrder);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RuleChainControllerApi.GetRuleChainsUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 

### Return type

[**PageDataRuleChain**](PageDataRuleChain.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="importrulechainsusingpost"></a>
# **ImportRuleChainsUsingPOST**
> void ImportRuleChainsUsingPOST (RuleChainData ruleChainData, bool? overwrite = null)

importRuleChains

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ImportRuleChainsUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new RuleChainControllerApi();
            var ruleChainData = new RuleChainData(); // RuleChainData | ruleChainData
            var overwrite = true;  // bool? | overwrite (optional)  (default to false)

            try
            {
                // importRuleChains
                apiInstance.ImportRuleChainsUsingPOST(ruleChainData, overwrite);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RuleChainControllerApi.ImportRuleChainsUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ruleChainData** | [**RuleChainData**](RuleChainData.md)| ruleChainData | 
 **overwrite** | **bool?**| overwrite | [optional] [default to false]

### Return type

void (empty response body)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="saverulechainmetadatausingpost"></a>
# **SaveRuleChainMetaDataUsingPOST**
> RuleChainMetaData SaveRuleChainMetaDataUsingPOST (RuleChainMetaData ruleChainMetaData)

saveRuleChainMetaData

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SaveRuleChainMetaDataUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new RuleChainControllerApi();
            var ruleChainMetaData = new RuleChainMetaData(); // RuleChainMetaData | ruleChainMetaData

            try
            {
                // saveRuleChainMetaData
                RuleChainMetaData result = apiInstance.SaveRuleChainMetaDataUsingPOST(ruleChainMetaData);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RuleChainControllerApi.SaveRuleChainMetaDataUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ruleChainMetaData** | [**RuleChainMetaData**](RuleChainMetaData.md)| ruleChainMetaData | 

### Return type

[**RuleChainMetaData**](RuleChainMetaData.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="saverulechainusingpost"></a>
# **SaveRuleChainUsingPOST**
> RuleChain SaveRuleChainUsingPOST (DefaultRuleChainCreateRequest request)

saveRuleChain

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SaveRuleChainUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new RuleChainControllerApi();
            var request = new DefaultRuleChainCreateRequest(); // DefaultRuleChainCreateRequest | request

            try
            {
                // saveRuleChain
                RuleChain result = apiInstance.SaveRuleChainUsingPOST(request);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RuleChainControllerApi.SaveRuleChainUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **request** | [**DefaultRuleChainCreateRequest**](DefaultRuleChainCreateRequest.md)| request | 

### Return type

[**RuleChain**](RuleChain.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="saverulechainusingpost1"></a>
# **SaveRuleChainUsingPOST1**
> RuleChain SaveRuleChainUsingPOST1 (RuleChain ruleChain)

saveRuleChain

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SaveRuleChainUsingPOST1Example
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new RuleChainControllerApi();
            var ruleChain = new RuleChain(); // RuleChain | ruleChain

            try
            {
                // saveRuleChain
                RuleChain result = apiInstance.SaveRuleChainUsingPOST1(ruleChain);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RuleChainControllerApi.SaveRuleChainUsingPOST1: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ruleChain** | [**RuleChain**](RuleChain.md)| ruleChain | 

### Return type

[**RuleChain**](RuleChain.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="setrootrulechainusingpost"></a>
# **SetRootRuleChainUsingPOST**
> RuleChain SetRootRuleChainUsingPOST (string ruleChainId)

setRootRuleChain

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SetRootRuleChainUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new RuleChainControllerApi();
            var ruleChainId = ruleChainId_example;  // string | ruleChainId

            try
            {
                // setRootRuleChain
                RuleChain result = apiInstance.SetRootRuleChainUsingPOST(ruleChainId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RuleChainControllerApi.SetRootRuleChainUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ruleChainId** | **string**| ruleChainId | 

### Return type

[**RuleChain**](RuleChain.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="testscriptusingpost"></a>
# **TestScriptUsingPOST**
> string TestScriptUsingPOST (string inputParams)

testScript

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class TestScriptUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new RuleChainControllerApi();
            var inputParams = inputParams_example;  // string | inputParams

            try
            {
                // testScript
                string result = apiInstance.TestScriptUsingPOST(inputParams);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RuleChainControllerApi.TestScriptUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **inputParams** | **string**| inputParams | 

### Return type

**string**

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

