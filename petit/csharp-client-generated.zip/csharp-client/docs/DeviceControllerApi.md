# IO.Swagger.Api.DeviceControllerApi

All URIs are relative to *https://192.168.0.9:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AssignDeviceToCustomerUsingPOST**](DeviceControllerApi.md#assigndevicetocustomerusingpost) | **POST** /api/customer/{customerId}/device/{deviceId} | assignDeviceToCustomer
[**AssignDeviceToPublicCustomerUsingPOST**](DeviceControllerApi.md#assigndevicetopubliccustomerusingpost) | **POST** /api/customer/public/device/{deviceId} | assignDeviceToPublicCustomer
[**AssignDeviceToTenantUsingPOST**](DeviceControllerApi.md#assigndevicetotenantusingpost) | **POST** /api/tenant/{tenantId}/device/{deviceId} | assignDeviceToTenant
[**ClaimDeviceUsingPOST1**](DeviceControllerApi.md#claimdeviceusingpost1) | **POST** /api/customer/device/{deviceName}/claim | claimDevice
[**DeleteDeviceUsingDELETE**](DeviceControllerApi.md#deletedeviceusingdelete) | **DELETE** /api/device/{deviceId} | deleteDevice
[**FindByQueryUsingPOST1**](DeviceControllerApi.md#findbyqueryusingpost1) | **POST** /api/devices | findByQuery
[**GetCustomerDeviceInfosUsingGET**](DeviceControllerApi.md#getcustomerdeviceinfosusingget) | **GET** /api/customer/{customerId}/deviceInfos{?type,deviceProfileId,textSearch,sortProperty,sortOrder,pageSize,page} | getCustomerDeviceInfos
[**GetCustomerDevicesUsingGET**](DeviceControllerApi.md#getcustomerdevicesusingget) | **GET** /api/customer/{customerId}/devices{?type,textSearch,sortProperty,sortOrder,pageSize,page} | getCustomerDevices
[**GetDeviceByIdUsingGET**](DeviceControllerApi.md#getdevicebyidusingget) | **GET** /api/device/{deviceId} | getDeviceById
[**GetDeviceCredentialsByDeviceIdUsingGET**](DeviceControllerApi.md#getdevicecredentialsbydeviceidusingget) | **GET** /api/device/{deviceId}/credentials | getDeviceCredentialsByDeviceId
[**GetDeviceInfoByIdUsingGET**](DeviceControllerApi.md#getdeviceinfobyidusingget) | **GET** /api/device/info/{deviceId} | getDeviceInfoById
[**GetDeviceTypesUsingGET**](DeviceControllerApi.md#getdevicetypesusingget) | **GET** /api/device/types | getDeviceTypes
[**GetDevicesByIdsUsingGET**](DeviceControllerApi.md#getdevicesbyidsusingget) | **GET** /api/devices{?deviceIds} | getDevicesByIds
[**GetTenantDeviceInfosUsingGET**](DeviceControllerApi.md#gettenantdeviceinfosusingget) | **GET** /api/tenant/deviceInfos{?type,deviceProfileId,textSearch,sortProperty,sortOrder,pageSize,page} | getTenantDeviceInfos
[**GetTenantDeviceUsingGET**](DeviceControllerApi.md#gettenantdeviceusingget) | **GET** /api/tenant/devices{?deviceName} | getTenantDevice
[**GetTenantDevicesUsingGET**](DeviceControllerApi.md#gettenantdevicesusingget) | **GET** /api/tenant/devices{?type,textSearch,sortProperty,sortOrder,pageSize,page} | getTenantDevices
[**ReClaimDeviceUsingDELETE**](DeviceControllerApi.md#reclaimdeviceusingdelete) | **DELETE** /api/customer/device/{deviceName}/claim | reClaimDevice
[**SaveDeviceCredentialsUsingPOST**](DeviceControllerApi.md#savedevicecredentialsusingpost) | **POST** /api/device/credentials | saveDeviceCredentials
[**SaveDeviceUsingPOST**](DeviceControllerApi.md#savedeviceusingpost) | **POST** /api/device{?accessToken} | saveDevice
[**UnassignDeviceFromCustomerUsingDELETE**](DeviceControllerApi.md#unassigndevicefromcustomerusingdelete) | **DELETE** /api/customer/device/{deviceId} | unassignDeviceFromCustomer


<a name="assigndevicetocustomerusingpost"></a>
# **AssignDeviceToCustomerUsingPOST**
> Device AssignDeviceToCustomerUsingPOST (string customerId, string deviceId)

assignDeviceToCustomer

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AssignDeviceToCustomerUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceControllerApi();
            var customerId = customerId_example;  // string | customerId
            var deviceId = deviceId_example;  // string | deviceId

            try
            {
                // assignDeviceToCustomer
                Device result = apiInstance.AssignDeviceToCustomerUsingPOST(customerId, deviceId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceControllerApi.AssignDeviceToCustomerUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customerId** | **string**| customerId | 
 **deviceId** | **string**| deviceId | 

### Return type

[**Device**](Device.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="assigndevicetopubliccustomerusingpost"></a>
# **AssignDeviceToPublicCustomerUsingPOST**
> Device AssignDeviceToPublicCustomerUsingPOST (string deviceId)

assignDeviceToPublicCustomer

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AssignDeviceToPublicCustomerUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceControllerApi();
            var deviceId = deviceId_example;  // string | deviceId

            try
            {
                // assignDeviceToPublicCustomer
                Device result = apiInstance.AssignDeviceToPublicCustomerUsingPOST(deviceId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceControllerApi.AssignDeviceToPublicCustomerUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceId** | **string**| deviceId | 

### Return type

[**Device**](Device.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="assigndevicetotenantusingpost"></a>
# **AssignDeviceToTenantUsingPOST**
> Device AssignDeviceToTenantUsingPOST (string tenantId, string deviceId)

assignDeviceToTenant

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AssignDeviceToTenantUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceControllerApi();
            var tenantId = tenantId_example;  // string | tenantId
            var deviceId = deviceId_example;  // string | deviceId

            try
            {
                // assignDeviceToTenant
                Device result = apiInstance.AssignDeviceToTenantUsingPOST(tenantId, deviceId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceControllerApi.AssignDeviceToTenantUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenantId** | **string**| tenantId | 
 **deviceId** | **string**| deviceId | 

### Return type

[**Device**](Device.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="claimdeviceusingpost1"></a>
# **ClaimDeviceUsingPOST1**
> DeferredResultResponseEntity ClaimDeviceUsingPOST1 (string deviceName, ClaimRequest claimRequest = null)

claimDevice

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ClaimDeviceUsingPOST1Example
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceControllerApi();
            var deviceName = deviceName_example;  // string | deviceName
            var claimRequest = new ClaimRequest(); // ClaimRequest | claimRequest (optional) 

            try
            {
                // claimDevice
                DeferredResultResponseEntity result = apiInstance.ClaimDeviceUsingPOST1(deviceName, claimRequest);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceControllerApi.ClaimDeviceUsingPOST1: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceName** | **string**| deviceName | 
 **claimRequest** | [**ClaimRequest**](ClaimRequest.md)| claimRequest | [optional] 

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="deletedeviceusingdelete"></a>
# **DeleteDeviceUsingDELETE**
> void DeleteDeviceUsingDELETE (string deviceId)

deleteDevice

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeleteDeviceUsingDELETEExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceControllerApi();
            var deviceId = deviceId_example;  // string | deviceId

            try
            {
                // deleteDevice
                apiInstance.DeleteDeviceUsingDELETE(deviceId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceControllerApi.DeleteDeviceUsingDELETE: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceId** | **string**| deviceId | 

### Return type

void (empty response body)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="findbyqueryusingpost1"></a>
# **FindByQueryUsingPOST1**
> List<Device> FindByQueryUsingPOST1 (DeviceSearchQuery query)

findByQuery

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class FindByQueryUsingPOST1Example
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceControllerApi();
            var query = new DeviceSearchQuery(); // DeviceSearchQuery | query

            try
            {
                // findByQuery
                List&lt;Device&gt; result = apiInstance.FindByQueryUsingPOST1(query);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceControllerApi.FindByQueryUsingPOST1: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | [**DeviceSearchQuery**](DeviceSearchQuery.md)| query | 

### Return type

[**List<Device>**](Device.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getcustomerdeviceinfosusingget"></a>
# **GetCustomerDeviceInfosUsingGET**
> PageDataDeviceInfo GetCustomerDeviceInfosUsingGET (string customerId, string pageSize, string page, string type = null, string deviceProfileId = null, string textSearch = null, string sortProperty = null, string sortOrder = null)

getCustomerDeviceInfos

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetCustomerDeviceInfosUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceControllerApi();
            var customerId = customerId_example;  // string | customerId
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var type = type_example;  // string | type (optional) 
            var deviceProfileId = deviceProfileId_example;  // string | deviceProfileId (optional) 
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 

            try
            {
                // getCustomerDeviceInfos
                PageDataDeviceInfo result = apiInstance.GetCustomerDeviceInfosUsingGET(customerId, pageSize, page, type, deviceProfileId, textSearch, sortProperty, sortOrder);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceControllerApi.GetCustomerDeviceInfosUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customerId** | **string**| customerId | 
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **type** | **string**| type | [optional] 
 **deviceProfileId** | **string**| deviceProfileId | [optional] 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 

### Return type

[**PageDataDeviceInfo**](PageDataDeviceInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getcustomerdevicesusingget"></a>
# **GetCustomerDevicesUsingGET**
> PageDataDevice GetCustomerDevicesUsingGET (string customerId, string pageSize, string page, string type = null, string textSearch = null, string sortProperty = null, string sortOrder = null)

getCustomerDevices

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetCustomerDevicesUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceControllerApi();
            var customerId = customerId_example;  // string | customerId
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var type = type_example;  // string | type (optional) 
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 

            try
            {
                // getCustomerDevices
                PageDataDevice result = apiInstance.GetCustomerDevicesUsingGET(customerId, pageSize, page, type, textSearch, sortProperty, sortOrder);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceControllerApi.GetCustomerDevicesUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customerId** | **string**| customerId | 
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **type** | **string**| type | [optional] 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 

### Return type

[**PageDataDevice**](PageDataDevice.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getdevicebyidusingget"></a>
# **GetDeviceByIdUsingGET**
> Device GetDeviceByIdUsingGET (string deviceId)

getDeviceById

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetDeviceByIdUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceControllerApi();
            var deviceId = deviceId_example;  // string | deviceId

            try
            {
                // getDeviceById
                Device result = apiInstance.GetDeviceByIdUsingGET(deviceId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceControllerApi.GetDeviceByIdUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceId** | **string**| deviceId | 

### Return type

[**Device**](Device.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getdevicecredentialsbydeviceidusingget"></a>
# **GetDeviceCredentialsByDeviceIdUsingGET**
> DeviceCredentials GetDeviceCredentialsByDeviceIdUsingGET (string deviceId)

getDeviceCredentialsByDeviceId

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetDeviceCredentialsByDeviceIdUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceControllerApi();
            var deviceId = deviceId_example;  // string | deviceId

            try
            {
                // getDeviceCredentialsByDeviceId
                DeviceCredentials result = apiInstance.GetDeviceCredentialsByDeviceIdUsingGET(deviceId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceControllerApi.GetDeviceCredentialsByDeviceIdUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceId** | **string**| deviceId | 

### Return type

[**DeviceCredentials**](DeviceCredentials.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getdeviceinfobyidusingget"></a>
# **GetDeviceInfoByIdUsingGET**
> DeviceInfo GetDeviceInfoByIdUsingGET (string deviceId)

getDeviceInfoById

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetDeviceInfoByIdUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceControllerApi();
            var deviceId = deviceId_example;  // string | deviceId

            try
            {
                // getDeviceInfoById
                DeviceInfo result = apiInstance.GetDeviceInfoByIdUsingGET(deviceId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceControllerApi.GetDeviceInfoByIdUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceId** | **string**| deviceId | 

### Return type

[**DeviceInfo**](DeviceInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getdevicetypesusingget"></a>
# **GetDeviceTypesUsingGET**
> List<EntitySubtype> GetDeviceTypesUsingGET ()

getDeviceTypes

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetDeviceTypesUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceControllerApi();

            try
            {
                // getDeviceTypes
                List&lt;EntitySubtype&gt; result = apiInstance.GetDeviceTypesUsingGET();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceControllerApi.GetDeviceTypesUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List<EntitySubtype>**](EntitySubtype.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getdevicesbyidsusingget"></a>
# **GetDevicesByIdsUsingGET**
> List<Device> GetDevicesByIdsUsingGET (string deviceIds)

getDevicesByIds

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetDevicesByIdsUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceControllerApi();
            var deviceIds = deviceIds_example;  // string | deviceIds

            try
            {
                // getDevicesByIds
                List&lt;Device&gt; result = apiInstance.GetDevicesByIdsUsingGET(deviceIds);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceControllerApi.GetDevicesByIdsUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceIds** | **string**| deviceIds | 

### Return type

[**List<Device>**](Device.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettenantdeviceinfosusingget"></a>
# **GetTenantDeviceInfosUsingGET**
> PageDataDeviceInfo GetTenantDeviceInfosUsingGET (string pageSize, string page, string type = null, string deviceProfileId = null, string textSearch = null, string sortProperty = null, string sortOrder = null)

getTenantDeviceInfos

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTenantDeviceInfosUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceControllerApi();
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var type = type_example;  // string | type (optional) 
            var deviceProfileId = deviceProfileId_example;  // string | deviceProfileId (optional) 
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 

            try
            {
                // getTenantDeviceInfos
                PageDataDeviceInfo result = apiInstance.GetTenantDeviceInfosUsingGET(pageSize, page, type, deviceProfileId, textSearch, sortProperty, sortOrder);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceControllerApi.GetTenantDeviceInfosUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **type** | **string**| type | [optional] 
 **deviceProfileId** | **string**| deviceProfileId | [optional] 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 

### Return type

[**PageDataDeviceInfo**](PageDataDeviceInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettenantdeviceusingget"></a>
# **GetTenantDeviceUsingGET**
> Device GetTenantDeviceUsingGET (string deviceName)

getTenantDevice

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTenantDeviceUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceControllerApi();
            var deviceName = deviceName_example;  // string | deviceName

            try
            {
                // getTenantDevice
                Device result = apiInstance.GetTenantDeviceUsingGET(deviceName);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceControllerApi.GetTenantDeviceUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceName** | **string**| deviceName | 

### Return type

[**Device**](Device.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettenantdevicesusingget"></a>
# **GetTenantDevicesUsingGET**
> PageDataDevice GetTenantDevicesUsingGET (string pageSize, string page, string type = null, string textSearch = null, string sortProperty = null, string sortOrder = null)

getTenantDevices

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTenantDevicesUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceControllerApi();
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var type = type_example;  // string | type (optional) 
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 

            try
            {
                // getTenantDevices
                PageDataDevice result = apiInstance.GetTenantDevicesUsingGET(pageSize, page, type, textSearch, sortProperty, sortOrder);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceControllerApi.GetTenantDevicesUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **type** | **string**| type | [optional] 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 

### Return type

[**PageDataDevice**](PageDataDevice.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="reclaimdeviceusingdelete"></a>
# **ReClaimDeviceUsingDELETE**
> DeferredResultResponseEntity ReClaimDeviceUsingDELETE (string deviceName)

reClaimDevice

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ReClaimDeviceUsingDELETEExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceControllerApi();
            var deviceName = deviceName_example;  // string | deviceName

            try
            {
                // reClaimDevice
                DeferredResultResponseEntity result = apiInstance.ReClaimDeviceUsingDELETE(deviceName);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceControllerApi.ReClaimDeviceUsingDELETE: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceName** | **string**| deviceName | 

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="savedevicecredentialsusingpost"></a>
# **SaveDeviceCredentialsUsingPOST**
> DeviceCredentials SaveDeviceCredentialsUsingPOST (DeviceCredentials deviceCredentials)

saveDeviceCredentials

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SaveDeviceCredentialsUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceControllerApi();
            var deviceCredentials = new DeviceCredentials(); // DeviceCredentials | deviceCredentials

            try
            {
                // saveDeviceCredentials
                DeviceCredentials result = apiInstance.SaveDeviceCredentialsUsingPOST(deviceCredentials);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceControllerApi.SaveDeviceCredentialsUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceCredentials** | [**DeviceCredentials**](DeviceCredentials.md)| deviceCredentials | 

### Return type

[**DeviceCredentials**](DeviceCredentials.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="savedeviceusingpost"></a>
# **SaveDeviceUsingPOST**
> Device SaveDeviceUsingPOST (Device device, string accessToken = null)

saveDevice

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SaveDeviceUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceControllerApi();
            var device = new Device(); // Device | device
            var accessToken = accessToken_example;  // string | accessToken (optional) 

            try
            {
                // saveDevice
                Device result = apiInstance.SaveDeviceUsingPOST(device, accessToken);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceControllerApi.SaveDeviceUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **device** | [**Device**](Device.md)| device | 
 **accessToken** | **string**| accessToken | [optional] 

### Return type

[**Device**](Device.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="unassigndevicefromcustomerusingdelete"></a>
# **UnassignDeviceFromCustomerUsingDELETE**
> Device UnassignDeviceFromCustomerUsingDELETE (string deviceId)

unassignDeviceFromCustomer

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class UnassignDeviceFromCustomerUsingDELETEExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceControllerApi();
            var deviceId = deviceId_example;  // string | deviceId

            try
            {
                // unassignDeviceFromCustomer
                Device result = apiInstance.UnassignDeviceFromCustomerUsingDELETE(deviceId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceControllerApi.UnassignDeviceFromCustomerUsingDELETE: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceId** | **string**| deviceId | 

### Return type

[**Device**](Device.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

