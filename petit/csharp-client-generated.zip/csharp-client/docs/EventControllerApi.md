# IO.Swagger.Api.EventControllerApi

All URIs are relative to *https://192.168.0.9:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetEventsUsingGET**](EventControllerApi.md#geteventsusingget) | **GET** /api/events/{entityType}/{entityId}/{eventType}{?tenantId,pageSize,page,textSearch,sortProperty,sortOrder,startTime,endTime} | getEvents
[**GetEventsUsingGET1**](EventControllerApi.md#geteventsusingget1) | **GET** /api/events/{entityType}/{entityId}{?tenantId,pageSize,page,textSearch,sortProperty,sortOrder,startTime,endTime} | getEvents


<a name="geteventsusingget"></a>
# **GetEventsUsingGET**
> PageDataEvent GetEventsUsingGET (string entityType, string entityId, string eventType, string tenantId, int? pageSize, int? page, string textSearch = null, string sortProperty = null, string sortOrder = null, long? startTime = null, long? endTime = null)

getEvents

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetEventsUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EventControllerApi();
            var entityType = entityType_example;  // string | entityType
            var entityId = entityId_example;  // string | entityId
            var eventType = eventType_example;  // string | eventType
            var tenantId = tenantId_example;  // string | tenantId
            var pageSize = 56;  // int? | pageSize
            var page = 56;  // int? | page
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 
            var startTime = 789;  // long? | startTime (optional) 
            var endTime = 789;  // long? | endTime (optional) 

            try
            {
                // getEvents
                PageDataEvent result = apiInstance.GetEventsUsingGET(entityType, entityId, eventType, tenantId, pageSize, page, textSearch, sortProperty, sortOrder, startTime, endTime);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EventControllerApi.GetEventsUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entityType** | **string**| entityType | 
 **entityId** | **string**| entityId | 
 **eventType** | **string**| eventType | 
 **tenantId** | **string**| tenantId | 
 **pageSize** | **int?**| pageSize | 
 **page** | **int?**| page | 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 
 **startTime** | **long?**| startTime | [optional] 
 **endTime** | **long?**| endTime | [optional] 

### Return type

[**PageDataEvent**](PageDataEvent.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="geteventsusingget1"></a>
# **GetEventsUsingGET1**
> PageDataEvent GetEventsUsingGET1 (string entityType, string entityId, string tenantId, int? pageSize, int? page, string textSearch = null, string sortProperty = null, string sortOrder = null, long? startTime = null, long? endTime = null)

getEvents

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetEventsUsingGET1Example
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EventControllerApi();
            var entityType = entityType_example;  // string | entityType
            var entityId = entityId_example;  // string | entityId
            var tenantId = tenantId_example;  // string | tenantId
            var pageSize = 56;  // int? | pageSize
            var page = 56;  // int? | page
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 
            var startTime = 789;  // long? | startTime (optional) 
            var endTime = 789;  // long? | endTime (optional) 

            try
            {
                // getEvents
                PageDataEvent result = apiInstance.GetEventsUsingGET1(entityType, entityId, tenantId, pageSize, page, textSearch, sortProperty, sortOrder, startTime, endTime);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EventControllerApi.GetEventsUsingGET1: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entityType** | **string**| entityType | 
 **entityId** | **string**| entityId | 
 **tenantId** | **string**| tenantId | 
 **pageSize** | **int?**| pageSize | 
 **page** | **int?**| page | 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 
 **startTime** | **long?**| startTime | [optional] 
 **endTime** | **long?**| endTime | [optional] 

### Return type

[**PageDataEvent**](PageDataEvent.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

