# IO.Swagger.Model.DeviceInfo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AdditionalInfo** | **string** |  | [optional] 
**CreatedTime** | **long?** |  | [optional] 
**CustomerId** | [**CustomerId**](CustomerId.md) |  | [optional] 
**CustomerIsPublic** | **bool?** |  | [optional] 
**CustomerTitle** | **string** |  | [optional] 
**DeviceData** | [**DeviceData**](DeviceData.md) |  | [optional] 
**DeviceProfileId** | [**DeviceProfileId**](DeviceProfileId.md) |  | [optional] 
**DeviceProfileName** | **string** |  | [optional] 
**Id** | [**DeviceId**](DeviceId.md) |  | [optional] 
**Label** | **string** |  | [optional] 
**Name** | **string** |  | [optional] 
**TenantId** | [**TenantId**](TenantId.md) |  | [optional] 
**Type** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

