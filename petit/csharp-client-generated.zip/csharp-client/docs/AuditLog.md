# IO.Swagger.Model.AuditLog
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ActionData** | **string** |  | [optional] 
**ActionFailureDetails** | **string** |  | [optional] 
**ActionStatus** | **string** |  | [optional] 
**ActionType** | **string** |  | [optional] 
**CreatedTime** | **long?** |  | [optional] 
**CustomerId** | [**CustomerId**](CustomerId.md) |  | [optional] 
**EntityId** | [**EntityId**](EntityId.md) |  | [optional] 
**EntityName** | **string** |  | [optional] 
**Id** | [**AuditLogId**](AuditLogId.md) |  | [optional] 
**TenantId** | [**TenantId**](TenantId.md) |  | [optional] 
**UserId** | [**UserId**](UserId.md) |  | [optional] 
**UserName** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

