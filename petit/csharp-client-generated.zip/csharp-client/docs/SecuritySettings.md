# IO.Swagger.Model.SecuritySettings
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MaxFailedLoginAttempts** | **int?** |  | [optional] 
**PasswordPolicy** | [**UserPasswordPolicy**](UserPasswordPolicy.md) |  | [optional] 
**UserLockoutNotificationEmail** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

