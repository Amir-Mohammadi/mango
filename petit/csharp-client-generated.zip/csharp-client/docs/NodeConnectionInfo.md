# IO.Swagger.Model.NodeConnectionInfo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FromIndex** | **int?** |  | [optional] 
**ToIndex** | **int?** |  | [optional] 
**Type** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

