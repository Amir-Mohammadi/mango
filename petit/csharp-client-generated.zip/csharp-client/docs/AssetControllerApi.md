# IO.Swagger.Api.AssetControllerApi

All URIs are relative to *https://192.168.0.9:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AssignAssetToCustomerUsingPOST**](AssetControllerApi.md#assignassettocustomerusingpost) | **POST** /api/customer/{customerId}/asset/{assetId} | assignAssetToCustomer
[**AssignAssetToPublicCustomerUsingPOST**](AssetControllerApi.md#assignassettopubliccustomerusingpost) | **POST** /api/customer/public/asset/{assetId} | assignAssetToPublicCustomer
[**DeleteAssetUsingDELETE**](AssetControllerApi.md#deleteassetusingdelete) | **DELETE** /api/asset/{assetId} | deleteAsset
[**FindByQueryUsingPOST**](AssetControllerApi.md#findbyqueryusingpost) | **POST** /api/assets | findByQuery
[**GetAssetByIdUsingGET**](AssetControllerApi.md#getassetbyidusingget) | **GET** /api/asset/{assetId} | getAssetById
[**GetAssetInfoByIdUsingGET**](AssetControllerApi.md#getassetinfobyidusingget) | **GET** /api/asset/info/{assetId} | getAssetInfoById
[**GetAssetTypesUsingGET**](AssetControllerApi.md#getassettypesusingget) | **GET** /api/asset/types | getAssetTypes
[**GetAssetsByIdsUsingGET**](AssetControllerApi.md#getassetsbyidsusingget) | **GET** /api/assets{?assetIds} | getAssetsByIds
[**GetCustomerAssetInfosUsingGET**](AssetControllerApi.md#getcustomerassetinfosusingget) | **GET** /api/customer/{customerId}/assetInfos{?type,textSearch,sortProperty,sortOrder,pageSize,page} | getCustomerAssetInfos
[**GetCustomerAssetsUsingGET**](AssetControllerApi.md#getcustomerassetsusingget) | **GET** /api/customer/{customerId}/assets{?type,textSearch,sortProperty,sortOrder,pageSize,page} | getCustomerAssets
[**GetTenantAssetInfosUsingGET**](AssetControllerApi.md#gettenantassetinfosusingget) | **GET** /api/tenant/assetInfos{?type,textSearch,sortProperty,sortOrder,pageSize,page} | getTenantAssetInfos
[**GetTenantAssetUsingGET**](AssetControllerApi.md#gettenantassetusingget) | **GET** /api/tenant/assets{?assetName} | getTenantAsset
[**GetTenantAssetsUsingGET**](AssetControllerApi.md#gettenantassetsusingget) | **GET** /api/tenant/assets{?type,textSearch,sortProperty,sortOrder,pageSize,page} | getTenantAssets
[**SaveAssetUsingPOST**](AssetControllerApi.md#saveassetusingpost) | **POST** /api/asset | saveAsset
[**UnassignAssetFromCustomerUsingDELETE**](AssetControllerApi.md#unassignassetfromcustomerusingdelete) | **DELETE** /api/customer/asset/{assetId} | unassignAssetFromCustomer


<a name="assignassettocustomerusingpost"></a>
# **AssignAssetToCustomerUsingPOST**
> Asset AssignAssetToCustomerUsingPOST (string customerId, string assetId)

assignAssetToCustomer

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AssignAssetToCustomerUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AssetControllerApi();
            var customerId = customerId_example;  // string | customerId
            var assetId = assetId_example;  // string | assetId

            try
            {
                // assignAssetToCustomer
                Asset result = apiInstance.AssignAssetToCustomerUsingPOST(customerId, assetId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AssetControllerApi.AssignAssetToCustomerUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customerId** | **string**| customerId | 
 **assetId** | **string**| assetId | 

### Return type

[**Asset**](Asset.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="assignassettopubliccustomerusingpost"></a>
# **AssignAssetToPublicCustomerUsingPOST**
> Asset AssignAssetToPublicCustomerUsingPOST (string assetId)

assignAssetToPublicCustomer

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AssignAssetToPublicCustomerUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AssetControllerApi();
            var assetId = assetId_example;  // string | assetId

            try
            {
                // assignAssetToPublicCustomer
                Asset result = apiInstance.AssignAssetToPublicCustomerUsingPOST(assetId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AssetControllerApi.AssignAssetToPublicCustomerUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **assetId** | **string**| assetId | 

### Return type

[**Asset**](Asset.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="deleteassetusingdelete"></a>
# **DeleteAssetUsingDELETE**
> void DeleteAssetUsingDELETE (string assetId)

deleteAsset

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeleteAssetUsingDELETEExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AssetControllerApi();
            var assetId = assetId_example;  // string | assetId

            try
            {
                // deleteAsset
                apiInstance.DeleteAssetUsingDELETE(assetId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AssetControllerApi.DeleteAssetUsingDELETE: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **assetId** | **string**| assetId | 

### Return type

void (empty response body)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="findbyqueryusingpost"></a>
# **FindByQueryUsingPOST**
> List<Asset> FindByQueryUsingPOST (AssetSearchQuery query)

findByQuery

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class FindByQueryUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AssetControllerApi();
            var query = new AssetSearchQuery(); // AssetSearchQuery | query

            try
            {
                // findByQuery
                List&lt;Asset&gt; result = apiInstance.FindByQueryUsingPOST(query);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AssetControllerApi.FindByQueryUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | [**AssetSearchQuery**](AssetSearchQuery.md)| query | 

### Return type

[**List<Asset>**](Asset.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getassetbyidusingget"></a>
# **GetAssetByIdUsingGET**
> Asset GetAssetByIdUsingGET (string assetId)

getAssetById

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAssetByIdUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AssetControllerApi();
            var assetId = assetId_example;  // string | assetId

            try
            {
                // getAssetById
                Asset result = apiInstance.GetAssetByIdUsingGET(assetId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AssetControllerApi.GetAssetByIdUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **assetId** | **string**| assetId | 

### Return type

[**Asset**](Asset.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getassetinfobyidusingget"></a>
# **GetAssetInfoByIdUsingGET**
> AssetInfo GetAssetInfoByIdUsingGET (string assetId)

getAssetInfoById

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAssetInfoByIdUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AssetControllerApi();
            var assetId = assetId_example;  // string | assetId

            try
            {
                // getAssetInfoById
                AssetInfo result = apiInstance.GetAssetInfoByIdUsingGET(assetId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AssetControllerApi.GetAssetInfoByIdUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **assetId** | **string**| assetId | 

### Return type

[**AssetInfo**](AssetInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getassettypesusingget"></a>
# **GetAssetTypesUsingGET**
> List<EntitySubtype> GetAssetTypesUsingGET ()

getAssetTypes

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAssetTypesUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AssetControllerApi();

            try
            {
                // getAssetTypes
                List&lt;EntitySubtype&gt; result = apiInstance.GetAssetTypesUsingGET();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AssetControllerApi.GetAssetTypesUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List<EntitySubtype>**](EntitySubtype.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getassetsbyidsusingget"></a>
# **GetAssetsByIdsUsingGET**
> List<Asset> GetAssetsByIdsUsingGET (string assetIds)

getAssetsByIds

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAssetsByIdsUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AssetControllerApi();
            var assetIds = assetIds_example;  // string | assetIds

            try
            {
                // getAssetsByIds
                List&lt;Asset&gt; result = apiInstance.GetAssetsByIdsUsingGET(assetIds);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AssetControllerApi.GetAssetsByIdsUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **assetIds** | **string**| assetIds | 

### Return type

[**List<Asset>**](Asset.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getcustomerassetinfosusingget"></a>
# **GetCustomerAssetInfosUsingGET**
> PageDataAssetInfo GetCustomerAssetInfosUsingGET (string customerId, string pageSize, string page, string type = null, string textSearch = null, string sortProperty = null, string sortOrder = null)

getCustomerAssetInfos

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetCustomerAssetInfosUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AssetControllerApi();
            var customerId = customerId_example;  // string | customerId
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var type = type_example;  // string | type (optional) 
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 

            try
            {
                // getCustomerAssetInfos
                PageDataAssetInfo result = apiInstance.GetCustomerAssetInfosUsingGET(customerId, pageSize, page, type, textSearch, sortProperty, sortOrder);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AssetControllerApi.GetCustomerAssetInfosUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customerId** | **string**| customerId | 
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **type** | **string**| type | [optional] 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 

### Return type

[**PageDataAssetInfo**](PageDataAssetInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getcustomerassetsusingget"></a>
# **GetCustomerAssetsUsingGET**
> PageDataAsset GetCustomerAssetsUsingGET (string customerId, string pageSize, string page, string type = null, string textSearch = null, string sortProperty = null, string sortOrder = null)

getCustomerAssets

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetCustomerAssetsUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AssetControllerApi();
            var customerId = customerId_example;  // string | customerId
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var type = type_example;  // string | type (optional) 
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 

            try
            {
                // getCustomerAssets
                PageDataAsset result = apiInstance.GetCustomerAssetsUsingGET(customerId, pageSize, page, type, textSearch, sortProperty, sortOrder);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AssetControllerApi.GetCustomerAssetsUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customerId** | **string**| customerId | 
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **type** | **string**| type | [optional] 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 

### Return type

[**PageDataAsset**](PageDataAsset.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettenantassetinfosusingget"></a>
# **GetTenantAssetInfosUsingGET**
> PageDataAssetInfo GetTenantAssetInfosUsingGET (string pageSize, string page, string type = null, string textSearch = null, string sortProperty = null, string sortOrder = null)

getTenantAssetInfos

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTenantAssetInfosUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AssetControllerApi();
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var type = type_example;  // string | type (optional) 
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 

            try
            {
                // getTenantAssetInfos
                PageDataAssetInfo result = apiInstance.GetTenantAssetInfosUsingGET(pageSize, page, type, textSearch, sortProperty, sortOrder);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AssetControllerApi.GetTenantAssetInfosUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **type** | **string**| type | [optional] 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 

### Return type

[**PageDataAssetInfo**](PageDataAssetInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettenantassetusingget"></a>
# **GetTenantAssetUsingGET**
> Asset GetTenantAssetUsingGET (string assetName)

getTenantAsset

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTenantAssetUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AssetControllerApi();
            var assetName = assetName_example;  // string | assetName

            try
            {
                // getTenantAsset
                Asset result = apiInstance.GetTenantAssetUsingGET(assetName);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AssetControllerApi.GetTenantAssetUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **assetName** | **string**| assetName | 

### Return type

[**Asset**](Asset.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettenantassetsusingget"></a>
# **GetTenantAssetsUsingGET**
> PageDataAsset GetTenantAssetsUsingGET (string pageSize, string page, string type = null, string textSearch = null, string sortProperty = null, string sortOrder = null)

getTenantAssets

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTenantAssetsUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AssetControllerApi();
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var type = type_example;  // string | type (optional) 
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 

            try
            {
                // getTenantAssets
                PageDataAsset result = apiInstance.GetTenantAssetsUsingGET(pageSize, page, type, textSearch, sortProperty, sortOrder);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AssetControllerApi.GetTenantAssetsUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **type** | **string**| type | [optional] 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 

### Return type

[**PageDataAsset**](PageDataAsset.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="saveassetusingpost"></a>
# **SaveAssetUsingPOST**
> Asset SaveAssetUsingPOST (Asset asset)

saveAsset

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SaveAssetUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AssetControllerApi();
            var asset = new Asset(); // Asset | asset

            try
            {
                // saveAsset
                Asset result = apiInstance.SaveAssetUsingPOST(asset);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AssetControllerApi.SaveAssetUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **asset** | [**Asset**](Asset.md)| asset | 

### Return type

[**Asset**](Asset.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="unassignassetfromcustomerusingdelete"></a>
# **UnassignAssetFromCustomerUsingDELETE**
> Asset UnassignAssetFromCustomerUsingDELETE (string assetId)

unassignAssetFromCustomer

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class UnassignAssetFromCustomerUsingDELETEExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AssetControllerApi();
            var assetId = assetId_example;  // string | assetId

            try
            {
                // unassignAssetFromCustomer
                Asset result = apiInstance.UnassignAssetFromCustomerUsingDELETE(assetId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AssetControllerApi.UnassignAssetFromCustomerUsingDELETE: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **assetId** | **string**| assetId | 

### Return type

[**Asset**](Asset.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

