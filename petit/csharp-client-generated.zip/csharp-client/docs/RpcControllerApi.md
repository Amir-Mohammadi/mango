# IO.Swagger.Api.RpcControllerApi

All URIs are relative to *https://192.168.0.9:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**HandleOneWayDeviceRPCRequestUsingPOST**](RpcControllerApi.md#handleonewaydevicerpcrequestusingpost) | **POST** /api/plugins/rpc/oneway/{deviceId} | handleOneWayDeviceRPCRequest
[**HandleTwoWayDeviceRPCRequestUsingPOST**](RpcControllerApi.md#handletwowaydevicerpcrequestusingpost) | **POST** /api/plugins/rpc/twoway/{deviceId} | handleTwoWayDeviceRPCRequest


<a name="handleonewaydevicerpcrequestusingpost"></a>
# **HandleOneWayDeviceRPCRequestUsingPOST**
> DeferredResultResponseEntity HandleOneWayDeviceRPCRequestUsingPOST (string deviceId, string requestBody)

handleOneWayDeviceRPCRequest

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class HandleOneWayDeviceRPCRequestUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new RpcControllerApi();
            var deviceId = deviceId_example;  // string | deviceId
            var requestBody = requestBody_example;  // string | requestBody

            try
            {
                // handleOneWayDeviceRPCRequest
                DeferredResultResponseEntity result = apiInstance.HandleOneWayDeviceRPCRequestUsingPOST(deviceId, requestBody);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RpcControllerApi.HandleOneWayDeviceRPCRequestUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceId** | **string**| deviceId | 
 **requestBody** | **string**| requestBody | 

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="handletwowaydevicerpcrequestusingpost"></a>
# **HandleTwoWayDeviceRPCRequestUsingPOST**
> DeferredResultResponseEntity HandleTwoWayDeviceRPCRequestUsingPOST (string deviceId, string requestBody)

handleTwoWayDeviceRPCRequest

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class HandleTwoWayDeviceRPCRequestUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new RpcControllerApi();
            var deviceId = deviceId_example;  // string | deviceId
            var requestBody = requestBody_example;  // string | requestBody

            try
            {
                // handleTwoWayDeviceRPCRequest
                DeferredResultResponseEntity result = apiInstance.HandleTwoWayDeviceRPCRequestUsingPOST(deviceId, requestBody);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RpcControllerApi.HandleTwoWayDeviceRPCRequestUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceId** | **string**| deviceId | 
 **requestBody** | **string**| requestBody | 

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

