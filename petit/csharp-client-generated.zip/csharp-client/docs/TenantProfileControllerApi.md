# IO.Swagger.Api.TenantProfileControllerApi

All URIs are relative to *https://192.168.0.9:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**DeleteTenantProfileUsingDELETE**](TenantProfileControllerApi.md#deletetenantprofileusingdelete) | **DELETE** /api/tenantProfile/{tenantProfileId} | deleteTenantProfile
[**GetDefaultTenantProfileInfoUsingGET**](TenantProfileControllerApi.md#getdefaulttenantprofileinfousingget) | **GET** /api/tenantProfileInfo/default | getDefaultTenantProfileInfo
[**GetTenantProfileByIdUsingGET**](TenantProfileControllerApi.md#gettenantprofilebyidusingget) | **GET** /api/tenantProfile/{tenantProfileId} | getTenantProfileById
[**GetTenantProfileInfoByIdUsingGET**](TenantProfileControllerApi.md#gettenantprofileinfobyidusingget) | **GET** /api/tenantProfileInfo/{tenantProfileId} | getTenantProfileInfoById
[**GetTenantProfileInfosUsingGET**](TenantProfileControllerApi.md#gettenantprofileinfosusingget) | **GET** /api/tenantProfileInfos{?textSearch,sortProperty,sortOrder,pageSize,page} | getTenantProfileInfos
[**GetTenantProfilesUsingGET**](TenantProfileControllerApi.md#gettenantprofilesusingget) | **GET** /api/tenantProfiles{?textSearch,sortProperty,sortOrder,pageSize,page} | getTenantProfiles
[**SaveTenantProfileUsingPOST**](TenantProfileControllerApi.md#savetenantprofileusingpost) | **POST** /api/tenantProfile | saveTenantProfile
[**SetDefaultTenantProfileUsingPOST**](TenantProfileControllerApi.md#setdefaulttenantprofileusingpost) | **POST** /api/tenantProfile/{tenantProfileId}/default | setDefaultTenantProfile


<a name="deletetenantprofileusingdelete"></a>
# **DeleteTenantProfileUsingDELETE**
> void DeleteTenantProfileUsingDELETE (string tenantProfileId)

deleteTenantProfile

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeleteTenantProfileUsingDELETEExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TenantProfileControllerApi();
            var tenantProfileId = tenantProfileId_example;  // string | tenantProfileId

            try
            {
                // deleteTenantProfile
                apiInstance.DeleteTenantProfileUsingDELETE(tenantProfileId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TenantProfileControllerApi.DeleteTenantProfileUsingDELETE: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenantProfileId** | **string**| tenantProfileId | 

### Return type

void (empty response body)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getdefaulttenantprofileinfousingget"></a>
# **GetDefaultTenantProfileInfoUsingGET**
> EntityInfo GetDefaultTenantProfileInfoUsingGET ()

getDefaultTenantProfileInfo

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetDefaultTenantProfileInfoUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TenantProfileControllerApi();

            try
            {
                // getDefaultTenantProfileInfo
                EntityInfo result = apiInstance.GetDefaultTenantProfileInfoUsingGET();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TenantProfileControllerApi.GetDefaultTenantProfileInfoUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**EntityInfo**](EntityInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettenantprofilebyidusingget"></a>
# **GetTenantProfileByIdUsingGET**
> TenantProfile GetTenantProfileByIdUsingGET (string tenantProfileId)

getTenantProfileById

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTenantProfileByIdUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TenantProfileControllerApi();
            var tenantProfileId = tenantProfileId_example;  // string | tenantProfileId

            try
            {
                // getTenantProfileById
                TenantProfile result = apiInstance.GetTenantProfileByIdUsingGET(tenantProfileId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TenantProfileControllerApi.GetTenantProfileByIdUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenantProfileId** | **string**| tenantProfileId | 

### Return type

[**TenantProfile**](TenantProfile.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettenantprofileinfobyidusingget"></a>
# **GetTenantProfileInfoByIdUsingGET**
> EntityInfo GetTenantProfileInfoByIdUsingGET (string tenantProfileId)

getTenantProfileInfoById

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTenantProfileInfoByIdUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TenantProfileControllerApi();
            var tenantProfileId = tenantProfileId_example;  // string | tenantProfileId

            try
            {
                // getTenantProfileInfoById
                EntityInfo result = apiInstance.GetTenantProfileInfoByIdUsingGET(tenantProfileId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TenantProfileControllerApi.GetTenantProfileInfoByIdUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenantProfileId** | **string**| tenantProfileId | 

### Return type

[**EntityInfo**](EntityInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettenantprofileinfosusingget"></a>
# **GetTenantProfileInfosUsingGET**
> PageDataEntityInfo GetTenantProfileInfosUsingGET (string pageSize, string page, string textSearch = null, string sortProperty = null, string sortOrder = null)

getTenantProfileInfos

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTenantProfileInfosUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TenantProfileControllerApi();
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 

            try
            {
                // getTenantProfileInfos
                PageDataEntityInfo result = apiInstance.GetTenantProfileInfosUsingGET(pageSize, page, textSearch, sortProperty, sortOrder);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TenantProfileControllerApi.GetTenantProfileInfosUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 

### Return type

[**PageDataEntityInfo**](PageDataEntityInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettenantprofilesusingget"></a>
# **GetTenantProfilesUsingGET**
> PageDataTenantProfile GetTenantProfilesUsingGET (string pageSize, string page, string textSearch = null, string sortProperty = null, string sortOrder = null)

getTenantProfiles

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTenantProfilesUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TenantProfileControllerApi();
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 

            try
            {
                // getTenantProfiles
                PageDataTenantProfile result = apiInstance.GetTenantProfilesUsingGET(pageSize, page, textSearch, sortProperty, sortOrder);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TenantProfileControllerApi.GetTenantProfilesUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 

### Return type

[**PageDataTenantProfile**](PageDataTenantProfile.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="savetenantprofileusingpost"></a>
# **SaveTenantProfileUsingPOST**
> TenantProfile SaveTenantProfileUsingPOST (TenantProfile tenantProfile)

saveTenantProfile

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SaveTenantProfileUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TenantProfileControllerApi();
            var tenantProfile = new TenantProfile(); // TenantProfile | tenantProfile

            try
            {
                // saveTenantProfile
                TenantProfile result = apiInstance.SaveTenantProfileUsingPOST(tenantProfile);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TenantProfileControllerApi.SaveTenantProfileUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenantProfile** | [**TenantProfile**](TenantProfile.md)| tenantProfile | 

### Return type

[**TenantProfile**](TenantProfile.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="setdefaulttenantprofileusingpost"></a>
# **SetDefaultTenantProfileUsingPOST**
> TenantProfile SetDefaultTenantProfileUsingPOST (string tenantProfileId)

setDefaultTenantProfile

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SetDefaultTenantProfileUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TenantProfileControllerApi();
            var tenantProfileId = tenantProfileId_example;  // string | tenantProfileId

            try
            {
                // setDefaultTenantProfile
                TenantProfile result = apiInstance.SetDefaultTenantProfileUsingPOST(tenantProfileId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TenantProfileControllerApi.SetDefaultTenantProfileUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenantProfileId** | **string**| tenantProfileId | 

### Return type

[**TenantProfile**](TenantProfile.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

