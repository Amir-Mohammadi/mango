# IO.Swagger.Model.AttributesEntityView
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Cs** | **List&lt;string&gt;** |  | [optional] 
**Sh** | **List&lt;string&gt;** |  | [optional] 
**Ss** | **List&lt;string&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

