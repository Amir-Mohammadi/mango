# IO.Swagger.Model.DashboardInfo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AssignedCustomers** | [**List&lt;ShortCustomerInfo&gt;**](ShortCustomerInfo.md) |  | [optional] 
**CreatedTime** | **long?** |  | [optional] 
**Id** | [**DashboardId**](DashboardId.md) |  | [optional] 
**Name** | **string** |  | [optional] 
**TenantId** | [**TenantId**](TenantId.md) |  | [optional] 
**Title** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

