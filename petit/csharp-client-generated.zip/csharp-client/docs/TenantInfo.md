# IO.Swagger.Model.TenantInfo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AdditionalInfo** | **string** |  | [optional] 
**Address** | **string** |  | [optional] 
**Address2** | **string** |  | [optional] 
**City** | **string** |  | [optional] 
**Country** | **string** |  | [optional] 
**CreatedTime** | **long?** |  | [optional] 
**Email** | **string** |  | [optional] 
**Id** | [**TenantId**](TenantId.md) |  | [optional] 
**Name** | **string** |  | [optional] 
**Phone** | **string** |  | [optional] 
**Region** | **string** |  | [optional] 
**State** | **string** |  | [optional] 
**TenantProfileId** | [**TenantProfileId**](TenantProfileId.md) |  | [optional] 
**TenantProfileName** | **string** |  | [optional] 
**Title** | **string** |  | [optional] 
**Zip** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

