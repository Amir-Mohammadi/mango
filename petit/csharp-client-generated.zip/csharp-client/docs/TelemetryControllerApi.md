# IO.Swagger.Api.TelemetryControllerApi

All URIs are relative to *https://192.168.0.9:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**DeleteEntityAttributesUsingDELETE**](TelemetryControllerApi.md#deleteentityattributesusingdelete) | **DELETE** /api/plugins/telemetry/{deviceId}/{scope}{?keys} | deleteEntityAttributes
[**DeleteEntityAttributesUsingDELETE1**](TelemetryControllerApi.md#deleteentityattributesusingdelete1) | **DELETE** /api/plugins/telemetry/{entityType}/{entityId}/{scope}{?keys} | deleteEntityAttributes
[**DeleteEntityTimeseriesUsingDELETE**](TelemetryControllerApi.md#deleteentitytimeseriesusingdelete) | **DELETE** /api/plugins/telemetry/{entityType}/{entityId}/timeseries/delete{?keys,deleteAllDataForKeys,startTs,endTs,rewriteLatestIfDeleted} | deleteEntityTimeseries
[**GetAttributeKeysByScopeUsingGET**](TelemetryControllerApi.md#getattributekeysbyscopeusingget) | **GET** /api/plugins/telemetry/{entityType}/{entityId}/keys/attributes/{scope} | getAttributeKeysByScope
[**GetAttributeKeysUsingGET**](TelemetryControllerApi.md#getattributekeysusingget) | **GET** /api/plugins/telemetry/{entityType}/{entityId}/keys/attributes | getAttributeKeys
[**GetAttributesByScopeUsingGET**](TelemetryControllerApi.md#getattributesbyscopeusingget) | **GET** /api/plugins/telemetry/{entityType}/{entityId}/values/attributes/{scope}{?keys} | getAttributesByScope
[**GetAttributesUsingGET**](TelemetryControllerApi.md#getattributesusingget) | **GET** /api/plugins/telemetry/{entityType}/{entityId}/values/attributes{?keys} | getAttributes
[**GetLatestTimeseriesUsingGET**](TelemetryControllerApi.md#getlatesttimeseriesusingget) | **GET** /api/plugins/telemetry/{entityType}/{entityId}/values/timeseries{?keys,useStrictDataTypes} | getLatestTimeseries
[**GetTimeseriesKeysUsingGET1**](TelemetryControllerApi.md#gettimeserieskeysusingget1) | **GET** /api/plugins/telemetry/{entityType}/{entityId}/keys/timeseries | getTimeseriesKeys
[**GetTimeseriesUsingGET**](TelemetryControllerApi.md#gettimeseriesusingget) | **GET** /api/plugins/telemetry/{entityType}/{entityId}/values/timeseries{?interval,limit,agg,orderBy,useStrictDataTypes,keys,startTs,endTs} | getTimeseries
[**SaveDeviceAttributesUsingPOST**](TelemetryControllerApi.md#savedeviceattributesusingpost) | **POST** /api/plugins/telemetry/{deviceId}/{scope} | saveDeviceAttributes
[**SaveEntityAttributesV1UsingPOST**](TelemetryControllerApi.md#saveentityattributesv1usingpost) | **POST** /api/plugins/telemetry/{entityType}/{entityId}/{scope} | saveEntityAttributesV1
[**SaveEntityAttributesV2UsingPOST**](TelemetryControllerApi.md#saveentityattributesv2usingpost) | **POST** /api/plugins/telemetry/{entityType}/{entityId}/attributes/{scope} | saveEntityAttributesV2
[**SaveEntityTelemetryUsingPOST**](TelemetryControllerApi.md#saveentitytelemetryusingpost) | **POST** /api/plugins/telemetry/{entityType}/{entityId}/timeseries/{scope} | saveEntityTelemetry
[**SaveEntityTelemetryWithTTLUsingPOST**](TelemetryControllerApi.md#saveentitytelemetrywithttlusingpost) | **POST** /api/plugins/telemetry/{entityType}/{entityId}/timeseries/{scope}/{ttl} | saveEntityTelemetryWithTTL


<a name="deleteentityattributesusingdelete"></a>
# **DeleteEntityAttributesUsingDELETE**
> DeferredResultResponseEntity DeleteEntityAttributesUsingDELETE (string deviceId, string scope, string keys)

deleteEntityAttributes

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeleteEntityAttributesUsingDELETEExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TelemetryControllerApi();
            var deviceId = deviceId_example;  // string | deviceId
            var scope = scope_example;  // string | scope
            var keys = keys_example;  // string | keys

            try
            {
                // deleteEntityAttributes
                DeferredResultResponseEntity result = apiInstance.DeleteEntityAttributesUsingDELETE(deviceId, scope, keys);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TelemetryControllerApi.DeleteEntityAttributesUsingDELETE: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceId** | **string**| deviceId | 
 **scope** | **string**| scope | 
 **keys** | **string**| keys | 

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="deleteentityattributesusingdelete1"></a>
# **DeleteEntityAttributesUsingDELETE1**
> DeferredResultResponseEntity DeleteEntityAttributesUsingDELETE1 (string entityType, string entityId, string scope, string keys)

deleteEntityAttributes

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeleteEntityAttributesUsingDELETE1Example
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TelemetryControllerApi();
            var entityType = entityType_example;  // string | entityType
            var entityId = entityId_example;  // string | entityId
            var scope = scope_example;  // string | scope
            var keys = keys_example;  // string | keys

            try
            {
                // deleteEntityAttributes
                DeferredResultResponseEntity result = apiInstance.DeleteEntityAttributesUsingDELETE1(entityType, entityId, scope, keys);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TelemetryControllerApi.DeleteEntityAttributesUsingDELETE1: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entityType** | **string**| entityType | 
 **entityId** | **string**| entityId | 
 **scope** | **string**| scope | 
 **keys** | **string**| keys | 

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="deleteentitytimeseriesusingdelete"></a>
# **DeleteEntityTimeseriesUsingDELETE**
> DeferredResultResponseEntity DeleteEntityTimeseriesUsingDELETE (string entityType, string entityId, string keys, bool? deleteAllDataForKeys = null, long? startTs = null, long? endTs = null, bool? rewriteLatestIfDeleted = null)

deleteEntityTimeseries

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeleteEntityTimeseriesUsingDELETEExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TelemetryControllerApi();
            var entityType = entityType_example;  // string | entityType
            var entityId = entityId_example;  // string | entityId
            var keys = keys_example;  // string | keys
            var deleteAllDataForKeys = true;  // bool? | deleteAllDataForKeys (optional)  (default to false)
            var startTs = 789;  // long? | startTs (optional) 
            var endTs = 789;  // long? | endTs (optional) 
            var rewriteLatestIfDeleted = true;  // bool? | rewriteLatestIfDeleted (optional)  (default to false)

            try
            {
                // deleteEntityTimeseries
                DeferredResultResponseEntity result = apiInstance.DeleteEntityTimeseriesUsingDELETE(entityType, entityId, keys, deleteAllDataForKeys, startTs, endTs, rewriteLatestIfDeleted);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TelemetryControllerApi.DeleteEntityTimeseriesUsingDELETE: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entityType** | **string**| entityType | 
 **entityId** | **string**| entityId | 
 **keys** | **string**| keys | 
 **deleteAllDataForKeys** | **bool?**| deleteAllDataForKeys | [optional] [default to false]
 **startTs** | **long?**| startTs | [optional] 
 **endTs** | **long?**| endTs | [optional] 
 **rewriteLatestIfDeleted** | **bool?**| rewriteLatestIfDeleted | [optional] [default to false]

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getattributekeysbyscopeusingget"></a>
# **GetAttributeKeysByScopeUsingGET**
> DeferredResultResponseEntity GetAttributeKeysByScopeUsingGET (string entityType, string entityId, string scope)

getAttributeKeysByScope

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAttributeKeysByScopeUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TelemetryControllerApi();
            var entityType = entityType_example;  // string | entityType
            var entityId = entityId_example;  // string | entityId
            var scope = scope_example;  // string | scope

            try
            {
                // getAttributeKeysByScope
                DeferredResultResponseEntity result = apiInstance.GetAttributeKeysByScopeUsingGET(entityType, entityId, scope);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TelemetryControllerApi.GetAttributeKeysByScopeUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entityType** | **string**| entityType | 
 **entityId** | **string**| entityId | 
 **scope** | **string**| scope | 

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getattributekeysusingget"></a>
# **GetAttributeKeysUsingGET**
> DeferredResultResponseEntity GetAttributeKeysUsingGET (string entityType, string entityId)

getAttributeKeys

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAttributeKeysUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TelemetryControllerApi();
            var entityType = entityType_example;  // string | entityType
            var entityId = entityId_example;  // string | entityId

            try
            {
                // getAttributeKeys
                DeferredResultResponseEntity result = apiInstance.GetAttributeKeysUsingGET(entityType, entityId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TelemetryControllerApi.GetAttributeKeysUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entityType** | **string**| entityType | 
 **entityId** | **string**| entityId | 

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getattributesbyscopeusingget"></a>
# **GetAttributesByScopeUsingGET**
> DeferredResultResponseEntity GetAttributesByScopeUsingGET (string entityType, string entityId, string scope, string keys = null)

getAttributesByScope

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAttributesByScopeUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TelemetryControllerApi();
            var entityType = entityType_example;  // string | entityType
            var entityId = entityId_example;  // string | entityId
            var scope = scope_example;  // string | scope
            var keys = keys_example;  // string | keys (optional) 

            try
            {
                // getAttributesByScope
                DeferredResultResponseEntity result = apiInstance.GetAttributesByScopeUsingGET(entityType, entityId, scope, keys);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TelemetryControllerApi.GetAttributesByScopeUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entityType** | **string**| entityType | 
 **entityId** | **string**| entityId | 
 **scope** | **string**| scope | 
 **keys** | **string**| keys | [optional] 

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getattributesusingget"></a>
# **GetAttributesUsingGET**
> DeferredResultResponseEntity GetAttributesUsingGET (string entityType, string entityId, string keys = null)

getAttributes

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAttributesUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TelemetryControllerApi();
            var entityType = entityType_example;  // string | entityType
            var entityId = entityId_example;  // string | entityId
            var keys = keys_example;  // string | keys (optional) 

            try
            {
                // getAttributes
                DeferredResultResponseEntity result = apiInstance.GetAttributesUsingGET(entityType, entityId, keys);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TelemetryControllerApi.GetAttributesUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entityType** | **string**| entityType | 
 **entityId** | **string**| entityId | 
 **keys** | **string**| keys | [optional] 

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getlatesttimeseriesusingget"></a>
# **GetLatestTimeseriesUsingGET**
> DeferredResultResponseEntity GetLatestTimeseriesUsingGET (string entityType, string entityId, string keys = null, bool? useStrictDataTypes = null)

getLatestTimeseries

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetLatestTimeseriesUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TelemetryControllerApi();
            var entityType = entityType_example;  // string | entityType
            var entityId = entityId_example;  // string | entityId
            var keys = keys_example;  // string | keys (optional) 
            var useStrictDataTypes = true;  // bool? | useStrictDataTypes (optional)  (default to false)

            try
            {
                // getLatestTimeseries
                DeferredResultResponseEntity result = apiInstance.GetLatestTimeseriesUsingGET(entityType, entityId, keys, useStrictDataTypes);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TelemetryControllerApi.GetLatestTimeseriesUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entityType** | **string**| entityType | 
 **entityId** | **string**| entityId | 
 **keys** | **string**| keys | [optional] 
 **useStrictDataTypes** | **bool?**| useStrictDataTypes | [optional] [default to false]

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettimeserieskeysusingget1"></a>
# **GetTimeseriesKeysUsingGET1**
> DeferredResultResponseEntity GetTimeseriesKeysUsingGET1 (string entityType, string entityId)

getTimeseriesKeys

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTimeseriesKeysUsingGET1Example
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TelemetryControllerApi();
            var entityType = entityType_example;  // string | entityType
            var entityId = entityId_example;  // string | entityId

            try
            {
                // getTimeseriesKeys
                DeferredResultResponseEntity result = apiInstance.GetTimeseriesKeysUsingGET1(entityType, entityId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TelemetryControllerApi.GetTimeseriesKeysUsingGET1: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entityType** | **string**| entityType | 
 **entityId** | **string**| entityId | 

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettimeseriesusingget"></a>
# **GetTimeseriesUsingGET**
> DeferredResultResponseEntity GetTimeseriesUsingGET (string entityType, string entityId, string keys, string startTs, string endTs, long? interval = null, int? limit = null, string agg = null, string orderBy = null, bool? useStrictDataTypes = null)

getTimeseries

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTimeseriesUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TelemetryControllerApi();
            var entityType = entityType_example;  // string | entityType
            var entityId = entityId_example;  // string | entityId
            var keys = keys_example;  // string | keys
            var startTs = startTs_example;  // string | startTs
            var endTs = endTs_example;  // string | endTs
            var interval = 789;  // long? | interval (optional)  (default to 0)
            var limit = 56;  // int? | limit (optional)  (default to 100)
            var agg = agg_example;  // string | agg (optional)  (default to NONE)
            var orderBy = orderBy_example;  // string | orderBy (optional)  (default to DESC)
            var useStrictDataTypes = true;  // bool? | useStrictDataTypes (optional)  (default to false)

            try
            {
                // getTimeseries
                DeferredResultResponseEntity result = apiInstance.GetTimeseriesUsingGET(entityType, entityId, keys, startTs, endTs, interval, limit, agg, orderBy, useStrictDataTypes);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TelemetryControllerApi.GetTimeseriesUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entityType** | **string**| entityType | 
 **entityId** | **string**| entityId | 
 **keys** | **string**| keys | 
 **startTs** | **string**| startTs | 
 **endTs** | **string**| endTs | 
 **interval** | **long?**| interval | [optional] [default to 0]
 **limit** | **int?**| limit | [optional] [default to 100]
 **agg** | **string**| agg | [optional] [default to NONE]
 **orderBy** | **string**| orderBy | [optional] [default to DESC]
 **useStrictDataTypes** | **bool?**| useStrictDataTypes | [optional] [default to false]

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="savedeviceattributesusingpost"></a>
# **SaveDeviceAttributesUsingPOST**
> DeferredResultResponseEntity SaveDeviceAttributesUsingPOST (string deviceId, string scope, string request)

saveDeviceAttributes

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SaveDeviceAttributesUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TelemetryControllerApi();
            var deviceId = deviceId_example;  // string | deviceId
            var scope = scope_example;  // string | scope
            var request = request_example;  // string | request

            try
            {
                // saveDeviceAttributes
                DeferredResultResponseEntity result = apiInstance.SaveDeviceAttributesUsingPOST(deviceId, scope, request);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TelemetryControllerApi.SaveDeviceAttributesUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceId** | **string**| deviceId | 
 **scope** | **string**| scope | 
 **request** | **string**| request | 

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="saveentityattributesv1usingpost"></a>
# **SaveEntityAttributesV1UsingPOST**
> DeferredResultResponseEntity SaveEntityAttributesV1UsingPOST (string entityType, string entityId, string scope, string request)

saveEntityAttributesV1

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SaveEntityAttributesV1UsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TelemetryControllerApi();
            var entityType = entityType_example;  // string | entityType
            var entityId = entityId_example;  // string | entityId
            var scope = scope_example;  // string | scope
            var request = request_example;  // string | request

            try
            {
                // saveEntityAttributesV1
                DeferredResultResponseEntity result = apiInstance.SaveEntityAttributesV1UsingPOST(entityType, entityId, scope, request);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TelemetryControllerApi.SaveEntityAttributesV1UsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entityType** | **string**| entityType | 
 **entityId** | **string**| entityId | 
 **scope** | **string**| scope | 
 **request** | **string**| request | 

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="saveentityattributesv2usingpost"></a>
# **SaveEntityAttributesV2UsingPOST**
> DeferredResultResponseEntity SaveEntityAttributesV2UsingPOST (string entityType, string entityId, string scope, string request)

saveEntityAttributesV2

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SaveEntityAttributesV2UsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TelemetryControllerApi();
            var entityType = entityType_example;  // string | entityType
            var entityId = entityId_example;  // string | entityId
            var scope = scope_example;  // string | scope
            var request = request_example;  // string | request

            try
            {
                // saveEntityAttributesV2
                DeferredResultResponseEntity result = apiInstance.SaveEntityAttributesV2UsingPOST(entityType, entityId, scope, request);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TelemetryControllerApi.SaveEntityAttributesV2UsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entityType** | **string**| entityType | 
 **entityId** | **string**| entityId | 
 **scope** | **string**| scope | 
 **request** | **string**| request | 

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="saveentitytelemetryusingpost"></a>
# **SaveEntityTelemetryUsingPOST**
> DeferredResultResponseEntity SaveEntityTelemetryUsingPOST (string entityType, string entityId, string scope, string requestBody)

saveEntityTelemetry

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SaveEntityTelemetryUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TelemetryControllerApi();
            var entityType = entityType_example;  // string | entityType
            var entityId = entityId_example;  // string | entityId
            var scope = scope_example;  // string | scope
            var requestBody = requestBody_example;  // string | requestBody

            try
            {
                // saveEntityTelemetry
                DeferredResultResponseEntity result = apiInstance.SaveEntityTelemetryUsingPOST(entityType, entityId, scope, requestBody);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TelemetryControllerApi.SaveEntityTelemetryUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entityType** | **string**| entityType | 
 **entityId** | **string**| entityId | 
 **scope** | **string**| scope | 
 **requestBody** | **string**| requestBody | 

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="saveentitytelemetrywithttlusingpost"></a>
# **SaveEntityTelemetryWithTTLUsingPOST**
> DeferredResultResponseEntity SaveEntityTelemetryWithTTLUsingPOST (string entityType, string entityId, string scope, long? ttl, string requestBody)

saveEntityTelemetryWithTTL

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SaveEntityTelemetryWithTTLUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new TelemetryControllerApi();
            var entityType = entityType_example;  // string | entityType
            var entityId = entityId_example;  // string | entityId
            var scope = scope_example;  // string | scope
            var ttl = 789;  // long? | ttl
            var requestBody = requestBody_example;  // string | requestBody

            try
            {
                // saveEntityTelemetryWithTTL
                DeferredResultResponseEntity result = apiInstance.SaveEntityTelemetryWithTTLUsingPOST(entityType, entityId, scope, ttl, requestBody);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TelemetryControllerApi.SaveEntityTelemetryWithTTLUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entityType** | **string**| entityType | 
 **entityId** | **string**| entityId | 
 **scope** | **string**| scope | 
 **ttl** | **long?**| ttl | 
 **requestBody** | **string**| requestBody | 

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

