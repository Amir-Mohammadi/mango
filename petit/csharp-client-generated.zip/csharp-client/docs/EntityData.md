# IO.Swagger.Model.EntityData
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EntityId** | [**EntityId**](EntityId.md) |  | [optional] 
**Latest** | **Dictionary&lt;string, Dictionary&lt;string, TsValue&gt;&gt;** |  | [optional] 
**Timeseries** | **Dictionary&lt;string, List&lt;TsValue&gt;&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

