# IO.Swagger.Model.RelationsSearchParameters
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EntityId** | [**EntityId**](EntityId.md) |  | [optional] 
**RootId** | **string** |  | 
**RootType** | **string** |  | 
**Direction** | **string** |  | 
**RelationTypeGroup** | **string** |  | 
**MaxLevel** | **int?** |  | 
**FetchLastLevelOnly** | **bool?** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

