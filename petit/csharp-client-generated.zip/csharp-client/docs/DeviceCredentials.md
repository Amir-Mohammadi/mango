# IO.Swagger.Model.DeviceCredentials
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreatedTime** | **long?** |  | [optional] 
**CredentialsId** | **string** |  | [optional] 
**CredentialsType** | **string** |  | [optional] 
**CredentialsValue** | **string** |  | [optional] 
**DeviceId** | [**DeviceId**](DeviceId.md) |  | [optional] 
**Id** | [**DeviceCredentialsId**](DeviceCredentialsId.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

