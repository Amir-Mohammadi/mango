# IO.Swagger.Model.EntityDataQuery
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EntityFields** | [**List&lt;EntityKey&gt;**](EntityKey.md) |  | [optional] 
**EntityFilter** | [**EntityFilter**](EntityFilter.md) |  | [optional] 
**KeyFilters** | [**List&lt;KeyFilter&gt;**](KeyFilter.md) |  | [optional] 
**LatestValues** | [**List&lt;EntityKey&gt;**](EntityKey.md) |  | [optional] 
**PageLink** | [**EntityDataPageLink**](EntityDataPageLink.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

