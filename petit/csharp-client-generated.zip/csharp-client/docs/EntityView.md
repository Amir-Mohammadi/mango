# IO.Swagger.Model.EntityView
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AdditionalInfo** | **string** |  | [optional] 
**CreatedTime** | **long?** |  | [optional] 
**CustomerId** | [**CustomerId**](CustomerId.md) |  | [optional] 
**EndTimeMs** | **long?** |  | [optional] 
**EntityId** | [**EntityId**](EntityId.md) |  | [optional] 
**Id** | [**EntityViewId**](EntityViewId.md) |  | [optional] 
**Keys** | [**TelemetryEntityView**](TelemetryEntityView.md) |  | [optional] 
**Name** | **string** |  | [optional] 
**StartTimeMs** | **long?** |  | [optional] 
**TenantId** | [**TenantId**](TenantId.md) |  | [optional] 
**Type** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

