# IO.Swagger.Api.DeviceProfileControllerApi

All URIs are relative to *https://192.168.0.9:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**DeleteDeviceProfileUsingDELETE**](DeviceProfileControllerApi.md#deletedeviceprofileusingdelete) | **DELETE** /api/deviceProfile/{deviceProfileId} | deleteDeviceProfile
[**GetAttributesKeysUsingGET**](DeviceProfileControllerApi.md#getattributeskeysusingget) | **GET** /api/deviceProfile/devices/keys/attributes{?deviceProfileId} | getAttributesKeys
[**GetDefaultDeviceProfileInfoUsingGET**](DeviceProfileControllerApi.md#getdefaultdeviceprofileinfousingget) | **GET** /api/deviceProfileInfo/default | getDefaultDeviceProfileInfo
[**GetDeviceProfileByIdUsingGET**](DeviceProfileControllerApi.md#getdeviceprofilebyidusingget) | **GET** /api/deviceProfile/{deviceProfileId} | getDeviceProfileById
[**GetDeviceProfileInfoByIdUsingGET**](DeviceProfileControllerApi.md#getdeviceprofileinfobyidusingget) | **GET** /api/deviceProfileInfo/{deviceProfileId} | getDeviceProfileInfoById
[**GetDeviceProfileInfosUsingGET**](DeviceProfileControllerApi.md#getdeviceprofileinfosusingget) | **GET** /api/deviceProfileInfos{?textSearch,sortProperty,sortOrder,transportType,pageSize,page} | getDeviceProfileInfos
[**GetDeviceProfilesUsingGET**](DeviceProfileControllerApi.md#getdeviceprofilesusingget) | **GET** /api/deviceProfiles{?textSearch,sortProperty,sortOrder,pageSize,page} | getDeviceProfiles
[**GetTimeseriesKeysUsingGET**](DeviceProfileControllerApi.md#gettimeserieskeysusingget) | **GET** /api/deviceProfile/devices/keys/timeseries{?deviceProfileId} | getTimeseriesKeys
[**SaveDeviceProfileUsingPOST**](DeviceProfileControllerApi.md#savedeviceprofileusingpost) | **POST** /api/deviceProfile | saveDeviceProfile
[**SetDefaultDeviceProfileUsingPOST**](DeviceProfileControllerApi.md#setdefaultdeviceprofileusingpost) | **POST** /api/deviceProfile/{deviceProfileId}/default | setDefaultDeviceProfile


<a name="deletedeviceprofileusingdelete"></a>
# **DeleteDeviceProfileUsingDELETE**
> void DeleteDeviceProfileUsingDELETE (string deviceProfileId)

deleteDeviceProfile

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeleteDeviceProfileUsingDELETEExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceProfileControllerApi();
            var deviceProfileId = deviceProfileId_example;  // string | deviceProfileId

            try
            {
                // deleteDeviceProfile
                apiInstance.DeleteDeviceProfileUsingDELETE(deviceProfileId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceProfileControllerApi.DeleteDeviceProfileUsingDELETE: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceProfileId** | **string**| deviceProfileId | 

### Return type

void (empty response body)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getattributeskeysusingget"></a>
# **GetAttributesKeysUsingGET**
> List<string> GetAttributesKeysUsingGET (string deviceProfileId = null)

getAttributesKeys

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAttributesKeysUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceProfileControllerApi();
            var deviceProfileId = deviceProfileId_example;  // string | deviceProfileId (optional) 

            try
            {
                // getAttributesKeys
                List&lt;string&gt; result = apiInstance.GetAttributesKeysUsingGET(deviceProfileId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceProfileControllerApi.GetAttributesKeysUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceProfileId** | **string**| deviceProfileId | [optional] 

### Return type

**List<string>**

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getdefaultdeviceprofileinfousingget"></a>
# **GetDefaultDeviceProfileInfoUsingGET**
> DeviceProfileInfo GetDefaultDeviceProfileInfoUsingGET ()

getDefaultDeviceProfileInfo

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetDefaultDeviceProfileInfoUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceProfileControllerApi();

            try
            {
                // getDefaultDeviceProfileInfo
                DeviceProfileInfo result = apiInstance.GetDefaultDeviceProfileInfoUsingGET();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceProfileControllerApi.GetDefaultDeviceProfileInfoUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**DeviceProfileInfo**](DeviceProfileInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getdeviceprofilebyidusingget"></a>
# **GetDeviceProfileByIdUsingGET**
> DeviceProfile GetDeviceProfileByIdUsingGET (string deviceProfileId)

getDeviceProfileById

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetDeviceProfileByIdUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceProfileControllerApi();
            var deviceProfileId = deviceProfileId_example;  // string | deviceProfileId

            try
            {
                // getDeviceProfileById
                DeviceProfile result = apiInstance.GetDeviceProfileByIdUsingGET(deviceProfileId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceProfileControllerApi.GetDeviceProfileByIdUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceProfileId** | **string**| deviceProfileId | 

### Return type

[**DeviceProfile**](DeviceProfile.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getdeviceprofileinfobyidusingget"></a>
# **GetDeviceProfileInfoByIdUsingGET**
> DeviceProfileInfo GetDeviceProfileInfoByIdUsingGET (string deviceProfileId)

getDeviceProfileInfoById

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetDeviceProfileInfoByIdUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceProfileControllerApi();
            var deviceProfileId = deviceProfileId_example;  // string | deviceProfileId

            try
            {
                // getDeviceProfileInfoById
                DeviceProfileInfo result = apiInstance.GetDeviceProfileInfoByIdUsingGET(deviceProfileId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceProfileControllerApi.GetDeviceProfileInfoByIdUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceProfileId** | **string**| deviceProfileId | 

### Return type

[**DeviceProfileInfo**](DeviceProfileInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getdeviceprofileinfosusingget"></a>
# **GetDeviceProfileInfosUsingGET**
> PageDataDeviceProfileInfo GetDeviceProfileInfosUsingGET (string pageSize, string page, string textSearch = null, string sortProperty = null, string sortOrder = null, string transportType = null)

getDeviceProfileInfos

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetDeviceProfileInfosUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceProfileControllerApi();
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 
            var transportType = transportType_example;  // string | transportType (optional) 

            try
            {
                // getDeviceProfileInfos
                PageDataDeviceProfileInfo result = apiInstance.GetDeviceProfileInfosUsingGET(pageSize, page, textSearch, sortProperty, sortOrder, transportType);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceProfileControllerApi.GetDeviceProfileInfosUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 
 **transportType** | **string**| transportType | [optional] 

### Return type

[**PageDataDeviceProfileInfo**](PageDataDeviceProfileInfo.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getdeviceprofilesusingget"></a>
# **GetDeviceProfilesUsingGET**
> PageDataDeviceProfile GetDeviceProfilesUsingGET (string pageSize, string page, string textSearch = null, string sortProperty = null, string sortOrder = null)

getDeviceProfiles

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetDeviceProfilesUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceProfileControllerApi();
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 

            try
            {
                // getDeviceProfiles
                PageDataDeviceProfile result = apiInstance.GetDeviceProfilesUsingGET(pageSize, page, textSearch, sortProperty, sortOrder);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceProfileControllerApi.GetDeviceProfilesUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 

### Return type

[**PageDataDeviceProfile**](PageDataDeviceProfile.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettimeserieskeysusingget"></a>
# **GetTimeseriesKeysUsingGET**
> List<string> GetTimeseriesKeysUsingGET (string deviceProfileId = null)

getTimeseriesKeys

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTimeseriesKeysUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceProfileControllerApi();
            var deviceProfileId = deviceProfileId_example;  // string | deviceProfileId (optional) 

            try
            {
                // getTimeseriesKeys
                List&lt;string&gt; result = apiInstance.GetTimeseriesKeysUsingGET(deviceProfileId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceProfileControllerApi.GetTimeseriesKeysUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceProfileId** | **string**| deviceProfileId | [optional] 

### Return type

**List<string>**

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="savedeviceprofileusingpost"></a>
# **SaveDeviceProfileUsingPOST**
> DeviceProfile SaveDeviceProfileUsingPOST (DeviceProfile deviceProfile)

saveDeviceProfile

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SaveDeviceProfileUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceProfileControllerApi();
            var deviceProfile = new DeviceProfile(); // DeviceProfile | deviceProfile

            try
            {
                // saveDeviceProfile
                DeviceProfile result = apiInstance.SaveDeviceProfileUsingPOST(deviceProfile);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceProfileControllerApi.SaveDeviceProfileUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceProfile** | [**DeviceProfile**](DeviceProfile.md)| deviceProfile | 

### Return type

[**DeviceProfile**](DeviceProfile.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="setdefaultdeviceprofileusingpost"></a>
# **SetDefaultDeviceProfileUsingPOST**
> DeviceProfile SetDefaultDeviceProfileUsingPOST (string deviceProfileId)

setDefaultDeviceProfile

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SetDefaultDeviceProfileUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new DeviceProfileControllerApi();
            var deviceProfileId = deviceProfileId_example;  // string | deviceProfileId

            try
            {
                // setDefaultDeviceProfile
                DeviceProfile result = apiInstance.SetDefaultDeviceProfileUsingPOST(deviceProfileId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DeviceProfileControllerApi.SetDefaultDeviceProfileUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **deviceProfileId** | **string**| deviceProfileId | 

### Return type

[**DeviceProfile**](DeviceProfile.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

