# IO.Swagger.Model.DeviceProfileAlarm
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AlarmType** | **string** |  | [optional] 
**ClearRule** | [**AlarmRule**](AlarmRule.md) |  | [optional] 
**CreateRules** | [**Dictionary&lt;string, AlarmRule&gt;**](AlarmRule.md) |  | [optional] 
**Id** | **string** |  | [optional] 
**Propagate** | **bool?** |  | [optional] 
**PropagateRelationTypes** | **List&lt;string&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

