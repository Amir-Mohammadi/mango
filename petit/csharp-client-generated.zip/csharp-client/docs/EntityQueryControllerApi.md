# IO.Swagger.Api.EntityQueryControllerApi

All URIs are relative to *https://192.168.0.9:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CountEntitiesByQueryUsingPOST**](EntityQueryControllerApi.md#countentitiesbyqueryusingpost) | **POST** /api/entitiesQuery/count | countEntitiesByQuery
[**FindAlarmDataByQueryUsingPOST**](EntityQueryControllerApi.md#findalarmdatabyqueryusingpost) | **POST** /api/alarmsQuery/find | findAlarmDataByQuery
[**FindEntityDataByQueryUsingPOST**](EntityQueryControllerApi.md#findentitydatabyqueryusingpost) | **POST** /api/entitiesQuery/find | findEntityDataByQuery
[**FindEntityTimeseriesAndAttributesKeysByQueryUsingPOST**](EntityQueryControllerApi.md#findentitytimeseriesandattributeskeysbyqueryusingpost) | **POST** /api/entitiesQuery/find/keys{?timeseries,attributes} | findEntityTimeseriesAndAttributesKeysByQuery


<a name="countentitiesbyqueryusingpost"></a>
# **CountEntitiesByQueryUsingPOST**
> long? CountEntitiesByQueryUsingPOST (EntityCountQuery query)

countEntitiesByQuery

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CountEntitiesByQueryUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityQueryControllerApi();
            var query = new EntityCountQuery(); // EntityCountQuery | query

            try
            {
                // countEntitiesByQuery
                long? result = apiInstance.CountEntitiesByQueryUsingPOST(query);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityQueryControllerApi.CountEntitiesByQueryUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | [**EntityCountQuery**](EntityCountQuery.md)| query | 

### Return type

**long?**

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="findalarmdatabyqueryusingpost"></a>
# **FindAlarmDataByQueryUsingPOST**
> PageDataAlarmData FindAlarmDataByQueryUsingPOST (AlarmDataQuery query)

findAlarmDataByQuery

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class FindAlarmDataByQueryUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityQueryControllerApi();
            var query = new AlarmDataQuery(); // AlarmDataQuery | query

            try
            {
                // findAlarmDataByQuery
                PageDataAlarmData result = apiInstance.FindAlarmDataByQueryUsingPOST(query);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityQueryControllerApi.FindAlarmDataByQueryUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | [**AlarmDataQuery**](AlarmDataQuery.md)| query | 

### Return type

[**PageDataAlarmData**](PageDataAlarmData.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="findentitydatabyqueryusingpost"></a>
# **FindEntityDataByQueryUsingPOST**
> PageDataEntityData FindEntityDataByQueryUsingPOST (EntityDataQuery query)

findEntityDataByQuery

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class FindEntityDataByQueryUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityQueryControllerApi();
            var query = new EntityDataQuery(); // EntityDataQuery | query

            try
            {
                // findEntityDataByQuery
                PageDataEntityData result = apiInstance.FindEntityDataByQueryUsingPOST(query);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityQueryControllerApi.FindEntityDataByQueryUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | [**EntityDataQuery**](EntityDataQuery.md)| query | 

### Return type

[**PageDataEntityData**](PageDataEntityData.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="findentitytimeseriesandattributeskeysbyqueryusingpost"></a>
# **FindEntityTimeseriesAndAttributesKeysByQueryUsingPOST**
> DeferredResultResponseEntity FindEntityTimeseriesAndAttributesKeysByQueryUsingPOST (EntityDataQuery query, bool? timeseries, bool? attributes)

findEntityTimeseriesAndAttributesKeysByQuery

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class FindEntityTimeseriesAndAttributesKeysByQueryUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new EntityQueryControllerApi();
            var query = new EntityDataQuery(); // EntityDataQuery | query
            var timeseries = true;  // bool? | timeseries
            var attributes = true;  // bool? | attributes

            try
            {
                // findEntityTimeseriesAndAttributesKeysByQuery
                DeferredResultResponseEntity result = apiInstance.FindEntityTimeseriesAndAttributesKeysByQueryUsingPOST(query, timeseries, attributes);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EntityQueryControllerApi.FindEntityTimeseriesAndAttributesKeysByQueryUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | [**EntityDataQuery**](EntityDataQuery.md)| query | 
 **timeseries** | **bool?**| timeseries | 
 **attributes** | **bool?**| attributes | 

### Return type

[**DeferredResultResponseEntity**](DeferredResultResponseEntity.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

