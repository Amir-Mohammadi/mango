# IO.Swagger.Model.OAuth2CustomMapperConfig
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Password** | **string** |  | [optional] 
**SendToken** | **bool?** |  | [optional] 
**Url** | **string** |  | [optional] 
**Username** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

