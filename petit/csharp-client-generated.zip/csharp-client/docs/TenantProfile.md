# IO.Swagger.Model.TenantProfile
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreatedTime** | **long?** |  | [optional] 
**Default** | **bool?** |  | [optional] 
**Description** | **string** |  | [optional] 
**Id** | [**TenantProfileId**](TenantProfileId.md) |  | [optional] 
**IsolatedTbCore** | **bool?** |  | [optional] 
**IsolatedTbRuleEngine** | **bool?** |  | [optional] 
**Name** | **string** |  | [optional] 
**ProfileData** | [**TenantProfileData**](TenantProfileData.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

