# IO.Swagger.Model.ClientRegistrationDto
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccessTokenUri** | **string** |  | [optional] 
**AdditionalInfo** | **string** |  | [optional] 
**AuthorizationUri** | **string** |  | [optional] 
**ClientAuthenticationMethod** | **string** |  | [optional] 
**ClientId** | **string** |  | [optional] 
**ClientSecret** | **string** |  | [optional] 
**JwkSetUri** | **string** |  | [optional] 
**LoginButtonIcon** | **string** |  | [optional] 
**LoginButtonLabel** | **string** |  | [optional] 
**MapperConfig** | [**OAuth2MapperConfig**](OAuth2MapperConfig.md) |  | [optional] 
**Scope** | **List&lt;string&gt;** |  | [optional] 
**UserInfoUri** | **string** |  | [optional] 
**UserNameAttributeName** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

