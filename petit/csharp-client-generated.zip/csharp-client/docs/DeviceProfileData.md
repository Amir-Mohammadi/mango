# IO.Swagger.Model.DeviceProfileData
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Alarms** | [**List&lt;DeviceProfileAlarm&gt;**](DeviceProfileAlarm.md) |  | [optional] 
**Configuration** | [**DeviceProfileConfiguration**](DeviceProfileConfiguration.md) |  | [optional] 
**ProvisionConfiguration** | [**DeviceProfileProvisionConfiguration**](DeviceProfileProvisionConfiguration.md) |  | [optional] 
**TransportConfiguration** | [**DeviceProfileTransportConfiguration**](DeviceProfileTransportConfiguration.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

