# IO.Swagger.Model.PageDataTenantProfile
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Data** | [**List&lt;TenantProfile&gt;**](TenantProfile.md) |  | [optional] 
**HasNext** | **bool?** |  | [optional] 
**TotalElements** | **long?** |  | [optional] 
**TotalPages** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

