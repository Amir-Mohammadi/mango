# IO.Swagger.Model.WidgetsBundle
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Alias** | **string** |  | [optional] 
**CreatedTime** | **long?** |  | [optional] 
**Description** | **string** |  | [optional] 
**Id** | [**WidgetsBundleId**](WidgetsBundleId.md) |  | [optional] 
**Image** | **string** |  | [optional] 
**TenantId** | [**TenantId**](TenantId.md) |  | [optional] 
**Title** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

