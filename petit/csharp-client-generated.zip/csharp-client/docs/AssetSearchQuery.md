# IO.Swagger.Model.AssetSearchQuery
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AssetTypes** | **List&lt;string&gt;** |  | [optional] 
**Parameters** | [**RelationsSearchParameters**](RelationsSearchParameters.md) |  | [optional] 
**RelationType** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

