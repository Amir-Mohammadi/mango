# IO.Swagger.Model.Alarm
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AckTs** | **long?** |  | [optional] 
**ClearTs** | **long?** |  | [optional] 
**CreatedTime** | **long?** |  | [optional] 
**Details** | **string** |  | [optional] 
**EndTs** | **long?** |  | [optional] 
**Id** | [**AlarmId**](AlarmId.md) |  | [optional] 
**Name** | **string** |  | [optional] 
**Originator** | [**EntityId**](EntityId.md) |  | [optional] 
**Propagate** | **bool?** |  | [optional] 
**PropagateRelationTypes** | **List&lt;string&gt;** |  | [optional] 
**Severity** | **string** |  | [optional] 
**StartTs** | **long?** |  | [optional] 
**Status** | **string** |  | [optional] 
**TenantId** | [**TenantId**](TenantId.md) |  | [optional] 
**Type** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

