# IO.Swagger.Model.RuleChainConnectionInfo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AdditionalInfo** | **string** |  | [optional] 
**FromIndex** | **int?** |  | [optional] 
**TargetRuleChainId** | [**RuleChainId**](RuleChainId.md) |  | [optional] 
**Type** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

