# IO.Swagger.Model.OAuth2ClientsDomainParams
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ClientRegistrations** | [**List&lt;ClientRegistrationDto&gt;**](ClientRegistrationDto.md) |  | [optional] 
**DomainInfos** | [**List&lt;DomainInfo&gt;**](DomainInfo.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

