# IO.Swagger.Model.HomeDashboardInfo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DashboardId** | [**DashboardId**](DashboardId.md) |  | [optional] 
**HideDashboardToolbar** | **bool?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

