# IO.Swagger.Model.RuleNode
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AdditionalInfo** | **string** |  | [optional] 
**Configuration** | **string** |  | [optional] 
**CreatedTime** | **long?** |  | [optional] 
**DebugMode** | **bool?** |  | [optional] 
**Id** | [**RuleNodeId**](RuleNodeId.md) |  | [optional] 
**Name** | **string** |  | [optional] 
**RuleChainId** | [**RuleChainId**](RuleChainId.md) |  | [optional] 
**Type** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

