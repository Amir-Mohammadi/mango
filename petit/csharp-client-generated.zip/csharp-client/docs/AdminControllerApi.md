# IO.Swagger.Api.AdminControllerApi

All URIs are relative to *https://192.168.0.9:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CheckUpdatesUsingGET**](AdminControllerApi.md#checkupdatesusingget) | **GET** /api/admin/updates | checkUpdates
[**GetAdminSettingsUsingGET**](AdminControllerApi.md#getadminsettingsusingget) | **GET** /api/admin/settings/{key} | getAdminSettings
[**GetSecuritySettingsUsingGET**](AdminControllerApi.md#getsecuritysettingsusingget) | **GET** /api/admin/securitySettings | getSecuritySettings
[**SaveAdminSettingsUsingPOST**](AdminControllerApi.md#saveadminsettingsusingpost) | **POST** /api/admin/settings | saveAdminSettings
[**SaveSecuritySettingsUsingPOST**](AdminControllerApi.md#savesecuritysettingsusingpost) | **POST** /api/admin/securitySettings | saveSecuritySettings
[**SendTestMailUsingPOST**](AdminControllerApi.md#sendtestmailusingpost) | **POST** /api/admin/settings/testMail | sendTestMail
[**SendTestSmsUsingPOST**](AdminControllerApi.md#sendtestsmsusingpost) | **POST** /api/admin/settings/testSms | sendTestSms


<a name="checkupdatesusingget"></a>
# **CheckUpdatesUsingGET**
> UpdateMessage CheckUpdatesUsingGET ()

checkUpdates

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CheckUpdatesUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AdminControllerApi();

            try
            {
                // checkUpdates
                UpdateMessage result = apiInstance.CheckUpdatesUsingGET();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AdminControllerApi.CheckUpdatesUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**UpdateMessage**](UpdateMessage.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getadminsettingsusingget"></a>
# **GetAdminSettingsUsingGET**
> AdminSettings GetAdminSettingsUsingGET (string key)

getAdminSettings

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAdminSettingsUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AdminControllerApi();
            var key = key_example;  // string | key

            try
            {
                // getAdminSettings
                AdminSettings result = apiInstance.GetAdminSettingsUsingGET(key);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AdminControllerApi.GetAdminSettingsUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **key** | **string**| key | 

### Return type

[**AdminSettings**](AdminSettings.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getsecuritysettingsusingget"></a>
# **GetSecuritySettingsUsingGET**
> SecuritySettings GetSecuritySettingsUsingGET ()

getSecuritySettings

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetSecuritySettingsUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AdminControllerApi();

            try
            {
                // getSecuritySettings
                SecuritySettings result = apiInstance.GetSecuritySettingsUsingGET();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AdminControllerApi.GetSecuritySettingsUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**SecuritySettings**](SecuritySettings.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="saveadminsettingsusingpost"></a>
# **SaveAdminSettingsUsingPOST**
> AdminSettings SaveAdminSettingsUsingPOST (AdminSettings adminSettings)

saveAdminSettings

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SaveAdminSettingsUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AdminControllerApi();
            var adminSettings = new AdminSettings(); // AdminSettings | adminSettings

            try
            {
                // saveAdminSettings
                AdminSettings result = apiInstance.SaveAdminSettingsUsingPOST(adminSettings);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AdminControllerApi.SaveAdminSettingsUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **adminSettings** | [**AdminSettings**](AdminSettings.md)| adminSettings | 

### Return type

[**AdminSettings**](AdminSettings.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="savesecuritysettingsusingpost"></a>
# **SaveSecuritySettingsUsingPOST**
> SecuritySettings SaveSecuritySettingsUsingPOST (SecuritySettings securitySettings)

saveSecuritySettings

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SaveSecuritySettingsUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AdminControllerApi();
            var securitySettings = new SecuritySettings(); // SecuritySettings | securitySettings

            try
            {
                // saveSecuritySettings
                SecuritySettings result = apiInstance.SaveSecuritySettingsUsingPOST(securitySettings);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AdminControllerApi.SaveSecuritySettingsUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **securitySettings** | [**SecuritySettings**](SecuritySettings.md)| securitySettings | 

### Return type

[**SecuritySettings**](SecuritySettings.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="sendtestmailusingpost"></a>
# **SendTestMailUsingPOST**
> void SendTestMailUsingPOST (AdminSettings adminSettings)

sendTestMail

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SendTestMailUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AdminControllerApi();
            var adminSettings = new AdminSettings(); // AdminSettings | adminSettings

            try
            {
                // sendTestMail
                apiInstance.SendTestMailUsingPOST(adminSettings);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AdminControllerApi.SendTestMailUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **adminSettings** | [**AdminSettings**](AdminSettings.md)| adminSettings | 

### Return type

void (empty response body)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="sendtestsmsusingpost"></a>
# **SendTestSmsUsingPOST**
> void SendTestSmsUsingPOST (TestSmsRequest testSmsRequest)

sendTestSms

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SendTestSmsUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new AdminControllerApi();
            var testSmsRequest = new TestSmsRequest(); // TestSmsRequest | testSmsRequest

            try
            {
                // sendTestSms
                apiInstance.SendTestSmsUsingPOST(testSmsRequest);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AdminControllerApi.SendTestSmsUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **testSmsRequest** | [**TestSmsRequest**](TestSmsRequest.md)| testSmsRequest | 

### Return type

void (empty response body)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

