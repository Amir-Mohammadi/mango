# IO.Swagger.Api.OAuth2ControllerApi

All URIs are relative to *https://192.168.0.9:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetCurrentOAuth2ParamsUsingGET**](OAuth2ControllerApi.md#getcurrentoauth2paramsusingget) | **GET** /api/oauth2/config | getCurrentOAuth2Params
[**GetLoginProcessingUrlUsingGET**](OAuth2ControllerApi.md#getloginprocessingurlusingget) | **GET** /api/oauth2/loginProcessingUrl | getLoginProcessingUrl
[**GetOAuth2ClientsUsingPOST**](OAuth2ControllerApi.md#getoauth2clientsusingpost) | **POST** /api/noauth/oauth2Clients | getOAuth2Clients
[**SaveOAuth2ParamsUsingPOST**](OAuth2ControllerApi.md#saveoauth2paramsusingpost) | **POST** /api/oauth2/config | saveOAuth2Params


<a name="getcurrentoauth2paramsusingget"></a>
# **GetCurrentOAuth2ParamsUsingGET**
> OAuth2ClientsParams GetCurrentOAuth2ParamsUsingGET ()

getCurrentOAuth2Params

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetCurrentOAuth2ParamsUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new OAuth2ControllerApi();

            try
            {
                // getCurrentOAuth2Params
                OAuth2ClientsParams result = apiInstance.GetCurrentOAuth2ParamsUsingGET();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OAuth2ControllerApi.GetCurrentOAuth2ParamsUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**OAuth2ClientsParams**](OAuth2ClientsParams.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getloginprocessingurlusingget"></a>
# **GetLoginProcessingUrlUsingGET**
> string GetLoginProcessingUrlUsingGET ()

getLoginProcessingUrl

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetLoginProcessingUrlUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new OAuth2ControllerApi();

            try
            {
                // getLoginProcessingUrl
                string result = apiInstance.GetLoginProcessingUrlUsingGET();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OAuth2ControllerApi.GetLoginProcessingUrlUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

**string**

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getoauth2clientsusingpost"></a>
# **GetOAuth2ClientsUsingPOST**
> List<OAuth2ClientInfo> GetOAuth2ClientsUsingPOST ()

getOAuth2Clients

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetOAuth2ClientsUsingPOSTExample
    {
        public void main()
        {
            var apiInstance = new OAuth2ControllerApi();

            try
            {
                // getOAuth2Clients
                List&lt;OAuth2ClientInfo&gt; result = apiInstance.GetOAuth2ClientsUsingPOST();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OAuth2ControllerApi.GetOAuth2ClientsUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List<OAuth2ClientInfo>**](OAuth2ClientInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="saveoauth2paramsusingpost"></a>
# **SaveOAuth2ParamsUsingPOST**
> OAuth2ClientsParams SaveOAuth2ParamsUsingPOST (OAuth2ClientsParams oauth2Params)

saveOAuth2Params

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SaveOAuth2ParamsUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new OAuth2ControllerApi();
            var oauth2Params = new OAuth2ClientsParams(); // OAuth2ClientsParams | oauth2Params

            try
            {
                // saveOAuth2Params
                OAuth2ClientsParams result = apiInstance.SaveOAuth2ParamsUsingPOST(oauth2Params);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OAuth2ControllerApi.SaveOAuth2ParamsUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **oauth2Params** | [**OAuth2ClientsParams**](OAuth2ClientsParams.md)| oauth2Params | 

### Return type

[**OAuth2ClientsParams**](OAuth2ClientsParams.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

