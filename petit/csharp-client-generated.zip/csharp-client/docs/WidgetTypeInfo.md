# IO.Swagger.Model.WidgetTypeInfo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Alias** | **string** |  | [optional] 
**BundleAlias** | **string** |  | [optional] 
**CreatedTime** | **long?** |  | [optional] 
**Description** | **string** |  | [optional] 
**Id** | [**WidgetTypeId**](WidgetTypeId.md) |  | [optional] 
**Image** | **string** |  | [optional] 
**Name** | **string** |  | [optional] 
**TenantId** | [**TenantId**](TenantId.md) |  | [optional] 
**WidgetType** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

