# IO.Swagger.Api.UserControllerApi

All URIs are relative to *https://192.168.0.9:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**DeleteUserUsingDELETE**](UserControllerApi.md#deleteuserusingdelete) | **DELETE** /api/user/{userId} | deleteUser
[**GetActivationLinkUsingGET**](UserControllerApi.md#getactivationlinkusingget) | **GET** /api/user/{userId}/activationLink | getActivationLink
[**GetCustomerUsersUsingGET**](UserControllerApi.md#getcustomerusersusingget) | **GET** /api/customer/{customerId}/users{?textSearch,sortProperty,sortOrder,pageSize,page} | getCustomerUsers
[**GetTenantAdminsUsingGET**](UserControllerApi.md#gettenantadminsusingget) | **GET** /api/tenant/{tenantId}/users{?textSearch,sortProperty,sortOrder,pageSize,page} | getTenantAdmins
[**GetUserByIdUsingGET**](UserControllerApi.md#getuserbyidusingget) | **GET** /api/user/{userId} | getUserById
[**GetUserTokenUsingGET**](UserControllerApi.md#getusertokenusingget) | **GET** /api/user/{userId}/token | getUserToken
[**GetUsersUsingGET**](UserControllerApi.md#getusersusingget) | **GET** /api/users{?textSearch,sortProperty,sortOrder,pageSize,page} | getUsers
[**IsUserTokenAccessEnabledUsingGET**](UserControllerApi.md#isusertokenaccessenabledusingget) | **GET** /api/user/tokenAccessEnabled | isUserTokenAccessEnabled
[**SaveUserUsingPOST**](UserControllerApi.md#saveuserusingpost) | **POST** /api/user{?sendActivationMail} | saveUser
[**SendActivationEmailUsingPOST**](UserControllerApi.md#sendactivationemailusingpost) | **POST** /api/user/sendActivationMail{?email} | sendActivationEmail
[**SetUserCredentialsEnabledUsingPOST**](UserControllerApi.md#setusercredentialsenabledusingpost) | **POST** /api/user/{userId}/userCredentialsEnabled{?userCredentialsEnabled} | setUserCredentialsEnabled


<a name="deleteuserusingdelete"></a>
# **DeleteUserUsingDELETE**
> void DeleteUserUsingDELETE (string userId)

deleteUser

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeleteUserUsingDELETEExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new UserControllerApi();
            var userId = userId_example;  // string | userId

            try
            {
                // deleteUser
                apiInstance.DeleteUserUsingDELETE(userId);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling UserControllerApi.DeleteUserUsingDELETE: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userId** | **string**| userId | 

### Return type

void (empty response body)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getactivationlinkusingget"></a>
# **GetActivationLinkUsingGET**
> string GetActivationLinkUsingGET (string userId)

getActivationLink

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetActivationLinkUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new UserControllerApi();
            var userId = userId_example;  // string | userId

            try
            {
                // getActivationLink
                string result = apiInstance.GetActivationLinkUsingGET(userId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling UserControllerApi.GetActivationLinkUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userId** | **string**| userId | 

### Return type

**string**

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: text/plain

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getcustomerusersusingget"></a>
# **GetCustomerUsersUsingGET**
> PageDataUser GetCustomerUsersUsingGET (string customerId, string pageSize, string page, string textSearch = null, string sortProperty = null, string sortOrder = null)

getCustomerUsers

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetCustomerUsersUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new UserControllerApi();
            var customerId = customerId_example;  // string | customerId
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 

            try
            {
                // getCustomerUsers
                PageDataUser result = apiInstance.GetCustomerUsersUsingGET(customerId, pageSize, page, textSearch, sortProperty, sortOrder);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling UserControllerApi.GetCustomerUsersUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customerId** | **string**| customerId | 
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 

### Return type

[**PageDataUser**](PageDataUser.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="gettenantadminsusingget"></a>
# **GetTenantAdminsUsingGET**
> PageDataUser GetTenantAdminsUsingGET (string tenantId, string pageSize, string page, string textSearch = null, string sortProperty = null, string sortOrder = null)

getTenantAdmins

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetTenantAdminsUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new UserControllerApi();
            var tenantId = tenantId_example;  // string | tenantId
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 

            try
            {
                // getTenantAdmins
                PageDataUser result = apiInstance.GetTenantAdminsUsingGET(tenantId, pageSize, page, textSearch, sortProperty, sortOrder);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling UserControllerApi.GetTenantAdminsUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tenantId** | **string**| tenantId | 
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 

### Return type

[**PageDataUser**](PageDataUser.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getuserbyidusingget"></a>
# **GetUserByIdUsingGET**
> User GetUserByIdUsingGET (string userId)

getUserById

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetUserByIdUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new UserControllerApi();
            var userId = userId_example;  // string | userId

            try
            {
                // getUserById
                User result = apiInstance.GetUserByIdUsingGET(userId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling UserControllerApi.GetUserByIdUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userId** | **string**| userId | 

### Return type

[**User**](User.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getusertokenusingget"></a>
# **GetUserTokenUsingGET**
> string GetUserTokenUsingGET (string userId)

getUserToken

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetUserTokenUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new UserControllerApi();
            var userId = userId_example;  // string | userId

            try
            {
                // getUserToken
                string result = apiInstance.GetUserTokenUsingGET(userId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling UserControllerApi.GetUserTokenUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userId** | **string**| userId | 

### Return type

**string**

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getusersusingget"></a>
# **GetUsersUsingGET**
> PageDataUser GetUsersUsingGET (string pageSize, string page, string textSearch = null, string sortProperty = null, string sortOrder = null)

getUsers

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetUsersUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new UserControllerApi();
            var pageSize = pageSize_example;  // string | pageSize
            var page = page_example;  // string | page
            var textSearch = textSearch_example;  // string | textSearch (optional) 
            var sortProperty = sortProperty_example;  // string | sortProperty (optional) 
            var sortOrder = sortOrder_example;  // string | sortOrder (optional) 

            try
            {
                // getUsers
                PageDataUser result = apiInstance.GetUsersUsingGET(pageSize, page, textSearch, sortProperty, sortOrder);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling UserControllerApi.GetUsersUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pageSize** | **string**| pageSize | 
 **page** | **string**| page | 
 **textSearch** | **string**| textSearch | [optional] 
 **sortProperty** | **string**| sortProperty | [optional] 
 **sortOrder** | **string**| sortOrder | [optional] 

### Return type

[**PageDataUser**](PageDataUser.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="isusertokenaccessenabledusingget"></a>
# **IsUserTokenAccessEnabledUsingGET**
> bool? IsUserTokenAccessEnabledUsingGET ()

isUserTokenAccessEnabled

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class IsUserTokenAccessEnabledUsingGETExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new UserControllerApi();

            try
            {
                // isUserTokenAccessEnabled
                bool? result = apiInstance.IsUserTokenAccessEnabledUsingGET();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling UserControllerApi.IsUserTokenAccessEnabledUsingGET: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

**bool?**

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="saveuserusingpost"></a>
# **SaveUserUsingPOST**
> User SaveUserUsingPOST (User user, bool? sendActivationMail = null)

saveUser

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SaveUserUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new UserControllerApi();
            var user = new User(); // User | user
            var sendActivationMail = true;  // bool? | sendActivationMail (optional)  (default to true)

            try
            {
                // saveUser
                User result = apiInstance.SaveUserUsingPOST(user, sendActivationMail);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling UserControllerApi.SaveUserUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user** | [**User**](User.md)| user | 
 **sendActivationMail** | **bool?**| sendActivationMail | [optional] [default to true]

### Return type

[**User**](User.md)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="sendactivationemailusingpost"></a>
# **SendActivationEmailUsingPOST**
> void SendActivationEmailUsingPOST (string email)

sendActivationEmail

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SendActivationEmailUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new UserControllerApi();
            var email = email_example;  // string | email

            try
            {
                // sendActivationEmail
                apiInstance.SendActivationEmailUsingPOST(email);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling UserControllerApi.SendActivationEmailUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **email** | **string**| email | 

### Return type

void (empty response body)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="setusercredentialsenabledusingpost"></a>
# **SetUserCredentialsEnabledUsingPOST**
> void SetUserCredentialsEnabledUsingPOST (string userId, bool? userCredentialsEnabled = null)

setUserCredentialsEnabled

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SetUserCredentialsEnabledUsingPOSTExample
    {
        public void main()
        {
            // Configure API key authorization: X-Authorization
            Configuration.Default.AddApiKey("X-Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("X-Authorization", "Bearer");

            var apiInstance = new UserControllerApi();
            var userId = userId_example;  // string | userId
            var userCredentialsEnabled = true;  // bool? | userCredentialsEnabled (optional)  (default to true)

            try
            {
                // setUserCredentialsEnabled
                apiInstance.SetUserCredentialsEnabledUsingPOST(userId, userCredentialsEnabled);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling UserControllerApi.SetUserCredentialsEnabledUsingPOST: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userId** | **string**| userId | 
 **userCredentialsEnabled** | **bool?**| userCredentialsEnabled | [optional] [default to true]

### Return type

void (empty response body)

### Authorization

[X-Authorization](../README.md#X-Authorization)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

